﻿var Quikrete = Quikrete || {};

Quikrete.CustomerAddress = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userBUID = null;
    var userID = null;

    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        // Adds a function to be called when form data is loaded.
        formContext.data.addOnLoad(formOnLoad);

        if (formContext.getAttribute("postalcode") != null)
            formContext.getAttribute("postalcode").addOnChange(populateLocation);

        if (formContext.getAttribute("new_jobsitephone") != null)
            formContext.getAttribute("new_jobsitephone").addOnChange(onChangeofJobsitePhone);

    }

    async function populateLocation() {

        var zipCode = formContext.getAttribute("postalcode").getValue();

        if (zipCode) {
            var fieldCity = "new_citylookup";
            var fieldState = "new_statelookup";
            var fieldCounty = "new_countylookup";
            var fieldCountry = "new_countrylookup";

            var citylookup = `_${fieldCity}_value`;
            var citylookup_formatted = `${citylookup}@OData.Community.Display.V1.FormattedValue`;

            var countrylookup = `_${fieldCountry}_value`;
            var countrylookup_formatted = `${countrylookup}@OData.Community.Display.V1.FormattedValue`;

            var countylookup = `_${fieldCounty}_value`;
            var countylookup_formatted = `${countylookup}@OData.Community.Display.V1.FormattedValue`;

            var statelookup = `_${fieldState}_value`;
            var statelookup_formatted = `${statelookup}@OData.Community.Display.V1.FormattedValue`;

            var response = await formContext.retrieveMultipleRecords("new_zipcode", `?$filter=new_zipcode eq '${zipCode}'`)
            if (response != null && response.length > 0) {
                var result = response[0];
                formContext.setFieldValue("city", result[citylookup_formatted]);
                formContext.setFieldValue("new_city_guid", result[citylookup]);

                formContext.setFieldValue("new_state", result[statelookup_formatted]);
                formContext.setFieldValue("new_state_guid", result[statelookup]);

                formContext.setFieldValue("county", result[countylookup_formatted]);
                formContext.setFieldValue("new_county_guid", result[countylookup]);

                formContext.setFieldValue("country", result[countrylookup_formatted]);
                formContext.setFieldValue("new_country_guid", result[countrylookup]);
            }
        }
        else {
            formContext.setFieldValue("city", "");
            formContext.setFieldValue("new_city_guid", "");

            formContext.setFieldValue("new_state", "");
            formContext.setFieldValue("new_state_guid", "");

            formContext.setFieldValue("county", "");
            formContext.setFieldValue("new_county_guid", "");

            formContext.setFieldValue("country", "");
            formContext.setFieldValue("new_country_guid", "");
        }

    }

    async function onChangeofJobsitePhone() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "new_jobsitephone");
    }

    async function formOnLoad() {

        formContext.makeFieldRequired("name", false);
        formContext.makeFieldRequired("postalcode");
        formContext.setFieldSubmitMode("postalcode");

        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);

        var userHasAdministratorRole = formContext.isUserAdministrator();

        if (userHasAdministratorRole) {
            formContext.makeFieldDisabled("new_shiptonumber", false);
            formContext.makeFieldDisabled("new_isactive", false);
        }
        else {
            formContext.makeFieldDisabled("new_shiptonumber", true);
            formContext.makeFieldDisabled("new_isactive", true);
        }

        var isActive = formContext.getFieldValue("new_isactive");

        if (isActive == false) {
            formContext.makeFieldDisabled("new_shiptonumber", true);
            formContext.makeFieldDisabled("new_jobsitecontact", true);
            formContext.makeFieldDisabled("new_jobsitephone", true);
            formContext.makeFieldDisabled("new_jobsiteemail", true);
            formContext.makeFieldDisabled("new_shiptorequest", true);

            formContext.makeFieldDisabled("addresstypecode", true);
            formContext.makeFieldDisabled("line1", true);
            formContext.makeFieldDisabled("line2", true);
            formContext.makeFieldDisabled("line3", true);
            formContext.makeFieldDisabled("city", true);
            formContext.makeFieldDisabled("new_statepicklist", true);
            formContext.makeFieldDisabled("new_countypicklist", true);
            formContext.makeFieldDisabled("postalcode", true);
        }
        else {

            //if (Xrm.Page.data.entity.getId() != null) {
            //    var url = GetCustomPageLocationURL() + '/JDEAccountDetail.aspx?accountId=' + Xrm.Page.data.entity.getId() + "&EntityName=CustomerAddress";
            //    Xrm.Page.getControl("IFRAME_JDEAddressInfo").setSrc(url);
            //}

            var formType = formContext.getFormType();

            if (formType === Quikrete.Common.FormType.Create) {
                formContext.makeFieldDisabled("new_shiptorequest", true);
            }
            else if (formType === Quikrete.Common.FormType.Update) {

                var strJdeNumberValue = formContext.getFieldValue("new_jdeformnumber");
                var strshiptoNumber = formContext.getFieldValue("new_shiptonumber");

                if (strJdeNumberValue != null && strJdeNumberValue != "") {
                    if (formContext.getFieldValue("new_shiptonumber") == "Rejected") {
                        formContext.makeFieldDisabled("new_shiptorequest", false);
                    }
                    else {
                        formContext.makeFieldDisabled("new_shiptorequest", true);
                    }
                }
                else if (strshiptoNumber?.toLowerCase()?.includes("request has been sent")) {
                    formContext.makeFieldDisabled("new_shiptorequest", true);
                }
                else {
                    var parentAccountID = formContext.getFieldValue("parentid");

                    if (parentAccountID.length > 0) {
                        var accountGuid = parentAccountID[0].id;
                        // Define the query to get the teams the user belongs to
                        const queryParam = `?$select=accountnumber`;

                        // Make the Web API request to retrieve 
                        var response = await formContext.retrieveRecord("account", accountGuid, queryParam);
                        if (response != null) {
                            if (response.accountnumber?.toLowerCase().includes("request")) {
                                formContext.makeFieldDisabled("new_shiptorequest", true);
                            }
                            else {
                                formContext.makeFieldDisabled("new_shiptorequest", false);
                            }
                        }
                    }
                }
            }
        }
        if (userBUID == Quikrete.Common.FoleyBU || userBUID == Quikrete.Common.OldCastleBU) {
            formContext.makeFieldDisabled("new_shiptorequest", true);
        }
    }

    return {
        Init: init,
        FormOnLoad: formOnLoad,
        OnChangeofJobsitePhone: onChangeofJobsitePhone
    }
}());