﻿var Quikrete = Quikrete || {};
Quikrete.ISVFunctions = (function () {

    async function getDetailsByZipCode(formContext, fieldzipCode, fieldCity, fieldState, fieldCounty, fieldCountry) {
        var zipCode = formContext.getFieldValue(fieldzipCode);
        var isValidZipcodeSet = false;

        var response = await formContext.retrieveMultipleRecords("new_zipcode", `?$select=new_zipcodeid,new_city,new_state,new_county,new_country,_new_pipesalesmanager_value,_new_fabsalesmanager_value&$filter=new_zipcode eq '${zipCode}'`)
        if (response != null) {
            var result = response[0];
            formContext.setFieldValue(fieldCity, result["new_city"]);
            formContext.setFieldValue(fieldState, result["new_state"]);
            formContext.setFieldValue(fieldCounty, result["new_county"]);
            formContext.setFieldValue(fieldCountry, result["new_country"]);
            isValidZipcodeSet = true;
        }
        else {
            formContext.setFieldValue(fieldCity, null);
            formContext.setFieldValue(fieldState, null);
            formContext.setFieldValue(fieldCounty, null);
            formContext.setFieldValue(fieldCountry, null);
        }
        return isValidZipcodeSet;
    };

    async function getDetailsByZipCodeLookup(formContext, fieldzipCode, setfieldCity, setfieldState, setfieldCounty, setfieldCountry, setPipeManager, setFabManager) {

        //Zipcode columns fields
        var fieldCity = "new_citylookup";
        var fieldState = "new_statelookup";
        var fieldCounty = "new_countylookup";
        var fieldCountry = "new_countrylookup";

        //user entity
        var fieldPipeManager = "new_pipesalesmanager";
        var fieldFabManager = "new_fabsalesmanager";

        // Columns
        var citylookup = `_${fieldCity}_value`; // Lookup
        var citylookup_formatted = `${citylookup}@OData.Community.Display.V1.FormattedValue`;
        var citylookup_lookuplogicalname = `${citylookup}@Microsoft.Dynamics.CRM.lookuplogicalname`;

        var countrylookup = `_${fieldCountry}_value`; // Lookup
        var countrylookup_formatted = `${countrylookup}@OData.Community.Display.V1.FormattedValue`;
        var countrylookup_lookuplogicalname = `${countrylookup}@Microsoft.Dynamics.CRM.lookuplogicalname`;

        var countylookup = `_${fieldCounty}_value`; // Lookup
        var countylookup_formatted = `${countylookup}@OData.Community.Display.V1.FormattedValue`;
        var countylookup_lookuplogicalname = `${countylookup}@Microsoft.Dynamics.CRM.lookuplogicalname`;

        var statelookup = `_${fieldState}_value`; // Lookup
        var statelookup_formatted = `${statelookup}@OData.Community.Display.V1.FormattedValue`;
        var statelookup_lookuplogicalname = `${statelookup}@Microsoft.Dynamics.CRM.lookuplogicalname`;


        var pipeManagerLookup = `_${fieldPipeManager}_value`; // Lookup
        var pipeManagerLookup_formatted = `${pipeManagerLookup}@OData.Community.Display.V1.FormattedValue`;
        var pipeManagerLookup_lookuplogicalname = `${pipeManagerLookup}@Microsoft.Dynamics.CRM.lookuplogicalname`;


        var fabManagerLookup = `_${fieldFabManager}_value`; // Lookup
        var fabManagerLookup_formatted = `${fabManagerLookup}@OData.Community.Display.V1.FormattedValue`;
        var fabManagerLookup_lookuplogicalname = `${fabManagerLookup}@Microsoft.Dynamics.CRM.lookuplogicalname`;

        var colums = `new_zipcodeid,${citylookup},${statelookup},${countylookup},${countrylookup},${pipeManagerLookup},${fabManagerLookup}`;

        var zipCode = formContext.getFieldValue(fieldzipCode);
        var isValidZipcodeSet = false;

        if (zipCode != null) {

            var zipcodeid = zipCode[0].id.replace("{", "").replace("}", "");
            //Set Value to Loolup
            var response = await formContext.retrieveRecord("new_zipcode", zipcodeid, `?$select=${colums}`);

            if (response != null) {
                var result = response;

                // City lookup Set
                var lookupCity = [];
                lookupCity[0] = new Object();
                lookupCity[0].id = result[`${citylookup}`];
                lookupCity[0].name = result[`${citylookup_formatted}`];
                lookupCity[0].entityType = result[`${citylookup_lookuplogicalname}`];

                // State lookup Set
                var lookupState = [];
                lookupState[0] = {};
                lookupState[0].id = result[`${statelookup}`];
                lookupState[0].name = result[`${statelookup_formatted}`];
                lookupState[0].entityType = result[`${statelookup_lookuplogicalname}`];

                // County lookup Set
                var lookupCounty = [];
                lookupCounty[0] = {};
                lookupCounty[0].id = result[`${countylookup}`];
                lookupCounty[0].name = result[`${countylookup_formatted}`];
                lookupCounty[0].entityType = result[`${countylookup_lookuplogicalname}`];


                // Country lookup Set
                var lookupCountry = [];
                lookupCountry[0] = {};
                lookupCountry[0].id = result[`${countrylookup}`];
                lookupCountry[0].name = result[`${countrylookup_formatted}`];
                lookupCountry[0].entityType = result[`${countrylookup_lookuplogicalname}`];

                // Pipe Manager set
                if (setPipeManager) {
                    var lookupPipeManager = [];
                    if (pipeManagerLookup != '') {
                        lookupPipeManager[0] = new Object();
                        lookupPipeManager[0].id = result[`${pipeManagerLookup}`];
                        lookupPipeManager[0].name = result[`${pipeManagerLookup_formatted}`];
                        lookupPipeManager[0].entityType = result[`${pipeManagerLookup_lookuplogicalname}`];

                        if (lookupPipeManager[0].id != null)
                            formContext.setFieldValue(setPipeManager, lookupPipeManager);
                        else
                            formContext.setFieldValue(setPipeManager, null);
                    }
                }

                if (setFabManager) {
                    // Fab Manager set
                    var lookupFabManager = [];
                    if (fabManagerLookup != '') {
                        lookupFabManager[0] = new Object();
                        lookupFabManager[0].id = result[`${fabManagerLookup}`];
                        lookupFabManager[0].name = result[`${fabManagerLookup_formatted}`];
                        lookupFabManager[0].entityType = result[`${fabManagerLookup_lookuplogicalname}`];

                        if (lookupFabManager[0].id != null)
                            formContext.setFieldValue(setFabManager, lookupFabManager);
                        else
                            formContext.setFieldValue(setFabManager, null);

                    }
                }

                if (lookupCity[0].id != null)
                    formContext.setFieldValue(setfieldCity, lookupCity);
                else
                    formContext.setFieldValue(setfieldCity, null);

                if (lookupState[0].id != null)
                    formContext.setFieldValue(setfieldState, lookupState);
                else
                    formContext.setFieldValue(setfieldState, null);

                if (lookupCounty[0].id != null)
                    formContext.setFieldValue(setfieldCounty, lookupCounty);
                else
                    formContext.setFieldValue(setfieldCounty, null);

                if (lookupCountry[0].id != null)
                    formContext.setFieldValue(setfieldCountry, lookupCountry);
                else
                    formContext.setFieldValue(setfieldCountry, null);

                isValidZipcodeSet = true;
            }
            else {
                formContext.setFieldValue(setfieldCity, null);
                formContext.setFieldValue(setfieldState, null);
                formContext.setFieldValue(setfieldCounty, null);
                formContext.setFieldValue(setfieldCountry, null);
                if (setPipeManager)
                    formContext.setFieldValue(setPipeManager, null);
                if (setFabManager)
                    formContext.setFieldValue(setFabManager, null);
            }
        }
        return isValidZipcodeSet;
    };

    function validateAndFormatFaxPhoneNumber(formContext, fieldName) {
        try {
            const fieldValue = formContext.getFieldValue(fieldName);// Fetch the field value
            if (fieldValue) {

                // Remove non-alphanumeric characters
                let sTmpValue = fieldValue.replace(/[^0-9]/g, "");

                // Validate and update the phone number field
                if (sTmpValue.length === 10) {
                    const formattedValue = applyPhoneMask(sTmpValue);
                    formContext.setFieldValue(fieldName, formattedValue);
                } else if (sTmpValue.length > 10) {
                    const formattedValue = applyPhoneMask(sTmpValue.substr(0, 10)) + " " + sTmpValue.substr(10);
                    formContext.setFieldValue(fieldName, formattedValue);
                } else {
                    formContext.setFieldValue(fieldName, null); // Reset field value
                    formContext.openAlertDialog("Warning", "Please enter a valid ten-digit number!");
                }
            }
        } catch (error) {
            console.error("Error validating phone number:", error.message);
            return error;
        }
    };

    // Utility function to apply a mask to phone numbers
    function applyPhoneMask(value) {
        if (value.length === 10) {
            // Format as (XXX) XXX-XXXX for 10-digit numbers
            return `(${value.substr(0, 3)}) ${value.substr(3, 3)}-${value.substr(6)} `;
        }
        return value; // Return unformatted for non-10-digit inputs (though this should be rare after validation)
    }

    async function cloneRecord(formContext, entityName, record, removedFieldList, openform = true) {



        let cleanedRecord = {};
        let lookupProcessedFields = new Set();
        for (let key in record) {
            if (record[key] !== null && record[key] !== undefined) {
                if (removedFieldList.some(pattern => key.toLowerCase().includes(pattern))) continue;
                if (key.endsWith("_value")) {
                    let entityLogicalName = record[`${key}@Microsoft.Dynamics.CRM.lookuplogicalname`];
                    let entitySetName = '';
                    if (entityLogicalName == 'new_productattributes') {
                        entitySetName = 'new_productattributeses';
                    }
                    else {
                        entitySetName = entityLogicalName ? entityLogicalName.plural() : null;
                    }
                    if (entitySetName) {
                        let navigationProperty = record[`${key}@Microsoft.Dynamics.CRM.associatednavigationproperty`];
                        if (navigationProperty) {

                            cleanedRecord[`${navigationProperty}@odata.bind`] = `/${entitySetName}(${record[key]})`;
                            lookupProcessedFields.add(`${key}@Microsoft.Dynamics.CRM.associatednavigationproperty`);
                            lookupProcessedFields.add(`${key}@Microsoft.Dynamics.CRM.lookuplogicalname`);
                        }
                        else {
                            let fallbackNav = key.replace(/_value$/, '').replace(/^_/, '');
                            // Handle specific field overrides (e.g., casing correction)
                            if (["quote", "salesorder"].includes(entityName.toLowerCase()) && entitySetName === "systemusers") {
                                let globalContext = Xrm.Utility.getGlobalContext()
                                let orgUrl = globalContext.getClientUrl()
                                const entityDefination = await fetch(`${orgUrl}/api/data/v9.2/EntityDefinitions(LogicalName='${entityName}')/Attributes(LogicalName='${fallbackNav}')`);
                                const attr = await entityDefination.json();
                                cleanedRecord[`${attr?.SchemaName}@odata.bind`] = `/${entitySetName}(${record[key]})`;
                            }
                        }
                    }
                }
                else if (!lookupProcessedFields.has(key)) {
                    cleanedRecord[key] = record[key];
                }
            }
        }

        const result = await Xrm.WebApi.createRecord(entityName, cleanedRecord);
        if (openform) {
            if (result) {
                var entityFormOptions = {};
                entityFormOptions["entityName"] = entityName;
                entityFormOptions["entityId"] = result.id;
                formContext.openForm(entityFormOptions).then(
                    function (success) {
                        console.log(success);
                    },
                    function (error) {

                        console.log(error);
                    });
            }
        }
        return result;
    }

    async function transactionalCopy(primaryControl, primaryEntityName) {
        debugger;
        const formContext = primaryControl;
        try {
            const currentRecordId = formContext.getCurrentRecordId();

            const entityNameMap = {
                'quote': ['opportunityid'],
                'salesorder': ['quoteid', 'opportunityid']
            };

            const excludeFields = [
                ...getFieldByEntity(primaryEntityName),
                `${primaryEntityName}id`,
                ...(entityNameMap[primaryEntityName] || [])
            ];

            Xrm.Utility.showProgressIndicator("Getting record details...");
            const existingRecord = await Xrm.WebApi.retrieveRecord(
                primaryEntityName,
                currentRecordId,
                "?$expand=customerid_account($select=_ownerid_value,address2_stateorprovince,address2_country)"
            );

            // Add copy tracking fields
            if (primaryEntityName === "salesorder") {
                Object.assign(existingRecord, {
                    "new_issavedfirsttime": true,
                    "new_ordercopiedfrom": existingRecord.ordernumber,
                    "new_ordercopieddate": new Date(),
                    "ispricelocked": false,
                    "new_signedcontechquotedate": new Date(),
                    "new_customerporeceiveddate": new Date(),
                    "new_letterofintentdate": new Date(),
                    "new_verbalorderdate": new Date(),
                    "new_taxexemptcert": new Date(),
                    "billto_stateorprovince": existingRecord.customerid_account?.address2_stateorprovince,
                    "billto_country": existingRecord.customerid_account?.address2_country,
                    "new_ordercopiedby": formContext.getUserSetting().userName
                });
            }

            if (primaryEntityName === "quote") {
                Object.assign(existingRecord, {
                    new_quotecopiedfrom: existingRecord.quotenumber,
                    new_quotecopieddate: new Date(),
                    new_quotecopiedby: formContext.getUserSetting().userName
                });
            }

            // Clone main record
            Xrm.Utility.showProgressIndicator("Creating main record...");
            const result = await Quikrete.ISVFunctions.CloneRecord(formContext, primaryEntityName, existingRecord, excludeFields, false);
            formContext.close();
            if (result) {
                const newRecordID = result.id;
                Xrm.Utility.showProgressIndicator("Retrieving related products...");
                const associateEntityName = primaryEntityName === 'quote' ? 'quote_details' : 'order_details';
                const entityToCreate = primaryEntityName === 'quote' ? 'quotedetail' : 'salesorderdetail';
                const associatedProducts = await formContext.retrieveRecord(primaryEntityName, currentRecordId, `?$select=${primaryEntityName}id&$expand=${associateEntityName}`);
                const products = associatedProducts[associateEntityName];

                for (let i = 0; i < products.length; i++) {
                    Xrm.Utility.showProgressIndicator(
                        `Creating product ${i + 1} of ${products.length}...`
                    );


                    const product = products[i];
                    let clonedAttributeId = '';

                    const productAttributeId = product?._new_productattribute_value;
                    if (productAttributeId) {
                        clonedAttributeId = await cloneProductAttribute(formContext, "new_productattributes", productAttributeId);
                        if (clonedAttributeId) {
                            product._new_productattribute_value = clonedAttributeId;
                        }
                    }

                    const excludedFields = [
                        ...getProductFieldByEntity(entityToCreate),
                        `${entityToCreate}id`
                    ]

                    if (primaryEntityName === "quote") {
                        product._quoteid_value = newRecordID;
                    } else {
                        product._salesorderid_value = newRecordID;
                    }

                    const newProduct = await Quikrete.ISVFunctions.CloneRecord(formContext, entityToCreate, product, excludedFields, false);
                    await Quikrete.ISVFunctions.UpdateProductAttribute(formContext, clonedAttributeId, newProduct);
                }
                formContext.close();

            }
            return result;
        } catch (error) {
            showError(formContext, (error?.message.match(/InnerException\s*:\s*(.+)/)?.[1]?.trim()) || "Something Went Wrong..!");
        } finally {
            Xrm.Utility.closeProgressIndicator();
        }
    }

    async function cloneProductAttribute(formContext, entityName, recordId) {

        if (!recordId) return '';

        const existingRecord = await Xrm.WebApi.retrieveRecord(entityName, recordId);
        const excludePatterns = [
            ...getExcludePatterns(entityName),
            "new_OpportunityProduct",
            "_new_opportunityproduct_value",
            "_new_salesorderdetail_value",
            "_new_quotedetail_value",
            "_new_opportunityproduct_value"
        ];

        const result = await Quikrete.ISVFunctions.CloneRecord(formContext, entityName, existingRecord, excludePatterns, false);
        return result?.id ?? '';
    }

    async function updateProductAttribute(formContext, productattributeid, newProduct) {

        if (newProduct) {
            if (productattributeid != '') {
                var record = {};
                if (newProduct.entityType.toLowerCase() == "salesorderdetail") {
                    record["new_SalesOrderDetail@odata.bind"] = `/salesorderdetails(${newProduct.id})`;
                }
                else if (newProduct.entityType.toLowerCase() == "quotedetail") {
                    record["new_QuoteDetail@odata.bind"] = `/quotedetails(${newProduct.id})`;
                }
                else if (newProduct.entityType.toLowerCase() == "opportunityproduct") {
                    record["new_OpportunityProduct@odata.bind"] = `/opportunityproducts(${newProduct.id})`;
                }
                await Xrm.WebApi.updateRecord("new_productattributes", productattributeid, record);
            }
        }
    }

    function getExcludePatterns(entityName) {
        return [
            "@odata",
            "_base",
            "createdon",
            "modifiedon",
            "createdby",
            "modifiedby",
            "owninguser",
            "owningteam",
            "owningbusinessunit",
            "versionnumber",
            "_ownerid_value",
            `${entityName}id`
        ];
    }

    function showError(formContext, msg) {
        formContext.openAlertDialog("Error", msg)
    }

    function getFieldByEntity(entityName) {
        if (!entityName) {
            return [];
        }

        const fieldsMap = {
            quote: [
                "@odata",
                "_base",
                "createdon",
                "modifiedon",
                "createdby",
                "modifiedby",
                "owninguser",
                "owningteam",
                "owningbusinessunit",
                "versionnumber",
                "_ownerid_value",
                "projectnumber",
                "quotenumber",
                "new_projectnumber",
                "new_isfolderprocessed",
                "new_foldercreationdate",
                "new_documentpath",
                "new_quotecreatedfromportal",
                "new_copyorder",
                "statecode",
                "statuscode",
                "customerid_account"
            ],
            salesorder: [
                "@odata", "_base", "createdon", "modifiedon", "createdby", "modifiedby",
                "owninguser", "owningteam", "owningbusinessunit", "versionnumber", "_ownerid_value",
                "quotenumber", "ordernumber", "projectnumber", "salesorderdetailid",
                "new_gpordernumber", "new_projectnumber", "new_quotedetailmapid", "new_opportunityproductmapid",
                "new_oppprodidmap", "new_productid", "customerid_account", "quotedetailid",
                "opportunityid", "new_quotenumber", "new_isfolderprocessed", "new_foldercreationdate",
                "new_documentpath", "new_current", "new_issvpmailsent", "new_depositrequired",
                "new_depositwaived", "new_datedepositreceived", "new_orderdepositamount",
                "new_depositbalanceremaining", "new_waiveddepositamount", "new_depositwaivedbyid",
                "new_newcustomer", "new_contractdrawingsapproveddate", "new_fabricationdrawingsissueddate",
                "new_fabricationdrawingsapproveddate", "datefulfilled", "new_creditapprovaldate",
                "new_depositreceiveddate", "requestdeliveryby", "new_requiredreleasetomanufacturing",
                "new_contractdrawingsissueddate", "new_stateshippicklist", "new_cityshippicklist",
                "shipto_line1", "new_jdeshiptonumber", "shipto_line2", "shipto_line3",
                "shipto_postalcode", "new_countyshippicklist", "new_countryshippicklist",
                "shipto_city", "shipto_stateorprovince", "shipto_country", "new_countyship",
                "shipto_addressid", "statecode", "statuscode", "new_requesteddate", "new_soldtophone", "_new_soldtocontactid_value", "new_soldtocontactid@odata.bind"
            ]
        };

        return fieldsMap[entityName] || [];
    }

    function getProductFieldByEntity(entityName) {
        if (!entityName) {
            return [];
        }

        const fieldsMap = {
            quotedetail: [
                "@odata",
                "_base",
                "createdon",
                "modifiedon",
                "createdby",
                "modifiedby",
                "owninguser",
                "owningteam",
                "owningbusinessunit",
                "versionnumber",
                "_ownerid_value",
                "quotenumber",
                "projectnumber",
                "new_opportunityproductmapid",
                "new_quotedetailmapid",
                "new_oppprodidmap",
                "new_productid",
                "quotedetailid",
                "customerid_account",

            ],
            salesorderdetail: [
                "@odata",
                "_base",
                "createdon",
                "modifiedon",
                "createdby",
                "modifiedby",
                "owninguser",
                "owningteam",
                "owningbusinessunit",
                "versionnumber",
                "_ownerid_value",
                "quotenumber",
                "projectnumber",
                "new_opportunityproductmapid",
                "new_quotedetailmapid",
                "new_oppprodidmap",
                "new_productid",
                "quotedetailid",
                "customerid_account",
                "requestdeliveryby"
            ]
        };

        return fieldsMap[entityName] || [];
    }

    async function onSalesPersonChange(formContext, fieldName, fieldNameToBind) {

        var formContext = formContext;
        var salesPersonLookup = formContext.getAttribute(fieldName);

        if (!salesPersonLookup || salesPersonLookup.getValue() === null) {
            formContext.getAttribute(fieldNameToBind).setValue(null);
            return;
        }

        var userId = salesPersonLookup.getValue()[0].id.replace(/[{}]/g, "");

        try {
            var user = await formContext.retrieveRecord("systemuser", userId, "?$select=new_territorynumber");
            if (user.new_territorynumber) {
                formContext.setFieldValue(fieldNameToBind, user.new_territorynumber);
            } else {
                formContext.setFieldValue(fieldNameToBind, null);
            }
        } catch (error) {
            console.error("Failed to retrieve System User: ", error.message);
        }
    }

    async function getMiles(originZip, destinationZip) {

        const azureapi = Quikrete.Common.AzureAPIURL;
        const url = azureapi + `/api/distance/CalculateMiles?origin=${originZip}&destination=${destinationZip}`;

        try {
            const response = await fetch(url);
            const data = await response.json();

            // Extract the value of "Distance " (with trailing space)
            const distanceStr = data["Distance"];

            if (!distanceStr) throw new Error("Distance not found in response");

            // Remove commas and " mi", then parse as integer
            const miles = parseInt(distanceStr.replace(/,/g, '').replace(/\s*mi/i, '').trim(), 10);

            return miles;
        } catch (error) {
            console.error("Error fetching or parsing distance:", error);
            return 0; // default/fallback value
        }
    }

    //This is DOm Manipulation because annotation entity not support ribbonworkbench
    function hideNotSubgridAddButtons(subgridName) {
        try {
            let attempts = 0;
            const intervalId = setInterval(() => {
                const buttons = window.top?.document?.querySelectorAll(
                    `#dataSetRoot_${subgridName} button[data-id*="Mscrm.SubGrid.annotation.AddExistingStandard"],
                     #dataSetRoot_${subgridName} button[data-id*="Mscrm.SubGrid.annotation.AddNewStandard"]`
                );

                if (buttons && buttons.length > 0) {
                    buttons.forEach(btn => {
                        btn.style.setProperty("display", "none", "important");
                        btn.setAttribute("disabled", "true");
                    });

                    // Only stop if weâ€™ve hidden BOTH target buttons
                    const stillVisible = window.top?.document?.querySelectorAll(
                        `#dataSetRoot_${subgridName} button[data-id*="Mscrm.SubGrid.annotation.AddExistingStandard"],
                         #dataSetRoot_${subgridName} button[data-id*="Mscrm.SubGrid.annotation.AddNewStandard"]`
                    );

                    if (!stillVisible) {
                        clearInterval(intervalId);
                    }
                }
                if (++attempts > 30) { // wait up to 15s
                    clearInterval(intervalId);
                }
            }, 500);
        } catch (e) {
        }
    }

    function hideActivitiesSubgridButton() {
        const target = window.top?.document?.querySelector("#__fluentPortalMountNode");
        if (!target) {
            return;
        }

        const observer = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                if (mutation.addedNodes.length > 0) {
                    hideTargetButtons(target);
                }
            });
        });

        // Observe only direct DOM changes under the div
        observer.observe(target, { childList: true, subtree: true });
    }

    function hideTargetButtons(root) {
        const buttons = root.querySelectorAll(
            `button[data-id*=".new_projectstatus"]`
            //,button[data-id*=".new_producttodo"]
        );

        if (buttons.length > 0) {
            buttons.forEach(btn => {
                const parent = btn.parentElement;
                parent?.style?.setProperty("display", "none", "important");
                parent?.setAttribute("disabled", "true");
            });
        }
    }

    function wait(ms) {
        const start = Date.now();
        while (Date.now() - start < ms) {
            // Just loop until the time has passed
        }
    }

    async function savePCFAndPopulateFieldonEntiy(formContext, e) {

        var productnumber = formContext.getFieldValue("new_productnumber");
        if (top.window?.pcfAPI?.validatepcf && typeof top.window.pcfAPI.validatepcf === "function") {
            const valid = await top.window.pcfAPI.validatepcf();

            if (!valid || valid.isValid !== true) {
                wait(100);
                e.getEventArgs().preventDefault();
                return;
            }
            var productType = valid.pamProductType.toLowerCase();
            var productCode = valid.productCode;
            var applicationcode = formContext.getFieldValue("new_applicationcode");
            var isrequired = await requiredSpecType(formContext, productType, productCode, applicationcode);
            if (isrequired) {
                var specValue = formContext.getFieldValue("new_spectype");
                if (specValue == null) {
                    formContext.makeFieldRequired("new_spectype", true);
                    formContext.ui.setFormNotification("Spec Type: Required fields must be filled in.", "ERROR", "spectype_error");
                    return;
                }
                formContext.ui.clearFormNotification("spectype_error");
            }

            // Now it's guaranteed valid & isValid = true
            if (valid.crmProductid) {

                var lookupItem = formContext.getFieldValue("productid");
                formContext.setFieldValue("new_productnumber", valid.productPartNumber);
                formContext.setFieldValue("new_productfamily", valid?.pamProductFamily);
                formContext.setFieldValue("new_producttype", valid?.pamProductType);
                formContext.setFieldValue("new_productsubtype", valid?.pamProductSubType);

                // 1. PAM Product Lookup
                formContext.getAttribute("new_pa_productid").setValue([
                    {
                        id: valid.pamProductId,
                        entityType: "crmgp_product"
                    }
                ]);

                //2 CRM Product lookup (productid)
                formContext.getAttribute("productid").setValue([
                    {
                        id: valid.crmProductid,
                        entityType: "product",
                    }
                ]);


                if (lookupItem == null || lookupItem[0] == null) {

                    //// 3. UOM lookup
                    formContext.getAttribute("uomid").setValue([
                        {
                            id: valid.uomid,
                            entityType: "uom",
                            name: valid.uomName
                        }
                    ]);

                    formContext.setFieldValue("new_productdescriptioneditable", valid.productDescription);

                    if (valid.productCode != 0)
                        formContext.setFieldValue("new_productcode", valid.productCode);
                }
                else if (lookupItem[0].id.replace(/[{}]/g, "").toLowerCase() !== valid.crmProductid.replace(/[{}]/g, "").toLowerCase()) {
                    //// 3. UOM lookup
                    formContext.getAttribute("uomid").setValue([
                        {
                            id: valid.uomid,
                            entityType: "uom",
                            name: valid.uomName
                        }
                    ]);

                    formContext.setFieldValue("new_productdescriptioneditable", valid.productDescription);

                    if (valid.productCode != 0)
                        formContext.setFieldValue("new_productcode", valid.productCode);
                }
            }
            top.pcfValidationPassed = valid;
        }
    }

    async function postSaveHandlerForPCF(formContext) {

        if (!top.pcfValidationPassed || top.pcfValidationPassed.isValid !== true) return;

        if (typeof top.window.pcfAPI.save === "function") {
            const parentEntity = formContext._entityName;
            const parentId = formContext.getCurrentRecordId();
            if (parentEntity == null || parentEntity == "" || parentId == null || parentId == "") {
                return;
            }
            await top.window.pcfAPI.save(parentEntity, parentId);
            setTimeout(async () => {
                formContext.data.refresh(false);
            }, 150);
        } else {
            console.warn("saveProductAttributes function not available.");
        }
    }

    async function handleSharePointFileTab(formContext) {
        try {
            const entityName = formContext._entityName;
            const allowedEntities = ["account", "opportunity", "salesorder", "quote"];
            if (!entityName || !allowedEntities.includes(entityName.toLowerCase())) {
                return;
            }
            const spFolderAttr = formContext.getAttribute("new_issharepointfolderprocessed");
            if (!spFolderAttr) {
                console.warn("Attribute new_issharepointfolderprocessed not found.");
                return;
            }
            const isSPFolderCreated = spFolderAttr.getValue();
            if (isSPFolderCreated) {
                const docTab = formContext.ui.tabs.get("documents_sharepoint");
                if (docTab) {
                    docTab.setVisible(true);
                }
            }


            if (!isSPFolderCreated) {

                // Check record age is 20 sec then and only trigger folder creation.
                var recordage = isOlderThanGivenMinutes(formContext,0.2);
                if (!recordage) {
                    console.log("Record is not older than 2 minutes. Skipping API call.");
                    return;
                }
                console.log("Updating record to trigger SharePoint integration");

                // Call Azure Function instead of update
                const recordId = formContext.data.entity._entityId.guid;
                const payload = {
                    "MessageName": "CreateSharePointFolder",
                    "InputParameters": [
                        {
                            "key": "Target",
                            "value": {
                                "__type": "Entity:http://schemas.microsoft.com/xrm/2011/Contracts",
                                "LogicalName": entityName,
                                "Id": recordId
                            }
                        }
                    ]
                };
                var result = await callAzureFunction(Quikrete.Common.AzureAPIURL + "/api/CreateSharePointFolderStructure" + Quikrete.Common.AzureAPICode,
                    payload
                );

                var folderid = getFolderId(result);
                // Show SharePoint tab after successful call
                const docTab = formContext.ui.tabs.get("documents_sharepoint");
                if (docTab && folderid != null) {
                    docTab.setVisible(true);
                }
            }
        } catch (e) {
            console.warn("Error in handleSharePointFileTab", e);
        }
    }

    function isOlderThanGivenMinutes(formContext, minutes) {
        const createdOn = formContext.getAttribute("createdon")?.getValue();
        if (!createdOn) return false;

        const now = new Date();
        const diffMs = now - createdOn; // milliseconds
        const totalMinutes = minutes * 60 * 1000;

        return diffMs >= totalMinutes;
    }

    function getFolderId(responseText) {
        const folderId = responseText?.match(/#(.*?)#/)?.[1] || null;

        // Validate GUID
        if (!folderId || folderId.trim() === "" || folderId === "00000000-0000-0000-0000-000000000000") {
            return null;
        }
        return folderId;
    }

    async function callAzureFunction(url, payload) {
        // Show loader (same pattern as CreateRecord)
        Quikrete.ProgressIndicator.Show("Please wait...");

        return new Promise(function (resolve, reject) {

            fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            })
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error("Azure Function call failed");
                    }
                    return response.text();
                })
                .then(function (result) {
                    Quikrete.ProgressIndicator.Close();
                    resolve(result);
                })
                .catch(function (error) {
                    Quikrete.ProgressIndicator.Close();
                    reject(error);
                });
        });
    };

    function filterLookup(formContext, lookupFieldName, filterId, fieldName) {
        var control = formContext.getControl(lookupFieldName);

        if (!control || !filterId) return;

        control.addPreSearch(function () {
            var fetchXml = `<filter type="and">
                                <condition attribute="${fieldName}" operator="eq" value="${filterId}" />
                            </filter>`;

            control.addCustomFilter(fetchXml);
        });
    }

    async function getRecordBuidFromLookup(formContext, lookupFieldName) {
        const lookup = formContext.getAttribute(lookupFieldName)?.getValue();

        if (!lookup || lookup.length === 0) {
            return '';
        }

        const entityName = lookup[0].entityType; // derived from lookup
        const entityId = lookup[0].id.replace(/[{}]/g, '');

        try {
            const result = await formContext.retrieveRecord(entityName, entityId, "?$select=_owningbusinessunit_value")
            return result?._owningbusinessunit_value || '';
        }
        catch (error) {
            console.error(`Failed to get BU for ${entityName}`, error);
            return '';
        }
    }
    async function requiredSpecType(formContext, productType, productCode, applicationCode) {
        //Task 11867: Spec Type: Should be required if segment = Stormwater

        let applicationCodeChar = "";

        if (applicationCode) {
            applicationCodeChar = getApplicationCode(applicationCode);
        }

        let fetchXml = null;
        let result = null;

        if (productCode && applicationCodeChar && applicationCodeChar.toUpperCase() === "K") {

            fetchXml = `<fetch>
                            <entity name='new_productcode'>
                                <attribute name='new_productcode' />
                                <attribute name='new_productcodedescription' />
                                <attribute name='new_productcodeid' alias='productcodeid' />
                                <filter>
                                <condition attribute='new_productcode' operator='eq' value='${productCode}' />
                                </filter>
                                <!-- REPORT LINE -->
                                <link-entity name='new_linename' from='new_linenameid' to='new_reportline' link-type='inner' alias='LN'>
                                <attribute name='new_name' alias='linename' />
                                <attribute name='new_linenameid' alias='linenameid' />
                                <!-- SEGMENT LINE EXCEPTIONS -->
                                <link-entity name='new_segmentlineexceptions' from='new_linename' to='new_linenameid' link-type='inner' alias='EX'>
                                    <!-- SEGMENT -->
                                    <link-entity name='new_segment' from='new_segmentid' to='new_segment' link-type='inner' alias='S'>
                                    <attribute name='new_segmentdescription' alias='segment' />
                                    <attribute name='new_segmentid' alias='segmentid' />
                                    </link-entity>
                                    <!-- SEGMENT GROUP -->
                                    <link-entity name='new_segmentgroup' from='new_segmentgroupid' to='new_segmentgroup' link-type='inner' alias='SG'>
                                    <attribute name='new_seggroupdescription' alias='segmentgroup' />
                                    <attribute name='new_segmentgroupid' alias='segmentgroupid' />
                                    <!-- SUPER SEGMENT -->
                                    <link-entity name='new_supersegment' from='new_segmentgroup' to='new_segmentgroupid' link-type='inner' alias='SP'>
                                        <attribute name='new_name' alias='supersegment' />
                                        <attribute name='new_supersegmentid' alias='supersegmentid' />
                                    </link-entity>
                                    </link-entity>
                                </link-entity>
                                </link-entity>
                            </entity>
                        </fetch>`;



            const encodedFetchXml = encodeURIComponent(fetchXml);
            result = await formContext.retrieveMultipleRecords("new_productcode", `?fetchXml=${encodedFetchXml}`);
        }

        if (productCode && (!result || result.length === 0)) {

            fetchXml = `<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                            <entity name='new_productcode'>
                            <attribute name='new_productcode' />
                            <attribute name='new_productcodedescription' />
                            <attribute name='new_productcodeid' alias='productcodeid' />
                            <filter>
                                <condition attribute='new_productcode' operator='eq' value='${productCode}' />
                            </filter>
                            <link-entity name='new_linename' from='new_linenameid' to='new_reportline' link-type='outer' alias='LN'>
                                <attribute name='new_name' alias='linename' />
                                <attribute name='new_linenameid' alias='linenameid' />
                                <link-entity name='new_segment' from='new_segmentid' to='new_segment' link-type='outer' alias='S'>
                                <attribute name='new_segmentdescription' alias='segment' />
                                <attribute name='new_segmentid' alias='segmentid' />
                                </link-entity>
                                <link-entity name='new_segmentgroup' from='new_segmentgroupid' to='new_segmentgroup' link-type='outer' alias='SG'>
                                <attribute name='new_seggroupdescription' alias='segmentgroup' />
                                <attribute name='new_segmentgroupid' alias='segmentgroupid' />
                                <link-entity name='new_supersegment' from='new_segmentgroup' to='new_segmentgroupid' link-type='outer' alias='SP'>
                                    <attribute name='new_name' alias='supersegment' />
                                    <attribute name='new_supersegmentid' alias='supersegmentid' />
                                </link-entity>
                                </link-entity>
                            </link-entity>
                            </entity>
                        </fetch>`;

            const encodedFetchXml = encodeURIComponent(fetchXml);
            result = await formContext.retrieveMultipleRecords("new_productcode", `?fetchXml=${encodedFetchXml}`);
        }

        if (result && result.length > 0) {
            var segment = result[0]?.segment;

            if (segment?.toLowerCase().includes("stormwater"))
                return true;
        }
        return false;
    }

    function getApplicationCode(applicationCode) {

        let value = "";

        if (applicationCode && applicationCode.includes("(")) {

            const startIndex = applicationCode.indexOf("(") + 1;

            // Get up to 5 characters safely after '('
            const length = Math.min(5, applicationCode.length - startIndex);

            value = applicationCode
                .substr(startIndex, length)
                .replace(")", "");
        }
        else {
            value = "O";
        }

        // Equivalent of RIGHT(..., 1)
        return value.length > 0
            ? value.charAt(value.length - 1)
            : "";
    }

    return {
        GetDetailsByZipCode: getDetailsByZipCode,
        ValidateAndFormatFaxPhoneNumber: validateAndFormatFaxPhoneNumber,
        GetDetailsByZipCodeLookup: getDetailsByZipCodeLookup,
        CloneRecord: cloneRecord,
        transactionalCopy: transactionalCopy,
        onSalesPersonChange: onSalesPersonChange,
        GetMiles: getMiles,
        CloneProductAttribute: cloneProductAttribute,
        UpdateProductAttribute: updateProductAttribute,
        HideNotSubgridAddButtons: hideNotSubgridAddButtons,
        HideActivitiesSubgridButton: hideActivitiesSubgridButton,
        SavePCFData: savePCFAndPopulateFieldonEntiy,
        PostSaveHandlerForPCF: postSaveHandlerForPCF,
        HandleSharePointFileTab: handleSharePointFileTab,
        FilterLookup: filterLookup,
        GetRecordBuidFromLookup: getRecordBuidFromLookup
    }
}());