﻿var Quikrete = Quikrete || {};

Quikrete.Task = (function () {
    var eventsAttached = false;
    var formContext = null;

    function init(executionContext) {
        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        top.formContext = formContext;
        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;
        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);

        if (formContext.getAttribute("regardingobjectid") != null)
            formContext.getAttribute("regardingobjectid").addOnChange(onChangeOfRegardingobject);
    }

    async function formOnLoad() {
        await setDataInField();
        await onChangeOfRegardingobject();
        formContext.getControl("new_category").removeOption(3);
    }

    async function formOnSave() {
        var regarding = formContext.getFieldValue("regardingobjectid");
        if (regarding != null) {
            var entitytype = regarding[0].entityType;
            //var entityid=
            var lineitem = null;

            if (entitytype === 'opportunity') {
                lineitem = formContext.getFieldValue("new_projectproductlineitem");
            }
            else if (entitytype === 'quote') {
                lineitem = formContext.getFieldValue("new_quoteproductlineitem");
            }
            else if (entitytype === 'salesorder') {
                lineitem = formContext.getFieldValue("new_orderproductlineitem");
            }

            if (lineitem != null) {
                var lineentitytype = lineitem[0].entityType;
                var lineentityid = lineitem[0].id.replace("{", "").replace("}", "").toLowerCase();
                var lineItemRecord = await formContext.retrieveRecord(lineentitytype, lineentityid);

                var sequenceValue = (lineentitytype == "opportunityproduct" ? lineItemRecord.new_sequencenumber : lineItemRecord.lineitemnumber);

                formContext.setFieldValue("new_sequence", sequenceValue);
            } else {
                formContext.setFieldValue("new_sequence", null);
            }
        }
    }

    async function setDataInField() {

        var formType = formContext.getFormType();

        if (formType === Quikrete.Common.FormType.Create) {
            formContext.setFieldValue("scheduledend", new Date());
        }

        var regarding = formContext.getFieldValue("regardingobjectid");

        if (regarding != null) {
            var regardingId = regarding[0].id.replace("{", "").replace("}", "").toLowerCase();
            var regardingEntityName = regarding[0].entityType;

            if (regardingEntityName === 'opportunity' || regardingEntityName === 'quote' || regardingEntityName === 'salesorder') {
                var regardingRecord = await formContext.retrieveRecord(regardingEntityName, regardingId);
                var ownerId = regardingRecord._owningbusinessunit_value;
                if (ownerId == Quikrete.Common.ContechBU.toLowerCase()) {
                    var tab = formContext.ui.tabs.get("task_tab");
                    var section = tab.sections.get("section_todo");
                    section.setVisible(true);
                }
            }
        }
    }

    async function onChangeOfRegardingobject() {
        var regarding = formContext.getFieldValue("regardingobjectid");

        if (regarding != null) {
            var regardingEntityName = regarding[0].entityType.toLowerCase();

            if (regardingEntityName == 'opportunity') {
                formContext.makeFieldVisible("new_quoteproductlineitem", false);
                formContext.makeFieldVisible("new_orderproductlineitem", false);
            }
            if (regardingEntityName == 'quote') {
                formContext.makeFieldVisible("new_projectproductlineitem", false);
                formContext.makeFieldVisible("new_orderproductlineitem", false);
            }
            if (regardingEntityName == 'salesorder') {
                formContext.makeFieldVisible("new_projectproductlineitem", false);
                formContext.makeFieldVisible("new_quoteproductlineitem", false);
            }
        }
    }

    async function cloneRecord(primaryControl) {
        console.log(primaryControl);

        const sourceEntity = "task";

        const productEntityFields = {
            subject: formContext.getFieldValue("subject"),
            scheduledend: formContext.getFieldValue("scheduledend"),
            description: formContext.getFieldValue("description"),
            statecode: formContext.getFieldValue("statecode"),
            new_category: formContext.getFieldValue("new_category"),
            prioritycode: formContext.getFieldValue("prioritycode"),
            new_productdescription: formContext.getFieldValue("new_productdescription"),
            new_sequence: formContext.getFieldValue("new_sequence"),
            actualdurationminutes: formContext.getFieldValue("actualdurationminutes"),

            projectproductlineitem: formContext.getFieldValue("new_projectproductlineitem") != null ? formContext.getFieldValue("new_projectproductlineitem")[0] : null,
            quoteproductlineitem: formContext.getFieldValue("new_quoteproductlineitem") != null ? formContext.getFieldValue("new_quoteproductlineitem")[0] : null,
            orderproductlineitem: formContext.getFieldValue("new_orderproductlineitem") != null ? formContext.getFieldValue("new_orderproductlineitem")[0] : null,
            regardingobject: formContext.getFieldValue("regardingobjectid") != null ? formContext.getFieldValue("regardingobjectid")[0] : null,
            owner: formContext.getFieldValue("ownerid") != null ? formContext.getFieldValue("ownerid")[0] : null,
        };

        var projectproductentityname = productEntityFields?.projectproductlineitem?.entityType;
        var projectproductentityid = productEntityFields?.projectproductlineitem?.id.replace('{', '').replace('}', '');
        var quoteproductentityname = productEntityFields?.quoteproductlineitem?.entityType;
        var quoteproductentityid = productEntityFields?.quoteproductlineitem?.id.replace('{', '').replace('}', '');
        var orderproductentityname = productEntityFields?.orderproductlineitem?.entityType;
        var orderproductentityid = productEntityFields?.orderproductlineitem?.id.replace('{', '').replace('}', '');

        var ownerentityname = productEntityFields?.owner?.entityType;
        var ownerid = productEntityFields?.owner?.id.replace('{', '').replace('}', '');

        var regardingid = productEntityFields?.regardingobject?.id.replace('{', '').replace('}', '');
        var regardingentityname = productEntityFields?.regardingobject?.entityType;

        var regardigEntityMetaData = null;

        if (regardingid) {
            regardigEntityMetaData = await formContext.getentityMetadata(regardingentityname, []);
        }

        var ownerEntityMetaData = null;
        if (ownerid) {
            ownerEntityMetaData = await formContext.getentityMetadata(ownerentityname, []);
        }

        const cloneRecordField = {
            subject: productEntityFields.subject ?? '',
            description: productEntityFields.description ?? '',
            prioritycode: productEntityFields.prioritycode,
            scheduledend: productEntityFields.scheduledend,
            new_category: productEntityFields.new_category,
            new_productdescription: productEntityFields.new_productdescription ?? '',
            new_sequence: productEntityFields.new_sequence,
            actualdurationminutes: productEntityFields.actualdurationminutes
        };

        //Regarding Field 
        if (regardingid) {
            cloneRecordField[`regardingobjectid_${regardigEntityMetaData.LogicalName}_task@odata.bind`] = `/${regardigEntityMetaData?.EntitySetName}(${regardingid})`;
        }

        //Owner Field 
        if (ownerid) {
            cloneRecordField["ownerid_task@odata.bind"] = `/${ownerEntityMetaData?.EntitySetName}(${ownerid})`;
        }

        //Product Project
        if (projectproductentityid) {
            cloneRecordField["new_ProjectProductLineItem_Task@odata.bind"] = `/opportunityproducts(${projectproductentityid})`;
        }

        //Product quote
        if (quoteproductentityid) {
            cloneRecordField["new_QuoteProductLineItem_Task@odata.bind"] = `/quotedetails(${quoteproductentityid})`;
        }

        //Product order
        if (orderproductentityid) {
            cloneRecordField["new_OrderProductLineItem_Task@odata.bind"] = `/salesorderdetails(${orderproductentityid})`;
        }

        try {
            const cloneRecordID = await formContext.createRecord(sourceEntity, cloneRecordField);

            var entityFormOptions = {
                entityName: "task",
                entityId: cloneRecordID.id,
                openInNewWindow: true,
                navbar: "off",
                height: 600,
                width: 800
            };

            formContext.openForm(entityFormOptions);
        } catch (error) {
            console.error("Error while cloning the record: ", error);
        }
    }

    return {
        Init: init,
        OnChangeOfRegardingobject: onChangeOfRegardingobject,
        CloneRecord: cloneRecord
    }
}());