﻿var Quikrete = Quikrete || {};
var eventsAttached = false;
var formContext = null;

// ============================================================================
// GLOBAL CONSTANTS
// ============================================================================
const ENTITY_NAMES = {
    SALES_ORDER: "salesorder",
    ACCOUNT: "account",
    OPPORTUNITY: "opportunity",
    SALES_COMMISSION: "crmgp_salescommission",
    ZIPCODE: "new_zipcode",
    TERRITORY_MAP: "crm_territorymap",
    LOG_TABLE: "new_logtable",
    WebResourceName: "WebResource_SalesCommission"
};

// If your entity set names differ for binds, map them here:
const ENTITY_SETS = {
    ZIPCODE: "new_zipcodes",
    SALES_COMMISSION: "crmgp_salescommissions",
    LOG_TABLE: "new_logtables"
};

Quikrete.SalesCommission = (function () {
    function init(e) {
        formContext = e.getFormContext();
        top.formContext = formContext;
        console.log("Form Context saved:", formContext);
        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        //formContext.data.entity.addOnSave(formOnSave);
    }

    // ------------------------------------------------------------------------
    // Helpers: normalization, binds, logging
    // ------------------------------------------------------------------------
    function toBool(val) {
        if (val === true || val === 1 || val === "1" || val === "true" || val === "True") return true;
        return false;
    }

    /**
     * Accepts an entity logical name or full entity set name.
     * Prefer passing entity set names from ENTITY_SETS for custom entities.
     */
    function bindLookup(entitySetOrName, id) {
        if (!id) return null;
        const rawId = typeof id === "object" ? (id.id || id.new_zipcodeid || id.newzipcodeid || id.new_zipcodeid) : id;
        if (!rawId) return null;

        const cleanId = rawId.replace(/[{}]/g, "").trim();
        if (!cleanId) return null;

        // prefer explicit entity sets if provided in map
        let entitySet = entitySetOrName;
        if (!entitySet) entitySet = entitySetOrName;
        // If passed logical name and it has a mapping in ENTITY_SETS, use it
        if (ENTITY_SETS[entitySetOrName?.toUpperCase()]) {
            entitySet = ENTITY_SETS[entitySetOrName.toUpperCase()];
        } else if (!entitySetOrName.endsWith("s")) {
            entitySet = `${entitySetOrName}s`;
        }
        return `/${entitySet}(${cleanId})`;
    }

    function normalizeZip(raw) {
        if (!raw) return null;
        if (typeof raw === "object") {
            return {
                new_zipcode: raw.new_zipcode || raw["_new_zipaddress1_lookup_value@OData.Community.Display.V1.FormattedValue"] || raw.new_zipcode || raw.name || null,
                new_zipcodeid: (raw.new_zipcodeid || raw["_new_zipaddress1_lookup_value"] || raw.id) || null,
                etag: raw.etag || raw["@odata.etag"] || null
            };
        }
        // raw string considered as id
        return {
            new_zipcode: null,
            new_zipcodeid: raw,
            etag: null
        };
    }

    async function serverLog(message, orderNumber, data) {
        console.log("[LOG]", message, orderNumber, data || '');
        try {
            const logData = {
                new_logdata: message + (data ? ("\n" + JSON.stringify(data)) : ""),
                new_ordernumber: orderNumber || null,
                new_datetime: new Date().toISOString()
            };
            // Attempt to log to CRM log table (uncomment if you want server logs)
            // await Xrm.WebApi.createRecord(ENTITY_NAMES.LOG_TABLE, logData);
        } catch (e) {
            console.warn("Failed to write server log:", e);
        }
    }

    async function logError(error, orderNumber) {
        try {
            await serverLog(`Error: ${error.message}`, orderNumber, { stack: error.stack });
        } catch (e) {
            console.error("Error writing log", e);
        }
    }

    // ------------------------------------------------------------------------
    // Try read web resource values (unchanged)
    // ------------------------------------------------------------------------

    async function tryGetSalesCommissionValues(executionContext) {
        const formContextLocal = executionContext.getFormContext();
        const webResourceName = ENTITY_NAMES.WebResourceName; // "WebResource_SalesCommission";
        const wrCtrl = formContextLocal.getControl(webResourceName);
        if (!wrCtrl) {
            console.log("Web resource control not found.");
            return {};
        }
        const section = wrCtrl.getParent && wrCtrl.getParent();
        const tab = section && section.getParent && section.getParent();
        if (!tab || typeof tab.getVisible !== "function" || !tab.getVisible()) {
            console.log("Sales Commission tab not visible → web resource not loaded.");
            return {};
        }
        try {
            const wrWindow = await wrCtrl.getContentWindow();
            if (!wrWindow || !wrWindow.document || wrWindow.document.readyState !== "complete") {
                console.log("Web resource not fully loaded → skip.");
                return {};
            }
            return getSalesCommissionValues(wrWindow);
        } catch (e) {
            console.log("Web resource not loaded yet → skip.", e);
            return {};
        }
    }

    function getSalesCommissionValues(wrWindow) {
        return {
            // SE Territories
            seSpec1Territory: wrWindow.document.getElementById("se-spec1-territory")?.value || null,
            seSpec2Territory: wrWindow.document.getElementById("se-spec2-territory")?.value || null,
            seSell1Territory: wrWindow.document.getElementById("se-sell1-territory")?.value || null,
            seSell2Territory: wrWindow.document.getElementById("se-sell2-territory")?.value || null,
            seDest1Territory: wrWindow.document.getElementById("se-dest1-territory")?.value || null,
            seSpec30: wrWindow.document.getElementById("se-spec30")?.checked ?? (wrWindow.document.getElementById("se-spec30")?.value ?? false),

            // BC Territories
            bcSpec1Territory: wrWindow.document.getElementById("bc-spec1-territory")?.value || null,
            bcSpec2Territory: wrWindow.document.getElementById("bc-spec2-territory")?.value || null,
            bcSell1Territory: wrWindow.document.getElementById("bc-sell1-territory")?.value || null,
            bcSell2Territory: wrWindow.document.getElementById("bc-sell2-territory")?.value || null,
            bcDest1Territory: wrWindow.document.getElementById("bc-dest1-territory")?.value || null,
            bcSpec30: wrWindow.document.getElementById("bc-spec30")?.checked ?? (wrWindow.document.getElementById("bc-spec30")?.value ?? false),

            // SWC Territories
            swcSpec1Territory: wrWindow.document.getElementById("swc-spec1-territory")?.value || null,
            swcSpec2Territory: wrWindow.document.getElementById("swc-spec2-territory")?.value || null,
            swcSell1Territory: wrWindow.document.getElementById("swc-sell1-territory")?.value || null,
            swcSell2Territory: wrWindow.document.getElementById("swc-sell2-territory")?.value || null,
            swcDest1Territory: wrWindow.document.getElementById("swc-dest1-territory")?.value || null,
            swcSpec30: wrWindow.document.getElementById("swc-spec30")?.checked ?? (wrWindow.document.getElementById("swc-spec30")?.value ?? false),

            isDirtySalesCommissionFlag: wrWindow.isDirtySalesCommission,
        }
    }

    async function commissionSave(executionContext) {
        await onSalesOrderSave(executionContext);
    }

    // ------------------------------------------------------------------------
    // Main entry: on save flow
    // ------------------------------------------------------------------------
    async function onSalesOrderSave(executionContext) {

        const formContext = executionContext.getFormContext();

        // Extract parameters from form
        const paramsOrder = {
            merlinOrderNo: formContext.getAttribute("ordernumber")?.getValue(),
            fromSystem: "Merlin",
            divisionOrderNo: formContext.getAttribute("ordernumber")?.getValue(),

            // ISR Territories
            isrStormTerritory: formContext.getAttribute("new_isrstormterritory")?.getValue(),
            isrPipeTerritory: formContext.getAttribute("new_isrpipeterritory")?.getValue(),

            // Manual Overrides
            manualShipToZipCode: formContext.getAttribute("new_zipaddress1_lookup")?.getValue(),
            manualOrderAccountZipCode: null,

            // Metadata
            modifiedBy: Xrm.Utility.getGlobalContext().userSettings.userName,
            customerId: formContext.getAttribute("customerid")?.getValue()
        };

        const paramsSalesCommison = await tryGetSalesCommissionValues(executionContext);
        if (!paramsSalesCommison.isDirtySalesCommissionFlag) {
            reloadWebResourceOnSave(executionContext);
            return;
        }

        // Show progress indicator
        Xrm.Utility.showProgressIndicator("Processing Sales Commission...");
        try {
            const finalParams = { ...paramsOrder, ...paramsSalesCommison };
            // normalize lookup zip if present
            if (finalParams.manualShipToZipCode) finalParams.manualShipToZipCode = normalizeZip(finalParams.manualShipToZipCode[0]);

            const result = await insertSalesCommission(finalParams);

            Xrm.Utility.closeProgressIndicator();

            if (result.success) {
                reloadWebResourceOnSave(executionContext);
            }
        } catch (error) {
            Xrm.Utility.closeProgressIndicator();
            Xrm.Navigation.openAlertDialog({
                text: "An error occurred: " + error.message,
                title: "Error"
            });
        }
    }
    //reload Web resource
    function reloadWebResourceOnSave(executionContext) {
        const formContext = executionContext.getFormContext();
        const wrControl = formContext.getControl(ENTITY_NAMES.WebResourceName);
        if (wrControl) {
            wrControl.getContentWindow().then(function (cw) {
                cw.location.reload();
            });
        }

    }

    // ============================================================================
    // MAIN ENTRY FUNCTION
    // ============================================================================

    /**
     * Main function to insert or update Sales Commission
     * @param {Object} params - Input parameters
     * @returns {Promise<Object>} Result object with success status
     */
    async function insertSalesCommission(params) {
        try {
            logInfo('Starting Sales Commission process', params.merlinOrderNo);

            // Step 1: Validate business unit (Rinker check)
            if (params.merlinOrderNo) {
                const isValidBU = await validateBusinessUnit(params.merlinOrderNo);
                if (!isValidBU) {
                    logInfo('Invalid Business Unit - Exiting', params.merlinOrderNo);
                    return { success: false, message: "Invalid Business Unit" };
                }
            }

            // Step 2: Get zip codes
            const zipCodes = await getZipCodes(params);
            logInfo('Zip codes retrieved', params.merlinOrderNo, zipCodes);

            //TODO UnComment for BC EXCEPTION RULE
            // Step 3: Check BC Exception Rule (now implemented)
            //const bcException = await checkBCException(finalParams, zipCodes);
            //if (bcException.isException) {
            //    // Map returned territory zips/territories into params for later create/update logic
            //    finalParams.bcSpec1Territory = bcException.BCSPEC;
            //    finalParams.bcDest1Territory = bcException.BCDEST;
            //    finalParams.bcSell1Territory = bcException.BCSELL;
            //    finalParams._bcDestTerritory = bcException.BCDESTTerritory;
            //    finalParams._bcSpecTerritory = bcException.BCSPECTerritory;
            //    finalParams._bcSellTerritory = bcException.BCSELLTerritory;
            //    logInfo('BC Exception applied', finalParams.merlinOrderNo, bcException);
            //}

            // Step 4: Validate all territories
            const territoryValidation = await validateAllTerritories(params, zipCodes);
            logInfo('Territory validation complete', params.merlinOrderNo);

            // Step 5: Check if record exists
            const existingRecord = await findExistingSalesCommission(params);

            if (existingRecord) {
                // Update existing record
                await updateSalesCommission(existingRecord.crmgp_salescommissionid, territoryValidation, params);
                logInfo('Sales Commission updated', params.merlinOrderNo, existingRecord.crmgp_salescommissionid);
            } else {
                // Create new record
                const recordId = await createSalesCommission(territoryValidation, params);
                logInfo('Sales Commission created', params.merlinOrderNo, recordId);
            }

            // Step 6: Call additional update procedure for BC Exception Rule
            //await updateSalesCommissionAdditional(params, zipCodes);

            return {
                success: true,
                message: "Sales Commission processed successfully",
                recordId: existingRecord?.crmgp_salescommissionid || null
            };

        } catch (error) {
            console.error("Error in insertSalesCommission:", error);
            await logError(error, params.merlinOrderNo);
            return {
                success: false,
                message: error.message,
                error: error
            };
        }
    }

    // ============================================================================
    // BUSINESS UNIT VALIDATION
    // ============================================================================

    async function validateBusinessUnit(merlinOrderNo) {
        try {
            const query = `?$select=owningbusinessunit&$filter=ordernumber eq '${merlinOrderNo}'`;
            const result = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.SALES_ORDER, query);

            if (result.entities.length > 0) {
                const buId = result.entities[0]["_owningbusinessunit_value"];
                return buId?.toUpperCase() === Quikrete.Common.ContechBU;
            }
            return false;
        } catch (error) {
            console.error("Error validating business unit:", error);
            return false;
        }
    }

    // ============================================================================
    // ZIP CODE RETRIEVAL
    // ============================================================================

    async function getZipCodes(params) {
        const zipCodes = { shipToZipCode: null, accountZipCode: null, projectBaseZipCode: null };

        try {
            if ((params.fromSystem === 'Merlin' || params.fromSystem === 'OE') && params.merlinOrderNo) {
                // ensure convertLookupToZipRecord runs first; only call getShipToZip if it's null/undefined
                zipCodes.shipToZipCode = params.manualShipToZipCode ?? await getShipToZipCode(params.merlinOrderNo);
                zipCodes.accountZipCode = await getAccountZipCode(params.merlinOrderNo, params.customerId[0]?.id);
                zipCodes.projectBaseZipCode = await getProjectBaseZipCode(params.merlinOrderNo);
            } else if (params.fromSystem === 'OE' && !params.merlinOrderNo) {
                zipCodes.shipToZipCode = await getJDEShipToZip(params.divisionOrderNo);
                zipCodes.accountZipCode = await getJDEAccountZip(params.divisionOrderNo);
            }
            return zipCodes;
        } catch (error) {
            console.error("Error getting zip codes:", error);
            throw error;
        }
    }
    async function convertLookupToZipRecord(lookupValue) {
        if (!lookupValue || !lookupValue.id) return null;

        // remove braces and normalize GUID
        const cleanedId = (lookupValue.id || lookupValue).toString().replace(/[{}]/g, "").toLowerCase();
        return { "@odata.etag": null, new_zipcode: lookupValue.name || null, new_zipcodeid: cleanedId };
    }

    //Order ZipCode
    async function getShipToZipCode(merlinOrderNo) {
        try {
            const query = `?$select=_new_zipaddress1_lookup_value&$filter=ordernumber eq '${merlinOrderNo}'`;
            const result = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.SALES_ORDER, query);
            if (result.entities.length === 0) return null;

            const entity = result.entities[0];
            const formattedKey = "_new_zipaddress1_lookup_value@OData.Community.Display.V1.FormattedValue";
            return normalizeZip({
                new_zipcode: entity[formattedKey] || null,
                new_zipcodeid: entity["_new_zipaddress1_lookup_value"],
                etag: entity["@odata.etag"] || null
            });

        } catch (error) {
            console.error("Error getting ship-to zip code:", error);
            return null;
        }
    }

    //Order's Account' Zipcode
    async function getAccountZipCode(merlinOrderNo, customerid) {
        try {
            let accountId = null;
            if (customerid) {
                accountId = customerid
            } else {
                const orderQuery = `?$select=_customerid_value&$filter=ordernumber eq '${merlinOrderNo}'`;
                const orderResult = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.SALES_ORDER, orderQuery);
                if (orderResult.entities.length > 0 && orderResult.entities[0]["_customerid_value"]) {
                    accountId = orderResult.entities[0]["_customerid_value"];
                }
            }
            if (accountId != null) {

                const account = await Xrm.WebApi.retrieveRecord(ENTITY_NAMES.ACCOUNT, accountId, "?$select=_new_zipaddress1_lookup_value");
                if (!account) return null;

                const formattedKey = "_new_zipaddress1_lookup_value@OData.Community.Display.V1.FormattedValue";

                return normalizeZip({
                    new_zipcode: account[formattedKey] || null,
                    new_zipcodeid: account["_new_zipaddress1_lookup_value"] || null,
                    etag: account["@odata.etag"] || null
                });
            }
            return null;
        } catch (error) {
            console.error("Error getting account zip code:", error);
            return null;
        }
    }

    //Order's Project's Account's Zipcode
    async function getProjectBaseZipCode(merlinOrderNo) {
        try {
            const query = `?$select=_opportunityid_value&$filter=ordernumber eq '${merlinOrderNo}'`;
            const orderResult = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.SALES_ORDER, query);

            if (orderResult.entities.length > 0 && orderResult.entities[0]["_opportunityid_value"]) {
                const opportunityId = orderResult.entities[0]["_opportunityid_value"];
                const oppQuery = `?$select=_customerid_value`;
                const opportunity = await Xrm.WebApi.retrieveRecord(ENTITY_NAMES.OPPORTUNITY, opportunityId, oppQuery);

                if (opportunity["_customerid_value"]) {
                    const account = await Xrm.WebApi.retrieveRecord(ENTITY_NAMES.ACCOUNT, opportunity["_customerid_value"], "?$select=_new_zipaddress1_lookup_value");
                    if (!account) return null;

                    const formattedKey = "_new_zipaddress1_lookup_value@OData.Community.Display.V1.FormattedValue";
                    return normalizeZip({
                        new_zipcode: account[formattedKey] || null,
                        new_zipcodeid: account["_new_zipaddress1_lookup_value"] || null,
                        etag: account["@odata.etag"] || null
                    });
                }
            }
            return null;
        } catch (error) {
            console.error("Error getting project base zip code:", error);
            return null;
        }
    }

    // ============================================================================
    // TERRITORY VALIDATION
    // ============================================================================

    async function validateAllTerritories(params, zipCodes, paramsOrder) {
        const validation = {
            seSpec1: await validateTerritory('SE', 'Spec1', params.seSpec1Territory, zipCodes.projectBaseZipCode || zipCodes.shipToZipCode, params),
            seSell1: await validateTerritory('SE', 'Sell1', params.seSell1Territory, zipCodes.accountZipCode, params),
            seDest1: await validateTerritory('SE', 'Dest1', params.seDest1Territory, zipCodes.shipToZipCode, params),
            seSpec2: await validateTerritory('SE', 'Spec2', params.seSpec2Territory, zipCodes.projectBaseZipCode || zipCodes.shipToZipCode, params),
            seSell2: await validateTerritory('SE', 'Sell2', params.seSell2Territory, zipCodes.accountZipCode, params),

            bcSpec1: await validateTerritory('BC', 'Spec1', params.bcSpec1Territory, zipCodes.projectBaseZipCode || zipCodes.shipToZipCode, params),
            bcSell1: await validateTerritory('BC', 'Sell1', params.bcSell1Territory, zipCodes.accountZipCode, params),
            bcDest1: await validateTerritory('BC', 'Dest1', params.bcDest1Territory, zipCodes.shipToZipCode, params),
            bcSpec2: await validateTerritory('BC', 'Spec2', params.bcSpec2Territory, zipCodes.projectBaseZipCode || zipCodes.shipToZipCode, params),
            bcSell2: await validateTerritory('BC', 'Sell2', params.bcSell2Territory, zipCodes.accountZipCode, params),

            swcSpec1: await validateTerritory('SWC', 'Spec1', params.swcSpec1Territory, zipCodes.projectBaseZipCode || zipCodes.shipToZipCode, params),
            swcSell1: await validateTerritory('SWC', 'Sell1', params.swcSell1Territory, zipCodes.accountZipCode, params),
            swcDest1: await validateTerritory('SWC', 'Dest1', params.swcDest1Territory, zipCodes.shipToZipCode, params),
            swcSpec2: await validateTerritory('SWC', 'Spec2', params.swcSpec2Territory, zipCodes.projectBaseZipCode || zipCodes.shipToZipCode, params),
            swcSell2: await validateTerritory('SWC', 'Sell2', params.swcSell2Territory, zipCodes.accountZipCode, params),
        };
        return validation;
    }

    async function validateTerritory(segment, type, territoryNumber, zipCode, params) {
        if (!territoryNumber) {
            return { zipCode: null, isOverridden: 0, overriddenDate: null };
        }
        try {
            const fieldName = getSegmentFieldName(segment);
            const territoryFilter = isNaN(Number(territoryNumber)) ? `'${territoryNumber}'` : territoryNumber;
            const zip = normalizeZip(zipCode);
            const zipFilter = zip && (zip.new_zipcode || zip.new_zipcodeid) ? (zip.new_zipcode ? `'${zip.new_zipcode}'` : `'${zip.new_zipcodeid}'`) : null;

            if (!zipFilter) {
                return await checkHistoricalOverride(segment, type, territoryNumber, zip, params);
            }

            const matchQuery = `?$filter=${fieldName} eq ${territoryFilter} and new_zipcode eq ${zipFilter}&$count=true`;
            const matchResult = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.ZIPCODE, matchQuery);
            if (matchResult.entities.length > 0) {
                return { zipCode: zip, isOverridden: 0, overriddenDate: null };
            }
            return await checkHistoricalOverride(segment, type, territoryNumber, zip, params);
        } catch (error) {
            console.error(`Error validating territory ${segment}-${type}:`, error);
            throw error;
        }
    }

    async function checkHistoricalOverride(segment, type, territoryNumber, zipCode, params) {
        try {
            const existingRecord = await findExistingSalesCommission(params);

            if (!existingRecord) {
                const correctZipCode = await findCorrectZipCodeForTerritory(segment, territoryNumber);
                return { zipCode: normalizeZip(correctZipCode), isOverridden: 1, overriddenDate: new Date().toISOString() };
            }

            const fieldPrefix = `${segment.toLowerCase()}${type.toLowerCase()}`;
            const previousZipCode = existingRecord[`_crmgp_${fieldPrefix}zipcodeid_value@OData.Community.Display.V1.FormattedValue`];
            const previousOverridden = existingRecord[`crmgp_isoverridden${fieldPrefix}`];
            const overriddenDate = existingRecord[`crmgp_isoverriddendate${fieldPrefix}`] || existingRecord.modifiedon;

            const wasValidHistorically = await checkTerritoryMapHistory(territoryNumber, zipCode, overriddenDate);

            if (wasValidHistorically) {
                if (previousZipCode === (zipCode?.new_zipcode || zipCode?.new_zipcodeid) && previousOverridden === true) {
                    return { zipCode: zipCode, isOverridden: 1, overriddenDate: overriddenDate };
                } else {
                    return { zipCode: zipCode, isOverridden: 1, overriddenDate: existingRecord.modifiedon };
                }
            } else {
                const correctZipCode = await findCorrectZipCodeForTerritory(segment, territoryNumber);
                if (previousZipCode != (correctZipCode?.new_zipcode)) {
                    return { zipCode: normalizeZip(correctZipCode), isOverridden: 1, overriddenDate: new Date().toISOString() };
                } else {
                    if ((previousZipCode == zipCode.new_zipcode)) {
                        return { zipCode: normalizeZip(zipCode), isOverridden: 0, overriddenDate: new Date().toISOString() };
                    }
                    else {
                        const overrrideZipCode = await findCorrectZipCodeForTerritory(segment, territoryNumber);
                        return { zipCode: normalizeZip(overrrideZipCode), isOverridden: 1, overriddenDate: new Date().toISOString() };
                    }
                }
            }
        } catch (error) {
            console.error("Error checking historical override:", error);
            throw error;
        }
    }

    async function checkTerritoryMapHistory(territoryNumber, zipCode, checkDate) {
        try {
            const zip = normalizeZip(zipCode);
            if (!zip || !zip.new_zipcodeid) return false;
            const date = new Date(checkDate).toISOString();
            const territoryFilter = isNaN(Number(territoryNumber)) ? `'${territoryNumber}'` : territoryNumber;

            const query = `?$filter=crm_territorynumber eq ${territoryFilter} and _crm_zipcodeid_value eq '${zip.new_zipcodeid}' and crm_effectivestartdate le ${date} and crm_effectiveenddate ge ${date}&$count=true`;
            const result = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.TERRITORY_MAP, query);
            return result.entities.length > 0;
        } catch (error) {
            console.error("Error checking territory map history:", error);
            return false;
        }
    }

    async function findCorrectZipCodeForTerritory(segment, territoryNumber) {
        try {
            const fieldName = getSegmentFieldName(segment);
            const filterTerritory = isNaN(Number(territoryNumber)) ? `'${territoryNumber}'` : territoryNumber;
            const query = `?$select=new_zipcode&$filter=${fieldName} eq ${filterTerritory}&$orderby=new_zipcode asc&$top=1`;
            const result = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.ZIPCODE, query);
            return result.entities.length > 0 ? result.entities[0] : null;
        } catch (error) {
            console.error("Error finding correct zip code:", error);
            return null;
        }
    }

    // ============================================================================
    // BC EXCEPTION CHECK
    // ============================================================================
    // ============================================================================
    // BC EXCEPTION CHECK (REPLACED WITH CLIENT-SIDE TRANSLATION)
    // ============================================================================

    /**
     * Client-side implementation of Proc_CheckSalesCommissionBCException
     * Returns:
     *  { isException: boolean, BCDEST: zip, BCSPEC: zip, BCSELL: zip,
     *    BCDESTTerritory, BCSPECTerritory, BCSELLTerritory }
     */

    async function checkBCException(params, zipCodes) {
        try {
            if (!params.merlinOrderNo && !params.divisionOrderNo) return { isException: false };

            // Load the order to read segment/opportunity/shipto
            const orderNumber = params.merlinOrderNo || params.divisionOrderNo;
            const orderFilter = `ordernumber eq '${orderNumber}'`;
            const orderQuery = `?$select=salesorderid,new_segment,_opportunityid_value,shipto_postalcode,shipto_stateorprovince,shipto_postalcode&$filter=${orderFilter}`;
            const orderRes = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.SALES_ORDER, orderQuery);

            if (!orderRes || orderRes.entities.length === 0) {
                return { isException: false };
            }
            const order = orderRes.entities[0];
            const segment = (params.pSegment || order.new_segment || params.segment || "") + "";
            const isProjectBase = !!order["_opportunityid_value"] || !!params.projectBase;

            // Only for Stormwater Solutions or Structures Solutions
            if (!(segment.includes("Stormwater Solutions") || segment.includes("Structures Solutions"))) {
                return { isException: false };
            }

            // Find SalesCommission existing record
            const existingSC = await findExistingSalesCommission(params);

            const isOverBcSpec = existingSC ? (existingSC.crmgp_isoverriddenbcspec1 ?? existingSC["crmgp_isoverriddenbcspec1"] ?? 0) : 0;
            const isOverBcSell = existingSC ? (existingSC.crmgp_isoverriddenbcsell1 ?? existingSC["crmgp_isoverriddenbcsell1"] ?? 0) : 0;
            const isOverBcDest = existingSC ? (existingSC.crmgp_isoverriddenbcdest1 ?? existingSC["crmgp_isoverriddenbcdest1"] ?? 0) : 0;

            const existingBCSpec = existingSC ? (existingSC._crmgp_bcspec1zipcodeid_value || existingSC["crmgp_bcspec1zipcodeid@OData.Community.Display.V1.FormattedValue"] || null) : null;
            const existingBCSell = existingSC ? (existingSC._crmgp_bcsell1zipcodeid_value || existingSC["crmgp_bcsell1zipcodeid@OData.Community.Display.V1.FormattedValue"] || null) : null;
            const existingBCDest = existingSC ? (existingSC._crmgp_bcdest1zipcodeid_value || existingSC["crmgp_bcdest1zipcodeid@OData.Community.Display.V1.FormattedValue"] || null) : null;

            const bcProjectOverride = params.bcProjectOverriddenAccountZipCode || params.pBCProjectOverriddenAccountZipCode || params._bcProjectOverriddenAccountZipCode || params.bcProjectOverride;
            const bcOrderOverride = params.bcOrderOverrideAccountZipCode || params.pBCOrderOverrideAccountZipCode || params._bcOrderOverrideAccountZipCode || params.bcOrderOverride;

            let bcSpec = null, bcSell = null, bcDest = null;
            if ((isOverBcSpec === 0 || isOverBcSpec === "0")) {
                if (isProjectBase) {
                    bcSpec = bcProjectOverride || params.projectBaseZipCode || (zipCodes.projectBaseZipCode && (zipCodes.projectBaseZipCode.new_zipcode || zipCodes.projectBaseZipCode.new_zipcodeid)) || null;
                } else {
                    bcSpec = (zipCodes.shipToZipCode && (zipCodes.shipToZipCode.new_zipcode || zipCodes.shipToZipCode.new_zipcodeid)) || (zipCodes.accountZipCode && (zipCodes.accountZipCode.new_zipcode || zipCodes.accountZipCode.new_zipcodeid)) || null;
                }
            } else {
                bcSpec = existingBCSpec;
            }

            if ((isOverBcSell === 0 || isOverBcSell === "0")) {
                bcSell = bcOrderOverride || (zipCodes.accountZipCode && (zipCodes.accountZipCode.new_zipcode || zipCodes.accountZipCode.new_zipcodeid)) || null;
            } else {
                bcSell = existingBCSell;
            }

            // initial BCDEST set to BCSPEC per stored proc
            bcDest = bcSpec || existingBCDest || null;

            // Product detail logic
            const salesOrderId = order.salesorderid || order.SalesOrderId || null;

            let productFamily = "";
            let productSubType = "";
            let shipToState = (order.shipto_stateorprovince || order["shipto_stateorprovince"] || null);
            let isExceptionProductCodeCount = 0;

            if (salesOrderId) {
                // details query - GUID in filter must be quoted
                const detailsQuery = `?$select=new_productfamily,new_productsubtype,new_productcode&$filter=_salesorderid_value eq '${salesOrderId}'`;
                const details = await Xrm.WebApi.retrieveMultipleRecords("salesorderdetail", detailsQuery);
                if (details && details.entities && details.entities.length > 0) {
                    for (let d of details.entities) {
                        if (!productFamily && d.new_productfamily) productFamily = d.new_productfamily;
                        if (!productSubType && d.new_productsubtype) productSubType = d.new_productsubtype;
                        const code = (d.new_productcode || d.New_productcode || "") + "";
                        const last3 = code.slice(-3);
                        if (["585", "586", "587", "589", "680", "681"].includes(last3)) isExceptionProductCodeCount++;
                    }
                }
            }

            // Determine effective input ship zip
            let inputShipZip = (params.manualShipToZipCode || (zipCodes.shipToZipCode && (zipCodes.shipToZipCode.new_zipcode || zipCodes.shipToZipCode.new_zipcodeid)) || null);
            const orderShipPostal = order.shipto_postalcode || order["shipto_postalcode"] || null;
            if (inputShipZip && orderShipPostal && orderShipPostal !== inputShipZip) {
                try {
                    const zipQuery = `?$select=new_state,new_zipcode,new_zipcodeid&$filter=new_zipcode eq '${inputShipZip}'&$top=1`;
                    const zipRes = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.ZIPCODE, zipQuery);
                    if (zipRes && zipRes.entities.length > 0) {
                        shipToState = zipRes.entities[0].new_state || shipToState;
                    }
                } catch (e) {
                    console.warn("zip lookup for state failed", e);
                }
            } else {
                if (!shipToState && zipCodes.shipToZipCode?.new_state) shipToState = zipCodes.shipToZipCode.new_state;
            }

            // helper to fetch zip by BC number (top, order by createdon asc)
            const getZipByBCNumber = async (bcNumber) => {
                try {
                    const q = `?$select=new_zipcode,new_zipcodeid&$filter=new_bcnumber eq '${bcNumber}'&$orderby=createdon asc&$top=1`;
                    const r = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.ZIPCODE, q);
                    if (r && r.entities && r.entities.length > 0) return r.entities[0].new_zipcode || r.entities[0].new_zipcodeid || null;
                } catch (e) {
                    console.warn("getZipByBCNumber failed", e);
                }
                return null;
            };

            // Cattleguards case
            if ((productFamily || "").toString() === "Cattleguards") {
                const candidate = await getZipByBCNumber('5940');
                if (candidate) {
                    bcDest = candidate;
                    bcSell = candidate;
                    bcSpec = candidate;
                    return {
                        isException: true,
                        BCDEST: bcDest,
                        BCSPEC: bcSpec,
                        BCSELL: bcSell,
                        BCDESTTerritory: '5940',
                        BCSPECTerritory: '5940',
                        BCSELLTerritory: '5940'
                    };
                }
            }

            // TX + Specialty case
            if ((shipToState || "").toString() === 'TX' && (productSubType || "") === 'Specialty' && (productFamily || "") !== 'Cattleguards') {
                const candidate = await getZipByBCNumber('5750');
                if (candidate) {
                    bcDest = candidate;
                    bcSell = candidate;
                    bcSpec = candidate;
                    return {
                        isException: true,
                        BCDEST: bcDest,
                        BCSPEC: bcSpec,
                        BCSELL: bcSell,
                        BCDESTTerritory: '5750',
                        BCSPECTerritory: '5750',
                        BCSELLTerritory: '5750'
                    };
                }
            }

            // product code exceptions
            if (isExceptionProductCodeCount > 0) {
                if ((shipToState || "").toString() === 'CO') {
                    const candidate = await getZipByBCNumber('5919');
                    if (candidate) {
                        bcDest = candidate;
                        bcSell = candidate;
                        bcSpec = candidate;
                        return {
                            isException: true,
                            BCDEST: bcDest,
                            BCSPEC: bcSpec,
                            BCSELL: bcSell,
                            BCDESTTerritory: '5919',
                            BCSPECTerritory: '5919',
                            BCSELLTerritory: '5919'
                        };
                    }
                }
                // other commented WA/AK logic in SQL intentionally omitted (kept consistent with stored proc comments)
            }

            return {
                isException: false,
                BCDEST: bcDest || null,
                BCSPEC: bcSpec || null,
                BCSELL: bcSell || null,
                BCDESTTerritory: null,
                BCSPECTerritory: null,
                BCSELLTerritory: null
            };
        } catch (error) {
            console.error("Error in client-side checkBCException:", error);
            return { isException: false };
        }
    }

    // ============================================================================
    // FIND EXISTING RECORD
    // ============================================================================

    async function findExistingSalesCommission(params) {
        try {
            let filterQuery;
            if (params.fromSystem === 'OE') {
                filterQuery = `crmgp_merlinorderno eq '${params.divisionOrderNo}'`;
            } else {
                filterQuery = `crmgp_merlinorderno eq '${params.merlinOrderNo}'`;
            }

            const query = `?$filter=${filterQuery}&$orderby=crmgp_merlinorderno asc&$top=1`;
            const result = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.SALES_COMMISSION, query);
            return result.entities.length > 0 ? result.entities[0] : null;
        } catch (error) {
            console.error("Error finding existing sales commission:", error);
            return null;
        }
    }

    // ============================================================================
    // CREATE SALES COMMISSION
    // ============================================================================

    async function createSalesCommission(validation, params) {
        try {
            const createData = buildSalesCommissionData(validation, params);
            const result = await Xrm.WebApi.createRecord(ENTITY_NAMES.SALES_COMMISSION, createData);
            return result.id;
        } catch (error) {
            console.error("Error creating sales commission:", error);
            throw error;
        }
    }

    // ============================================================================
    // UPDATE SALES COMMISSION
    // ============================================================================

    async function updateSalesCommission(recordId, validation, params) {
        try {
            const updateData = buildSalesCommissionData(validation, params);

            //delete updateData.new_createdby;
            //delete updateData.new_createdon;

            await Xrm.WebApi.updateRecord(ENTITY_NAMES.SALES_COMMISSION, recordId, updateData);
        } catch (error) {
            console.error("Error updating sales commission:", error);
            throw error;
        }
    }

    // ------------------------------------------------------------------------
    // buildSalesCommissionData (unchanged logic but ensures normalized inputs)
    // ------------------------------------------------------------------------

    function buildSalesCommissionData(validation = {}, params = {}) {
        const record = {};
        if (params.merlinOrderNo != null) record.crmgp_merlinorderno = params.merlinOrderNo;
        if (params.fromSystem != null) record.crmgp_fromsystem = params.fromSystem;
        if (params.divisionOrderNo != null) record.crmgp_divisionorderno = params.divisionOrderNo;

        // helper for binds
        const setBind = (attr, zipObj) => {
            if (!zipObj) return;
            const normalized = normalizeZip(zipObj);
            const bind = bindLookup("ZIPCODE", normalized.new_zipcodeid || normalized.new_zipcode || normalized.id);
            if (bind) record[`${attr}@odata.bind`] = bind;
        };

        // SE fields
        setBind("crmgp_sespec1zipcodeId", validation.seSpec1?.zipCode);
        if (validation.seSpec1?.isOverridden != null) record.crmgp_isoverriddensespec1 = toBool(validation.seSpec1.isOverridden);
        if (validation.seSpec1?.overriddenDate) record.crmgp_isoverriddendatesespec1 = validation.seSpec1.overriddenDate;

        setBind("crmgp_sesell1zipcodeId", validation.seSell1?.zipCode);
        if (validation.seSell1?.isOverridden != null) record.crmgp_isoverriddensesell1 = toBool(validation.seSell1.isOverridden);
        if (validation.seSell1?.overriddenDate) record.crmgp_isoverriddendatesesell1 = validation.seSell1.overriddenDate;

        setBind("crmgp_sedest1zipcodeId", validation.seDest1?.zipCode);
        if (validation.seDest1?.isOverridden != null) record.crmgp_isoverriddensedest1 = toBool(validation.seDest1.isOverridden);
        if (validation.seDest1?.overriddenDate) record.crmgp_isoverriddendatesedest1 = validation.seDest1.overriddenDate;

        setBind("crmgp_sespec2zipcodeId", validation.seSpec2?.zipCode);
        if (validation.seSpec2?.isOverridden != null) record.crmgp_isoverriddensespec2 = toBool(validation.seSpec2.isOverridden);
        if (validation.seSpec2?.overriddenDate) record.crmgp_isoverriddendatesespec2 = validation.seSpec2.overriddenDate;

        setBind("crmgp_sesell2zipcodeId", validation.seSell2?.zipCode);
        if (validation.seSell2?.isOverridden != null) record.crmgp_isoverriddensesell2 = toBool(validation.seSell2.isOverridden);
        if (validation.seSell2?.overriddenDate) record.crmgp_isoverriddendatesesell2 = validation.seSell2.overriddenDate;

        if (params.seSpec30 != null) record.crmgp_sespec30 = toBool(params.seSpec30);

        // BC group
        setBind("crmgp_bcspec1zipcodeId", validation.bcSpec1?.zipCode);
        if (validation.bcSpec1?.isOverridden != null) record.crmgp_isoverriddenbcspec1 = toBool(validation.bcSpec1.isOverridden);
        if (validation.bcSpec1?.overriddenDate) record.crmgp_isoverriddendatebcspec1 = validation.bcSpec1.overriddenDate;

        setBind("crmgp_bcsell1zipcodeId", validation.bcSell1?.zipCode);
        if (validation.bcSell1?.isOverridden != null) record.crmgp_isoverriddenbcsell1 = toBool(validation.bcSell1.isOverridden);
        if (validation.bcSell1?.overriddenDate) record.crmgp_isoverriddendatebcsell1 = validation.bcSell1.overriddenDate;

        setBind("crmgp_bcdest1zipcodeId", validation.bcDest1?.zipCode);
        if (validation.bcDest1?.isOverridden != null) record.crmgp_isoverriddenbcdest1 = toBool(validation.bcDest1.isOverridden);
        if (validation.bcDest1?.overriddenDate) record.crmgp_isoverriddendatebcdest1 = validation.bcDest1.overriddenDate;

        setBind("crmgp_bcspec2zipcodeId", validation.bcSpec2?.zipCode);
        if (validation.bcSpec2?.isOverridden != null) record.crmgp_isoverriddenbcspec2 = toBool(validation.bcSpec2.isOverridden);
        if (validation.bcSpec2?.overriddenDate) record.crmgp_isoverriddendatebcspec2 = validation.bcSpec2.overriddenDate;

        setBind("crmgp_bcsell2zipcodeId", validation.bcSell2?.zipCode);
        if (validation.bcSell2?.isOverridden != null) record.crmgp_isoverriddenbcsell2 = toBool(validation.bcSell2.isOverridden);
        if (validation.bcSell2?.overriddenDate) record.crmgp_isoverriddendatebcsell2 = validation.bcSell2.overriddenDate;

        if (params.bcSpec30 != null) record.crmgp_bcspec30 = toBool(params.bcSpec30);

        // SWC group
        setBind("crmgp_swcspec1zipcodeId", validation.swcSpec1?.zipCode);
        if (validation.swcSpec1?.isOverridden != null) record.crmgp_isoverriddenswcspec1 = toBool(validation.swcSpec1.isOverridden);
        if (validation.swcSpec1?.overriddenDate) record.crmgp_isoverriddendateswcspec1 = validation.swcSpec1.overriddenDate;

        setBind("crmgp_swcsell1zipcodeId", validation.swcSell1?.zipCode);
        if (validation.swcSell1?.isOverridden != null) record.crmgp_isoverriddenswcsell1 = toBool(validation.swcSell1.isOverridden);
        if (validation.swcSell1?.overriddenDate) record.crmgp_isoverriddendateswcsell1 = validation.swcSell1.overriddenDate;

        setBind("crmgp_swcdest1zipcodeId", validation.swcDest1?.zipCode);
        if (validation.swcDest1?.isOverridden != null) record.crmgp_isoverriddenswcdest1 = toBool(validation.swcDest1.isOverridden);
        if (validation.swcDest1?.overriddenDate) record.crmgp_isoverriddendateswcdest1 = validation.swcDest1.overriddenDate;

        setBind("crmgp_swcspec2zipcodeId", validation.swcSpec2?.zipCode);
        if (validation.swcSpec2?.isOverridden != null) record.crmgp_isoverriddenswcspec2 = toBool(validation.swcSpec2.isOverridden);
        if (validation.swcSpec2?.overriddenDate) record.crmgp_isoverriddendateswcspec2 = validation.swcSpec2.overriddenDate;

        setBind("crmgp_swcsell2zipcodeId", validation.swcSell2?.zipCode);
        if (validation.swcSell2?.isOverridden != null) record.crmgp_isoverriddenswcsell2 = toBool(validation.swcSell2.isOverridden);
        if (validation.swcSell2?.overriddenDate) record.crmgp_isoverriddendateswcsell2 = validation.swcSell2.overriddenDate;

        if (params.swcSpec30 != null) record.crmgp_swcspec30 = toBool(params.swcSpec30);

        // ISR lookups (these are likely lookup values already)
        if (params.isrStormTerritory) {
            const st = typeof params.isrStormTerritory === "object" ? params.isrStormTerritory.id || params.isrStormTerritory : params.isrStormTerritory;
            const stormBind = bindLookup("ZIPCODE", st);
            if (stormBind) record["crmgp_isrstormzipcodeId@odata.bind"] = stormBind;
        }
        if (params.isrPipeTerritory) {
            const pt = typeof params.isrPipeTerritory === "object" ? params.isrPipeTerritory.id || params.isrPipeTerritory : params.isrPipeTerritory;
            const pipeBind = bindLookup("ZIPCODE", pt);
            if (pipeBind) record["crmgp_isrpipezipcodeId@odata.bind"] = pipeBind;
        }

        // modified by date fields left to server / not set here
        return record;
    }

    // ------------------------------------------------------------------------
    // updateSalesCommissionAdditional
    // Implements stored-proc update rules:
    // - Determines segments (Stormwater Solutions, Pipe Solutions, Structures Solutions)
    // - Applies BC exception outputs if any
    // - Updates override flags & set/clear fields accordingly 
    // - Code is not in Prod. on Premises
    // ------------------------------------------------------------------------
    //async function updateSalesCommissionAdditional(params, zipCodes) {
    //    try {
    //        const orderQuery = `?$select=new_segment,_opportunityid_value,ordernumber&$filter=ordernumber eq '${params.merlinOrderNo}'`;
    //        const orderRes = await Xrm.WebApi.retrieveMultipleRecords(ENTITY_NAMES.SALES_ORDER, orderQuery);
    //        if (orderRes.entities.length === 0) return true;
    //        const order = orderRes.entities[0];
    //        const segment = (order.new_segment || "").toString();
    //        const isProjectBase = !!order["_opportunityid_value"];

    //        // flags similar to stored proc
    //        const isStormOrStructures = segment.includes("Stormwater Solutions") || segment.includes("Structures Solutions");
    //        const isStorm = segment.includes("Stormwater Solutions");
    //        const isPipe = segment.includes("Pipe Solutions");
    //        const isStructures = segment.includes("Structures Solutions");

    //        // find existing sales commission
    //        const existing = await findExistingSalesCommission(params);
    //        if (!existing) return true;

    //        const updatePayload = { crmgp_modifiedby: params.modifiedBy || getCurrentUserName() };

    //        // Helper to set bind or null based on override
    //        const setZipBindOrNull = (logicalAttr, zipObj) => {
    //            if (!zipObj) {
    //                updatePayload[logicalAttr + "@odata.bind"] = null; // not always allowed; better to set null property keys directly
    //                updatePayload[logicalAttr] = null;
    //                return;
    //            }
    //            const normalized = normalizeZip(zipObj);
    //            const bind = bindLookup("ZIPCODE", normalized.new_zipcodeid || normalized.new_zipcode || normalized.id);
    //            if (bind) updatePayload[`${logicalAttr}@odata.bind`] = bind;
    //        };

    //        // --- Implement similar logic as stored proc ---
    //        // If Stormwater or Structures branch calls Proc_CheckSalesCommissionBCException earlier; we applied bc outputs into params._bcOutputs
    //        const bcOutputs = params._bcOutputs || null;

    //        // SE / SWC / PC updates:
    //        if (isStorm || isPipe || isStructures) {
    //            // For Stormwater Solutions - update SE and SWC fields
    //            if (isStorm) {
    //                // set SE fields: SESpec1Zipcode uses project base or shipTo / order account depending on overrides
    //                if (!existing.crmgp_isoverriddensespec1) {
    //                    const value = (isProjectBase && params.manualOrderAccountZipCode) ? params.manualOrderAccountZipCode : (zipCodes.shipToZipCode || zipCodes.accountZipCode);
    //                    if (value) setZipBindOrNull("crmgp_sespec1zipcodeid", value);
    //                }
    //                // PCSpec1Zipcode -> project base or shipTo
    //                if (!existing.crmgp_isoverriddenpcspec1) {
    //                    const value = (isProjectBase && params.manualOrderAccountZipCode) ? params.manualOrderAccountZipCode : zipCodes.shipToZipCode;
    //                    if (value) setZipBindOrNull("crmgp_pcspec1zipcodeid", value);
    //                }
    //                // SESell1Zipcode / PCSell1Zipcode -> account override or order account
    //                if (!existing.crmgp_isoverriddensesell1) {
    //                    const sellVal = params.manualOrderAccountZipCode || zipCodes.accountZipCode;
    //                    if (sellVal) setZipBindOrNull("crmgp_sesell1zipcodeid", sellVal);
    //                    if (sellVal) setZipBindOrNull("crmgp_pcsell1zipcodeid", sellVal);
    //                }
    //                // Also SWC fields
    //                if (!existing.crmgp_isoverriddenswcspec1) {
    //                    const swcVal = (isProjectBase && params._swcProjectOverriddenAccountZipCode) ? params._swcProjectOverriddenAccountZipCode : (zipCodes.shipToZipCode || zipCodes.accountZipCode);
    //                    if (swcVal) setZipBindOrNull("crmgp_swcspec1zipcodeid", swcVal);
    //                }
    //                if (!existing.crmgp_isoverriddenswcsell1) {
    //                    const swcSellVal = params._swcOrderOverrideAccountZipCode || zipCodes.accountZipCode;
    //                    if (swcSellVal) setZipBindOrNull("crmgp_swcsell1zipcodeid", swcSellVal);
    //                }
    //            }

    //            // For Pipe Solutions
    //            if (isPipe) {
    //                if (!existing.crmgp_isoverriddensespec1) {
    //                    const value = (isProjectBase && params.manualOrderAccountZipCode) ? params.manualOrderAccountZipCode : (zipCodes.shipToZipCode || zipCodes.accountZipCode);
    //                    if (value) setZipBindOrNull("crmgp_sespec1zipcodeid", value);
    //                }
    //                if (!existing.crmgp_isoverriddenpcspec1) {
    //                    const value = (isProjectBase && params.manualOrderAccountZipCode) ? params.manualOrderAccountZipCode : zipCodes.shipToZipCode;
    //                    if (value) setZipBindOrNull("crmgp_pcspec1zipcodeid", value);
    //                }
    //                if (!existing.crmgp_isoverriddensesell1) {
    //                    const sellVal = params.manualOrderAccountZipCode || zipCodes.accountZipCode;
    //                    if (sellVal) setZipBindOrNull("crmgp_sesell1zipcodeid", sellVal);
    //                    if (sellVal) setZipBindOrNull("crmgp_pcsell1zipcodeid", sellVal);
    //                }
    //            }

    //            // For Structures Solutions, BC logic applies
    //            if (isStructures) {
    //                // if bc exception outputs provided, apply them
    //                if (bcOutputs && bcOutputs.isException) {
    //                    // BCSpec1Zipcode, BCDest1Zipcode, BCSell1Zipcode set from outputs (if present)
    //                    if (bcOutputs.BCSPEC) setZipBindOrNull("crmgp_bcspec1zipcodeid", normalizeZip({ new_zipcodeid: bcOutputs.BCSPEC }));
    //                    if (bcOutputs.BCDEST) setZipBindOrNull("crmgp_bcdest1zipcodeid", normalizeZip({ new_zipcodeid: bcOutputs.BCDEST }));
    //                    if (bcOutputs.BCSELL) setZipBindOrNull("crmgp_bcsell1zipcodeid", normalizeZip({ new_zipcodeid: bcOutputs.BCSELL }));
    //                    // override flags should follow exception flag behaviour:
    //                    updatePayload.crmgp_isoverriddenbcspec1 = false; // matching stored proc trick: exception -> set 0 (enable override behavior reset)
    //                    updatePayload.crmgp_isoverriddenbcsell1 = false;
    //                } else {
    //                    // No exception: set BC fields conservatively from params.bc* or leave existing
    //                    if (params.bcSpec1Territory) {
    //                        const bcSpec = await findCorrectZipCodeForTerritory('BC', params.bcSpec1Territory);
    //                        if (bcSpec) setZipBindOrNull("crmgp_bcspec1zipcodeid", bcSpec);
    //                    }
    //                    if (params.bcDest1Territory) {
    //                        const bcDest = await findCorrectZipCodeForTerritory('BC', params.bcDest1Territory);
    //                        if (bcDest) setZipBindOrNull("crmgp_bcdest1zipcodeid", bcDest);
    //                    }
    //                    if (params.bcSell1Territory) {
    //                        const bcSell = await findCorrectZipCodeForTerritory('BC', params.bcSell1Territory);
    //                        if (bcSell) setZipBindOrNull("crmgp_bcsell1zipcodeid", bcSell);
    //                    }
    //                }
    //            }

    //            // Update modifiedOn/modifiedBy handled server-side; update record now
    //            await Xrm.WebApi.updateRecord(ENTITY_NAMES.SALES_COMMISSION, existing.crmgp_salescommissionid, updatePayload);
    //        } else {
    //            // NOT Storm/Pipe/Structures -> clear groups accordingly (matching stored proc clearing logic)
    //            const clearPayload = {};
    //            // Clear SE group if not present
    //            clearPayload.crmgp_sespec1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddensespec1 = false;
    //            clearPayload.crmgp_isoverriddendatesespec1 = null;
    //            clearPayload.crmgp_sedest1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddensedest1 = false;
    //            clearPayload.crmgp_isoverriddendatesedest1 = null;
    //            clearPayload.crmgp_sesell1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddensesell1 = false;
    //            clearPayload.crmgp_isoverriddendatesesell1 = null;
    //            clearPayload.crmgp_sespec2zipcodeid = null;
    //            clearPayload.crmgp_isoverriddensespec2 = false;
    //            clearPayload.crmgp_isoverriddendatesespec2 = null;
    //            clearPayload.crmgp_sesell2zipcodeid = null;
    //            clearPayload.crmgp_isoverriddensesell2 = false;
    //            clearPayload.crmgp_isoverriddendatesesell2 = null;

    //            // Clear PC group
    //            clearPayload.crmgp_pcspec1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenpcspec1 = false;
    //            clearPayload.crmgp_isoverriddendatepcspec1 = null;
    //            clearPayload.crmgp_pcdest1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenpcdest1 = false;
    //            clearPayload.crmgp_isoverriddatepcdest1 = null;
    //            clearPayload.crmgp_pcsell1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenpcsell1 = false;
    //            clearPayload.crmgp_isoverriddendatepcsell1 = null;
    //            clearPayload.crmgp_pcspec2zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenpcspec2 = false;
    //            clearPayload.crmgp_isoverriddendatepcspec2 = null;
    //            clearPayload.crmgp_pcsell2zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenpcsell2 = false;
    //            clearPayload.crmgp_isoverriddendatepcsell2 = null;

    //            // Clear BC group
    //            clearPayload.crmgp_bcspec1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenbcspec1 = false;
    //            clearPayload.crmgp_isoverriddendatebcspec1 = null;
    //            clearPayload.crmgp_bcdest1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenbcdest1 = false;
    //            clearPayload.crmgp_isoverriddendatebcdest1 = null;
    //            clearPayload.crmgp_bcsell1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenbcsell1 = false;
    //            clearPayload.crmgp_isoverriddendatebcsell1 = null;
    //            clearPayload.crmgp_bcspec2zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenbcspec2 = false;
    //            clearPayload.crmgp_isoverriddendatebcspec2 = null;
    //            clearPayload.crmgp_bcsell2zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenbcsell2 = false;
    //            clearPayload.crmgp_isoverriddendatebcsell2 = null;

    //            // Clear SWC group
    //            clearPayload.crmgp_swcspec1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenswcspec1 = false;
    //            clearPayload.crmgp_isoverriddendateswcspec1 = null;
    //            clearPayload.crmgp_swcdest1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenswcdest1 = false;
    //            clearPayload.crmgp_isoverriddendateswcdest1 = null;
    //            clearPayload.crmgp_swcsell1zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenswcsell1 = false;
    //            clearPayload.crmgp_isoverriddendateswcsell1 = null;
    //            clearPayload.crmgp_swcspec2zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenswcspec2 = false;
    //            clearPayload.crmgp_isoverriddendateswcspec2 = null;
    //            clearPayload.crmgp_swcsell2zipcodeid = null;
    //            clearPayload.crmgp_isoverriddenswcsell2 = false;
    //            clearPayload.crmgp_isoverriddendateswcsell2 = null;

    //            await Xrm.WebApi.updateRecord(ENTITY_NAMES.SALES_COMMISSION, existing.crmgp_salescommissionid, clearPayload);
    //        }

    //        return true;
    //    } catch (error) {
    //        console.error("Error in updateSalesCommissionAdditional:", error);
    //        await logError(error, params.merlinOrderNo);
    //        return false;
    //    }
    //}
    // ============================================================================
    // UTILITY FUNCTIONS
    // ============================================================================

    function getSegmentFieldName(segment) {
        const fieldMap = {
            'SE': 'new_senumber',
            'BC': 'new_bcnumber',
            'SWC': 'new_swcnumber',
            'PC': 'new_pcnumber'
        };
        return fieldMap[segment] || 'new_senumber';
    }

    function getCurrentUserName() {
        try {
            return Xrm.Utility.getGlobalContext().userSettings.userName;
        } catch (error) {
            return "System";
        }
    }

    async function getJDEShipToZip(divisionOrderNo) {
        try {
            var order_postalcode = formContext.getAttribute("new_zipaddress1_lookup")?.getValue();
            if (order_postalcode != null) {
                return normalizeZip(order_postalcode);
            }
            return null;
        } catch (e) {
            return null;
        }
    }

    async function getJDEAccountZip(divisionOrderNo) {
        try {
            var customer = formContext.getAttribute("customerid")?.getValue();
            if (customer && customer.length > 0) {
                var customerId = customer[0].id;
                var entityType = customer[0].entityType;

                var entAccount = null;

                if (entityType === "account") {
                    const queryParam = `?$select=new_zipaddress1_lookup`;
                    entAccount = await formContext.retrieveRecord("account", customerId, queryParam);

                    if (entAccount != null) {
                        var account_postalcode = entAccount["_new_zipaddress1_lookup_value@OData.Community.Display.V1.FormattedValue"];
                        return account_postalcode;
                    }
                }
                return null;
            }
            return null;
        } catch (e) {
            console.error("getJDEAccountZip error", e);
            return null;
        }
    }

    function logInfo(message, orderNumber, data) {
        console.log(`[INFO] ${message}`, orderNumber, data);
    }

    async function logError(error, orderNumber) {
        try {
            const logData = {
                new_logdata: `Error: ${error.message}\nStack: ${error.stack}`,
                new_ordernumber: orderNumber,
                new_datetime: new Date().toISOString()
            };
            console.error("Error logging to table:", logData);
            //await Xrm.WebApi.createRecord(ENTITY_NAMES.LOG_TABLE, logData);
        } catch (logError) {
            console.error("Error logging to table:", logError);
        }
    }

    return {
        Init: init,
        CommissionSave: commissionSave,
        CommissionReload: reloadWebResourceOnSave
    }
}());