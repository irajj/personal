﻿var Quikrete = Quikrete || {};

Quikrete.RibbonActions = (function () {
    var formContext = null;

    /*** Function for handling "Save As" action ***/
    async function saveAs(primaryControl, primaryEntityName) {

        //Show Progress Bar for  API call
        formContext = primaryControl;
        await formContext.data.save(true);

        if (!isFormEditable(formContext)) {
            formContext.openAlertDialog("Warning", "The form is not editable. Action is not allowed.");
            return;
        }

        var primaryEntName = primaryEntityName;
        var recId = null;
        var attributeName = null;
        var idAttribute = null;
        try {
            formContext.show('Product is copying.')
            if (primaryEntName == "quotedetail") {
                recId = formContext.getAttribute("quoteid").getValue()?.[0]?.id;
                attributeName = "lineitemnumber";
                idAttribute = "quoteid";
            }
            else if (primaryEntName == "salesorderdetail") {
                recId = formContext.getAttribute("salesorderid").getValue()?.[0]?.id;
                attributeName = "lineitemnumber";
                idAttribute = "salesorderid";
            }
            else if (primaryEntName == "opportunityproduct") {
                recId = formContext.getAttribute("opportunityid").getValue()?.[0]?.id;
                attributeName = "new_sequencenumber";
                idAttribute = "opportunityid";
            }
            var isProdSeqLimitReached = await checkProductSequenceLimit(recId, primaryEntName, attributeName, idAttribute);
            if (!isProdSeqLimitReached) {
                var confirmText = "Product Sequence # maximum limit is reached. Cannot add more products.";
                var confirmTitle = "Warning";
                formContext.openAlertDialog(confirmTitle, confirmText);
                return;
            }

            await fetchAndCreateRecord(primaryEntName);
        }
        catch (error) {
            showError(formContext, (error?.message.match(/InnerException\s*:\s*(.+)/)?.[1]?.trim()) || "Something Went Wrong..!");
        }
    }

    async function checkProductSequenceLimit(recId, primaryEntName, attributeName, idAttribute) {


        if (!recId) return true

        var fetchXml = `
            <fetch aggregate="true">
            <entity name="${primaryEntName}">
                <attribute name="${attributeName}" alias="MaxitemNumber" aggregate="max"/>
                <filter>
                <condition attribute="${idAttribute}" operator="eq" value="${recId}"/>
                </filter>
            </entity>
            </fetch>`;
        var encodedFetchXml = "?fetchXml=" + encodeURIComponent(fetchXml);

        try {
            let result = await formContext.retrieveMultipleRecords(primaryEntName, encodedFetchXml);
            if (result.length > 0) {
                var seq = result[0].MaxitemNumber;
                if (seq >= 990) {
                    return false;
                }
            }


        } catch (error) {
            console.error("Error retrieving product sequence:", error);
            formContext.close();
        }
        return true;


    }

    async function fetchAndCreateRecord(primaryEntName) {

        var currentRecordId = formContext.getCurrentRecordId();
        let existingRecord = await formContext.retrieveRecord(primaryEntName, currentRecordId);
        let clonedAttributeId = '';
        // Change existingRecord._new_productattribute_value
        const productAttributeId = existingRecord?._new_productattribute_value;
        if (productAttributeId) {
            clonedAttributeId = await Quikrete.ISVFunctions.CloneProductAttribute(formContext, "new_productattributes", productAttributeId);
            if (clonedAttributeId) {
                existingRecord._new_productattribute_value = clonedAttributeId;
            }
        }

        const excludePatterns = getExcludePatterns(primaryEntName);

        const newProduct = await Quikrete.ISVFunctions.CloneRecord(formContext, formContext._entityName, existingRecord, excludePatterns, false);
        await Quikrete.ISVFunctions.UpdateProductAttribute(formContext, clonedAttributeId, newProduct);

        var entityFormOptions = {};
        entityFormOptions["entityName"] = newProduct.entityType;
        entityFormOptions["entityId"] = newProduct.id;
        Xrm.Navigation.navigateBack().then(() => {
            // formContext.openForm(entityFormOptions);
            formContext.openForm(entityFormOptions).then(
                function (success) {
                    console.log(success);
                },
                function (error) {

                    console.log(error);
                });
        });

    }

    function getExcludePatterns(entityName) {
        return [
            "@odata",
            "_base",
            "createdon",
            "modifiedon",
            "createdby",
            "modifiedby",
            "owninguser",
            "owningteam",
            "owningbusinessunit",
            "versionnumber",
            "_ownerid_value",
            "lineitemnumber",
            "new_sequencenumber",
            `${entityName}id`
        ];
    }

    async function projectProductEdit(primaryControl, primaryEntityName, selectedEntityName) {

        try {
            formContext = primaryControl;
            top.formContext = formContext;
            if (!isFormEditable(formContext)) {
                formContext.openAlertDialog("Warning", "The form is not editable. Action is not allowed.");
                return;
            }

            var entityId = formContext.getCurrentRecordId();
            var userId = formContext.getCurrentUserId();
            var businessUnitId = await formContext.getBusinessUnit(userId);
            var entityName = primaryEntityName;
            var entityDetailName = selectedEntityName;
            openQuickProductEdit(entityId, businessUnitId, userId, entityName, entityDetailName);
        } catch (error) {
            console.error("Error while adding the record: ", error);
        }
    }

    function openQuickProductEdit(entityId, businessUnitId, userId, entityName, entityDetailName) {
        try {
            // Clean entityId if passed from context
            entityId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            // var owningBU =  formContext._data.entity._attributes._collection['owningbusinessunit'] ? formContext._data.entity._attributes._collection['owningbusinessunit'].getValue() : null;

            var businessUnitId = businessUnitId && businessUnitId.length > 0
                ? businessUnitId.replace("{", "").replace("}", "")
                : null;

            // Build parameters for URL
            const params = new URLSearchParams({
                entityId,
                entityName,
                businessUnitId,
                userId,
                entityDetailName,
            }).toString();

            var webResourceString = (businessUnitId.toUpperCase() == Quikrete.Common.USPipe ? "new_USPipe_Product_Edit?" : "new_Quikerte_Product_Edit?") + params;
            var windowOptions = { title: businessUnitId.toUpperCase() == Quikrete.Common.USPipe ? "USPipe_Product_Edit" : "Quikerte_Product_Edit" };
            Xrm.Navigation.openWebResource(webResourceString, windowOptions);
        }
        catch (error) {
            console.error("Error while opening web resource:", error);
        }
    }

    async function openProjectProductSummary(primaryControl) {

        formContext = primaryControl;
        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context

        // if (!isFormEditable(formContext)) {
        //     formContext.openAlertDialog("Warning", "The form is not editable. Action is not allowed.");
        //     return;
        // }

        try {
            let projectId = formContext.getCurrentRecordId();
            formContext.navigateTo(
                {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_ProjectProductSummary.html",
                    data: new URLSearchParams({ projectId }).toString(),
                },
                {
                    target: 2,
                    position: 1,
                    width: { value: 100, unit: "%" },
                    height: { value: 700, unit: "px" },
                    title: "Open Project Product Summary",
                }
            ).then(async function () {

            });
        } catch (error) {
            console.error("Error while adding the record: ", error);
        }
    }

    async function getOpportunityProductMain(primaryControl, primaryEntityName, selectedEntityName) {
        const entityMap = {
            opportunity: "opportunityproduct",
            salesorder: "salesorderdetail",
            quote: "quotedetail"
        };
        var formContext = primaryControl;

        if (!isFormEditable(formContext)) {
            formContext.openAlertDialog("Warning", "The form is not editable. Action is not allowed.");
            return;
        }

        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
        top.Quikrete = Quikrete;
        if (selectedEntityName === undefined) {
            selectedEntityName = entityMap[formContext._entityName];
        } else if (selectedEntityName == "opportunity" || selectedEntityName == "salesorder" || selectedEntityName == "quote") {
            selectedEntityName = entityMap[formContext._entityName];
        }
        top.selectedEntityName = selectedEntityName;

        try {

            let projectId = formContext.getCurrentRecordId();

            formContext.navigateTo(
                {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_GetProjectProduct",
                    data: new URLSearchParams({ projectId, primaryEntityName, selectedEntityName }).toString(),
                },
                {
                    target: 2,
                    position: 1,
                    width: { value: 70, unit: "%" },
                    height: { value: 90, unit: "%" },
                    title: "Project Product records",
                }
            ).then(async function () {
                Xrm.Page.data.refresh();
            });
        } catch (error) {
            console.error("Error while adding the record: ", error);
        }
    }

    async function activateQuoteRibbon(primaryControl) {
        try {

            if (Quikrete && Quikrete.FormExtension) {
                Quikrete.FormExtension.Init(primaryControl);
                top.Quikrete = Quikrete;
            }
            top.formContext = primaryControl; // Assigning the formContext to 'top' to pass it to the web resource context

            await Xrm.Navigation.navigateTo(
                {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_ActivateQuoteRibbon",
                    // data: new URLSearchParams({ projectId }).toString(),
                },
                {
                    target: 2,
                    position: 1,
                    width: { value: 70, unit: "%" },
                    height: { value: 90, unit: "%" },
                    title: "Quote Records",
                }
            );
            // Optional post-navigation logic
        } catch (error) {
            console.error("Error while opening the record: ", error);
            await Xrm.Navigation.openAlertDialog({
                confirmButtonLabel: "OK",
                text: "Something went wrong: " + error.message,
                title: "Error"
            });
        }
    }

    async function bulkUpdateConnections(primaryControl, SelectedControlSelectedItemCount, SelectedControlSelectedItemIds, primaryEntityName, selectedEntityName) {
        debugger;
        Quikrete.FormExtension.Init(primaryControl);
        formContext = primaryControl;
        top.formContext = formContext;
        sessionStorage.removeItem('selectedData');
        sessionStorage.removeItem('fetchXML');
        sessionStorage.removeItem('primaryentityname');
        sessionStorage.removeItem('selectedEntityName');

        // Try runtime filters first (Edit Filters)
        let fetchXml = primaryControl.getFetchXml();
        if (!fetchXml) {
            // Fallback to static savedquery
            const viewInfo = primaryControl._getCurrentView();
            const viewId = viewInfo.id.replace(/[{}]/g, "");

            const savedView = await Xrm.WebApi.retrieveRecord(
                viewInfo.entityType,
                viewId,
                "?$select=fetchxml"
            );
            fetchXml = savedView.fetchxml;
        }


        sessionStorage.setItem('fetchXML', fetchXml);
        sessionStorage.setItem('primaryentityname', primaryEntityName);
        sessionStorage.setItem('selectedEntityName', selectedEntityName);
        // Open bulk update HTML
        const globalContext = Xrm.Utility.getGlobalContext();
        const bulkUpdateUrl = globalContext.getCurrentAppUrl()
            + '&navbar=off&newWindow=true&pagetype=webresource&webresourceName=new_Quikrete_BulkUpdate_ConnectionRole';
        window.open(bulkUpdateUrl, "_blank", "width=1000,height=600,scrollbars=no,resizable=yes");

    }



    function autoCloseProjects(primaryControl) {

        Quikrete.FormExtension.Init(primaryControl);
        formContext = primaryControl;
        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
        try {
            formContext.navigateTo(
                {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_AutoCloseProject.html"
                },
                {
                    target: 2,
                    position: 1,
                    width: { value: 100, unit: "%" },
                    height: { value: 700, unit: "px" },
                    title: "Auto Close Project"
                }
            ).then(async function () {

            });
        } catch (error) {
            console.error("Error while adding the record: ", error);
        }
    }

    function isFormEditable(formContext) {
        const formType = formContext.ui.getFormType();
        return formType === 1 || formType === 2;
    }

    function showError(formContext, msg) {
        formContext.openAlertDialog(formContext, msg);
    }

    async function transactionalRecordCopy(primaryControl, primaryEntityName) {

        formContext = primaryControl;
        try {
            const transactionalRecord = await Quikrete.ISVFunctions.transactionalCopy(primaryControl, primaryEntityName);
            var entityFormOptions = {};
            entityFormOptions["entityName"] = primaryEntityName;
            entityFormOptions["entityId"] = transactionalRecord.id;
            formContext.openForm(entityFormOptions).then(
                function (success) {
                    console.log(success);
                },
                function (error) {

                    console.log(error);
                });
        } catch (error) {
            showError(formContext, (error?.message.match(/InnerException\s*:\s*(.+)/)?.[1]?.trim()) || "Something Went Wrong..!");

        }
    }

    async function openManufaturingLocationMap(primaryControl, primaryEntityName) {
        Quikrete.FormExtension.Init(primaryControl);
        formContext = primaryControl;
        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context

        try {

            formContext.navigateTo(
                {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_ManufacturingLocationMap"
                },
                {
                    target: 2,
                    position: 1,
                    width: { value: 90, unit: "%" },
                    height: { value: 90, unit: "%" },
                    title: "Manufaturing Location Map"
                }
            ).then(async function () {

            });

        } catch (error) {
            console.error("Error while open the record: ", error);
        }
    }

    async function printOrder(primaryControl, primaryEntityName) {

        var formContext = primaryControl;
        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
        top.Quikrete = Quikrete;
        top.primaryEntityName = primaryEntityName

        // Open Print Order HTML file
        try {
            let orderId = formContext.getCurrentRecordId();
            formContext.navigateTo(
                {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_OrderAcknowledgementPrint.html",
                    data: new URLSearchParams({ orderId }).toString(),
                },
                {
                    target: 2,
                    position: 1,
                    width: { value: 100, unit: "%" },
                    height: { value: 100, unit: "%" },
                    title: "Order Acknowledgement Print",
                }
            ).then(async function () {

            });
        } catch (error) {
            console.error("Error while adding the record: ", error);
        }

    }

    async function printQuote(primaryControl, primaryEntityName) {

        var formContext = primaryControl;
        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
        top.Quikrete = Quikrete;
        top.primaryEntityName = primaryEntityName

        // Open Print Order HTML file
        try {
            let orderId = formContext.getCurrentRecordId();
            formContext.navigateTo(
                {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_QuotePrint.html",
                    data: new URLSearchParams({ orderId }).toString(),
                },
                {
                    target: 2,
                    position: 1,
                    width: { value: 100, unit: "%" },
                    height: { value: 100, unit: "%" },
                    title: "Quote Print",
                }
            ).then(async function () {

            });
        } catch (error) {
            console.error("Error while adding the record: ", error);
        }

    }

    async function paperVision() {
        var url = "https://quikrete.neopostdms.com/";
        var windowName = "_blank";
        var windowFeatures = "width=1000,height=600,scrollbars=no,resizable=yes";

        window.open(url, windowName, windowFeatures);
    }

    async function openOrderHistory(primaryControl) {
        try {
            var formContext = primaryControl;
            top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
            top.Quikrete = Quikrete;

            var orderId = formContext.data.entity.getId().replace("{", "").replace("}", "");

            var pageInput = {
                pageType: "webresource",
                webresourceName: "new_Quikrete_OrderHistory",
                data: "orderid=" + orderId
            };

            var navigationOptions = {
                target: 2, // open as dialog
                width: { value: 80, unit: "%" },
                height: { value: 80, unit: "%" },
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        } catch (e) {
            console.log("Error: " + e.message);
        }
    }

    async function openOrderStatusReport(primaryControl) {
        try {
            var formContext = primaryControl;
            top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
            top.Quikrete = Quikrete;

            var orderId = formContext.data.entity.getId().replace("{", "").replace("}", "");

            var pageInput = {
                pageType: "webresource",
                webresourceName: "new_Quikrete_OrderStatusReport",
                data: "orderid=" + orderId
            };

            var navigationOptions = {
                target: 2, // open as dialog
                width: { value: 80, unit: "%" },
                height: { value: 80, unit: "%" },
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        } catch (e) {
            console.log("Error: " + e.message);
        }
    }

    async function openOrderAcknowledgeReport(primaryControl) {

        try {
            var formContext = primaryControl;
            top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
            top.Quikrete = Quikrete;
            var orderId = formContext.data.entity.getId().replace("{", "").replace("}", "");

            var pageInput = {
                pageType: "webresource",
                webresourceName: "new_Quikrete_OrderTrackerReport",
                data: "orderid=" + orderId
            };

            var navigationOptions = {
                target: 2, // open as dialog
                width: { value: 80, unit: "%" },
                height: { value: 80, unit: "%" },
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        } catch (e) {
            console.log("Error: " + e.message);
        }
    }

    async function openOrderDeliveryHistory(primaryControl) {
        // var formContext = primaryControl;
        // formContext.openAlertDialog("message", "This button calls 'OrderPrintHistory.aspx' page");

        try {
            var formContext = primaryControl;
            var orderId = formContext.data.entity.getId().replace("{", "").replace("}", "");

            var pageInput = {
                pageType: "webresource",
                webresourceName: "new_Quikrete_OrderACKDeliveryHistory",
                data: "orderid=" + orderId
            };

            var navigationOptions = {
                target: 2, // open as dialog
                width: { value: 80, unit: "%" },
                height: { value: 80, unit: "%" },
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        } catch (e) {
            console.log("Error: " + e.message);
        }
    }

    async function openLetterDeliveryHistory(primaryControl) {

        try {
            var formContext = primaryControl;
            var orderId = formContext.data.entity.getId().replace("{", "").replace("}", "");

            var pageInput = {
                pageType: "webresource",
                webresourceName: "new_OpenLetterDeliveryHistory",
                data: "orderid=" + orderId
            };

            var navigationOptions = {
                target: 2, // open as dialog
                width: { value: 80, unit: "%" },
                height: { value: 80, unit: "%" },
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        } catch (e) {
            console.log("Error: " + e.message);
        }
    }

    async function orderStatusReportApp(primaryControl) {
        var formContext = primaryControl;
        var userId = await Quikrete.GlobalContext.GetCurrentUserId();
        var businessUnit = await Quikrete.Security.GetBusinessUnit(userId);
        //var businessUnit = await formContext.getBusinessUnit(userId);
        if (businessUnit == Quikrete.Common.FoleyBU) {
            formContext.openAlertDialog("message", "Order Status is not available for this Business Unit.");
        }
        else {
            window.open('http://mfgconwebprod.quikrete.net/OrderStatus/ordersearch.aspx', 'window');
        }
    }

    async function openQuoteHistory(primaryControl) {
        try {
            var formContext = primaryControl;
            var quoteId = formContext.data.entity.getId().replace("{", "").replace("}", "");

            var pageInput = {
                pageType: "webresource",
                webresourceName: "new_Quikrete_OpenQuoteHistory",
                data: "quoteid=" + quoteId
            };

            var navigationOptions = {
                target: 2, // open as dialog
                width: { value: 80, unit: "%" },
                height: { value: 60, unit: "%" },
                position: 1,
                title: "Quote Delivery History Report"
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        } catch (e) {
            console.log("Error: " + e.message);
        }
    }
    ///////*****************************  Enable  rules Region*********************************///////

    async function enableBulkUpdate() {

        userID = Quikrete.GlobalContext.GetCurrentUserId();
        var userRoles = Quikrete.GlobalContext.GetUserRoles();
        userHasAdministratorRole = false;
        var adminRoles = ["System Administrator"];
        //var adminRoles = ["Sales Manager"];
        // Use 'some' to check if any role matches the admin roles
        userHasAdministratorRole = userRoles.some(role => adminRoles.includes(role.name));

        if (userHasAdministratorRole) {
            return true;
        }
        else {
            return false;
        }
    }

    function enableProductEdit(primaryControl, primaryentityid) {
        var formContext = primaryControl;
        var entityId = primaryentityid;
        var statecode = formContext.getFieldValue("statecode");
        if (statecode == 0) {
            return true;
        }
        else {
            return false;
        }
    }

    function getProjectProductEnable(primaryControl) {
        var formContext = primaryControl;
        //  var entityId = primaryentityid;
        var statecode = formContext.getFieldValue("statecode");
        if (statecode == 0) {
            return true;
        }
        else {
            return false;
        }
    }

    function isProjectBasedEntity(primaryControl) {

        var formContext = primaryControl;
        if (formContext.getFieldValue("opportunityid") != null) {
            return true;
        }
        else {
            return false;
        }
    }

    function isSalesOrderFullfill(primaryControl) {
        var formContext = primaryControl;
        var statecode = formContext.getFieldValue("statecode");
        if (statecode == 3) {
            return true;
        }
        else {
            return false;
        }
    }

    async function isSalesOrderFullfillActive(primaryControl) {
        var formContext = primaryControl;
        var statecode = formContext.getFieldValue("statecode");
        var userId = formContext.getCurrentUserId();
        var businessUnit = await formContext.getBusinessUnit(userId);
        if (businessUnit == Quikrete.Common.ContechBU && statecode == 3 || statecode == 0) {
            return true;
        }
        else {
            return false;
        }
    }

    async function transactionalEntityCopyButtonEnableRule(primaryControl) {
        var formContext = primaryControl;
        var userId = formContext.getCurrentUserId();
        var businessUnit = await formContext.getBusinessUnit(userId);
        var formType = formContext.getFormType();
        if (formType == Quikrete.Common.FormType.Update) {
            if (businessUnit == Quikrete.Common.USPipe) {
                return false;
            }
        }
        else if (formType == Quikrete.Common.FormType.Create) {
            return false;
        }
        return true;
    }

    async function openIDriveUrlFromSubgridButton(primaryControl) {
        try {

            const formContext = primaryControl;
            var record = await formContext.retrieveRecord(formContext.getCurrentEntityName(), formContext.getCurrentRecordId(), `?$select=new_documentpath`);
            if (record) {
                console.log(record);
                if (record.new_documentpath) {
                    await GetAlertOrOpenPath(record.new_documentpath);
                } else {
                    formContext.openAlertDialog("Error", "No URL found for this record.");
                    return;
                }
            }
        }
        catch (error) {
            formContext.openAlertDialog("Error", error.message);
            return;
        }
    }

    function isPOQ(primaryControl) {
        try {
            var formContext = primaryControl;
            var entityName = formContext._entityName;

            if (entityName && (entityName.toLowerCase() == 'opportunity' || entityName.toLowerCase() == 'salesorder' || entityName.toLowerCase() == 'quote')) {
                return false;
            }
            return true;
        } catch (e) {
            return true;
        }
    }

    function GetAlertOrOpenPath(docPath) {
        var tempInput = document.createElement("input");
        tempInput.value = docPath;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        var alertContent = 'Copied document path in your clipboard. Now you can open file explorer and paste it to open location. \nPath: ' + docPath.replace('\\', '');
        var isMSIE = /*@cc_on!@*/0;
        if (isMSIE) {
            // do IE-specific things
            window.open("file:" + docPath, "_blank"); //commented by Maulik
        } else {
            // do non IE-specific things
            alert(alertContent);
        }
    }

    function toggleAddNewButton(executionContext) {

        var formContext = executionContext;

        // Project on Quote/Order
        var projectId = formContext.getAttribute("opportunityid")?.getValue();
        if (projectId) {
            return false; // custom logic applied â†’ hide button
        }

        // Quote on Order/Transactional Quote
        var quoteId = formContext.getAttribute("quoteid")?.getValue();
        if (quoteId) {
            return false; // custom logic applied â†’ hide button
        }

        // Default â†’ show Add New
        return true;
    }

    async function enableOpportunityProductButtons(primaryControl) {

        let formContext = primaryControl;
        let oppId;
        let oppLookup = formContext.getAttribute("opportunityid") ? formContext.getAttribute("opportunityid")?.getValue() : formContext.data.entity.getId();

        if (!oppLookup) {
            return true;
        }
        if (typeof (oppLookup) === "string") {
            oppId = oppLookup.replace(/[{}]/g, "");
        } else if (typeof (oppLookup) == "object") {
            oppId = oppLookup[0].id.replace(/[{}]/g, "");
        }

        try {
            let opp = await formContext.retrieveRecord("opportunity", oppId, "?$select=statecode");

            if (opp.statecode === 1 || opp.statecode === 2) {
                return false;
            }
            return true;
        } catch (e) {
            console.log("Enable Rule Error:", e);
            return true;
        }
    }

    function enableOrderCommandOnQuote(primaryControl, selectedControl, commandProperties) {
        try {
            var formContext = primaryControl;
            var entityName = formContext?.data?.entity?.getEntityName();

            // Only restrict on Quote
            if (entityName !== "quote") {
                return true;
            }
            var stateAttr = formContext.getAttribute("statecode");
            if (!stateAttr) {
                return false;
            }
            // 0 = Draft
            if (stateAttr.getValue() === 0) {
                return false;
            }
            return true;
        } catch (e) {
            return false;
        }
    }



    return {
        SaveAs: saveAs,
        ActivateQuoteRibbon: activateQuoteRibbon,
        GetOpportunityProductMain: getOpportunityProductMain,
        ProjectProductEdit: projectProductEdit,
        OpenProjectProductSummary: openProjectProductSummary,
        BulkUpdateConnections: bulkUpdateConnections,
        AutoCloseProjects: autoCloseProjects,
        TransactionalRecordCopy: transactionalRecordCopy,
        OpenManufaturingLocationMap: openManufaturingLocationMap,
        PrintOrder: printOrder,
        PrintQuote: printQuote,
        EnableBulkUpdate: enableBulkUpdate,
        EnableProductEdit: enableProductEdit,
        GetProjectProductEnable: getProjectProductEnable,
        IsProjectBasedEntity: isProjectBasedEntity,
        TransactionalEntityCopyButtonEnableRule: transactionalEntityCopyButtonEnableRule,
        PaperVision: paperVision,
        OpenOrderHistory: openOrderHistory,
        IsSalesOrderFullfill: isSalesOrderFullfill,
        OpenOrderStatusReport: openOrderStatusReport,
        OpenOrderAcknowledgeReport: openOrderAcknowledgeReport,
        OpenOrderDeliveryHistory: openOrderDeliveryHistory,
        OpenLetterDeliveryHistory: openLetterDeliveryHistory,
        IsSalesOrderFullfillActive: isSalesOrderFullfillActive,
        OrderStatusReportApp: orderStatusReportApp,
        OpenQuoteHistory: openQuoteHistory,
        openIDriveUrlFromSubgridButton: openIDriveUrlFromSubgridButton,
        isPOQ: isPOQ,
        ToggleAddNewButton: toggleAddNewButton,
        EnableOpportunityProductButtons: enableOpportunityProductButtons,
        EnableOrderCommandOnQuote: enableOrderCommandOnQuote
    };
})();