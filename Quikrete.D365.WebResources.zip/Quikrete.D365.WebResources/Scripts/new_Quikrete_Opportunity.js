﻿var Quikrete = Quikrete || {};
Quikrete.Opportunity = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    var userHasAdministratorRole = null;
    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);


        // call function on change of Bidders List
        if (formContext.getAttribute("new_bidderslistid") != null)
            formContext.getAttribute("new_bidderslistid").addOnChange(onChangeOfBidderList);

        // call function on change of Customer ID
        if (formContext.getAttribute("customerid") != null)
            formContext.getAttribute("customerid").addOnChange(onChangeOfCustomerId);

        // call function on change of Copy Mfg Location to All Products
        if (formContext.getAttribute("new_updatemanufacturinglocationtoallproducts") != null)
            formContext.getAttribute("new_updatemanufacturinglocationtoallproducts").addOnChange(onChangeOfCopyMfgLocationtoAllProduct);

        // call function on change of End Marketing Subtype
        if (formContext.getAttribute("new_endmarketsubtype") != null)
            formContext.getAttribute("new_endmarketsubtype").addOnChange(onChangeOfEndMarketingSubType);

        // call function on change of Copy Probability to All Products
        if (formContext.getAttribute("new_updateprobabilitytoallproducts") != null)
            formContext.getAttribute("new_updateprobabilitytoallproducts").addOnChange(onChangeOfCopyProbabilityToAllProduct);

        // call function on change of zipcode
        if (formContext.getAttribute("new_zipaddress1_lookup") != null)
            formContext.getAttribute("new_zipaddress1_lookup").addOnChange(onChangeOfZipecode);

        // call function on change of Stage
        if (formContext.getAttribute("new_stage") != null)
            formContext.getAttribute("new_stage").addOnChange(onChangeOfStage);

        // Soft bind sales person lookup change
        if (formContext.getAttribute("new_salesperson") != null)
            formContext.getAttribute("new_salesperson").addOnChange(onSalesPersonChange);

        // --- Subgrid hiding: bind to tab expand ---
        if (formContext.ui.tabs.get("activities") != null)
            formContext.ui.tabs.get("activities").addTabStateChange(onTabStateChangeOfActivities);

        //---ExpectBidDateUnknow
        if (formContext.getAttribute("new_expectedbiddateunknown")) {
            formContext.getAttribute("new_expectedbiddateunknown").addOnChange(onChangeExpectBidDateUnknow);
        }

        //new_dotproject
        if (formContext.getAttribute("new_dotproject")) {
            formContext.getAttribute("new_dotproject").addOnChange(OnChangeDOTProject);
        }
    }

    async function formOnLoad() {

        var buid = formContext.getAttribute('owningbusinessunit')?.getValue();

        if (buid && buid.length > 0 && buid[0].id) {
            userBUID = buid[0].id.replace(/[{}]/g, "");
        } else {
            userID = formContext.getCurrentUserId();
            userBUID = await formContext.getBusinessUnit(userID);
        }

        var formType = formContext.getFormType();
        formContext.setFieldSubmitMode("new_legacyprojectreference");
        if (formType === Quikrete.Common.FormType.Create) { // Form type 1: Create
            formContext.setFieldValue("new_projectnumber", null);
            //formContext.setFieldValue("new_stage", 10);
            formContext.setFieldValue("new_leaddate", new Date());
        }

        //Filter Manufaturing Location By Buisness Unit Id.
        Quikrete.ISVFunctions.FilterLookup(formContext, "new_manufacturinglocationid", userBUID, "new_owningbusinessunit");

        if (formType === Quikrete.Common.FormType.Update) {// Form type 2: Update
            if (formContext.getFieldValue("new_updatemanufacturinglocationtoallproducts") == true) {
                formContext.setFieldValue("new_updatemanufacturinglocationtoallproducts", false);
            }
            if (formContext.getFieldValue("new_updateprobabilitytoallproducts") == true) {
                formContext.setFieldValue("new_updateprobabilitytoallproducts", false);
            }

        }
        if (formType == Quikrete.Common.FormType.Create) {
            var attribute = formContext.getAttribute("new_dotproject");
            var control = formContext.getControl("new_dotproject");
            attribute.setRequiredLevel("none");
            attribute.setValue(null);
            control.clearNotification();
            attribute.setRequiredLevel("required");
        }
        userHasAdministratorRole = formContext.isUserAdministrator();
        if (userHasAdministratorRole == true && formContext.getFieldValue("new_projectnumber") == null) {
            formContext.makeFieldDisabled("new_projectnumber", false);
            formContext.makeFieldDisabled("new_projectnumberautonumber", false);
        }

        if (userHasAdministratorRole == false || formContext.getFieldValue("new_projectnumber") != null) {
            formContext.makeFieldDisabled("new_projectnumber", true);
            formContext.makeFieldDisabled("new_projectnumberautonumber", true);
        }
        formContext.getControl("customerid").setEntityTypes(["account"]);
        onChangeOfBidderList();

        onChangeExpectBidDateUnknow();
        await Quikrete.ISVFunctions.HandleSharePointFileTab(formContext);
    }
    function OnChangeDOTProject() {
        formContext.clearFieldValidationMessage("new_dotproject");
        formContext.getAttribute("new_dotproject").setSubmitMode("always");
    }
    function onChangeExpectBidDateUnknow() {

        var bidDateUnknown = formContext.getFieldValue("new_expectedbiddateunknown");
        var bidDate = formContext.getFieldValue("new_biddate");

        if (bidDateUnknown === false && !bidDate) {

            formContext.makeFieldRequired("new_biddate", "required");
        }

        else if (bidDateUnknown === false && bidDate) {
            formContext.makeFieldRequired("new_biddate", false);
            formContext.makeFieldDisabled("new_expectedbiddateunknown", false);
        }
        else {
            formContext.makeFieldRequired("new_biddate", false);
        }
    }
    async function formOnSave(executionContext) {
        var eventArgs = executionContext.getEventArgs();
        const saveMode = eventArgs.getSaveMode();

        if (formContext.getFieldValue("new_biddate") == null && formContext.getFieldValue("new_expectedbiddateunknown") == 0 && formContext.getFormType() != 4) {
            formContext.setFieldValidationMessage("new_biddate", "Expected Bid Date is required. If unknown, toggle Expected Bid Date Unknown.");
            formContext.makeFieldRequired("new_biddate", "required");
            var confirmText = "Please provide an Expected Bid Date / Time. If the information is currently not available, check the Expected Bid Date Unknown Checkbox";
            var confirmTitle = "Confirmation";
            formContext.openAlertDialog(confirmTitle, confirmText)
            formContext.getControl("new_biddate").setFocus(true);
            var eventArgs = executionContext.getEventArgs();
            eventArgs.preventDefault();
            return;
        }
        var dotProject = formContext.getAttribute("new_dotproject").getValue();
        if (dotProject === null) {

            formContext.getControl("new_dotproject").setNotification(
                "DOT Project is required.",
                "DOT_REQUIRED"
            );
            var eventArgs = executionContext.getEventArgs();
            eventArgs.preventDefault();
            return;
        }
    }

    // on change of Specifier Account
    // no need to write this function as used quick view form in online crm

    //Spec Account contact 
    function onChangeOfCustomerId() {
        formContext.setFieldValue("new_specacctcontact", null);

    }


    // on Sales Person Change
    async function onSalesPersonChange() {
        await Quikrete.ISVFunctions.onSalesPersonChange(formContext, "new_salesperson", "new_salespersonnumber");
    }

    //on change of lead source , this functionality is no more needed 



    //on change of Design complete (Moved logic in BR)


    //on change of Bidders List
    function onChangeOfBidderList() {

        // Get the selected bidder list
        var bidderList = formContext.getFieldValue("new_bidderslistid");
        if (!bidderList || bidderList.length === 0) return;

        var bidderListId = bidderList[0].id.replace("{", "").replace("}", "");

        var viewId = "02D5C148-551C-F011-998A-000D3A1F2445";
        var entity = "account";
        var ViewDisplayName = "Custom account lookup view";
        var fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
            "<entity name='account'>" +
            "<attribute name='name'/>" +
            "<attribute name='primarycontactid'/>" +
            "<attribute name='telephone1'/>" +
            "<attribute name='accountid'/>" +
            "<attribute name='new_accountnumber'/>" +
            "<order attribute='name' descending='false'/>" +
            "<filter type='and'>" +
            "<condition attribute='statecode' operator='eq' value='0'/>" +  // Only active accounts
            "</filter>" +
            "<link-entity name='listmember' from='entityid' to='accountid' visible='false' intersect='true'>" +
            "<link-entity name='list' from='listid' to='listid' alias='ac'>" +
            "<filter type='and'>" +
            "<condition attribute='listid' operator='eq' uitype='list' value='" + bidderListId + "'/>" +  // Filter by the selected marketing list
            "</filter>" +
            "</link-entity>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";
        var layout = "<grid name='resultset' jump='name' select='1' icon='1' preview='1'>" +
            "<row name = 'result' id = 'accountid' >" +
            "<cell name='name' width='150' />" +
            "<cell name='productnumber' width='200' />" +
            "</row></grid>";
        formContext.getControl("new_lowbiddercustomer_lookup").addCustomView(viewId, entity, ViewDisplayName, fetchXML, layout, true);

    }

    //on change of Expected Bid Date (Moved this logic in Business Rule)

    //on change of Probability(Moved this logic in Business Rule)

    //on change of Manufacturing Location (Moved this logic in Business Rule)

    //on change of Copy Mfg Location to All Products
    function onChangeOfCopyMfgLocationtoAllProduct() {

        var copyMfgLocationToProduct = formContext.getFieldValue("new_updatemanufacturinglocationtoallproducts");
        if (copyMfgLocationToProduct == true) {
            formContext.makeFieldRequired("new_manufacturinglocationid", true);
            var confirmText = "By checking this checkbox, this information will be copied to all products on this project. Click Ok to proceed or click Cancel.";
            var confirmTitle = "Confirmation";
            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    formContext.setFieldValue("new_updatemanufacturinglocationtoallproducts", success.confirmed);
                });
            formContext.data.entity.save();
        }
        else {
            formContext.makeFieldRequired("new_manufacturinglocationid", false);
        }

    }


    //on change of Copy Probability to All Products
    function onChangeOfCopyProbabilityToAllProduct() {

        var manuFacturingLocation = formContext.getFieldValue("new_updateprobabilitytoallproducts");
        if (manuFacturingLocation == true) {
            var confirmText = "By Checking this checkbox, this information will be copied to all products on this Project. Click Ok to proceed or click cancel.";
            var confirmTitle = "Confirmation";
            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    formContext.setFieldValue("new_updateprobabilitytoallproducts", success.confirmed);
                });
            formContext.data.entity.save();
        }

    }
    //on change of zipcode 
    async function onChangeOfZipecode() {
        await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipaddress1_lookup", "new_cityaddress1_lookup", "new_stateaddress1_lookup", "new_countyaddress1_lookup", "new_countryaddress1_lookup");
    }

    function onChangeOfStage() {

        var stage = formContext.getFieldValueText("new_stage");

        //var option = formContext.getFieldValue("new_stage");
        // Sets stage date fields based on stage
        switch (stage) {
            case "Lead":
                if (ChangeFromMultistage() == true) {
                    saveform("new_leaddate");
                }
                break;
            case "Design":
                if (ChangeFromMultistage() == true) {
                    saveform("new_designdate");
                }
                break;
            case "Quote":
                // Uncomment and add functionality for Quote if needed
                // if (ChangeFromMultistage() == true) {
                //    saveform("new_quoteddate");
                // }
                break;
            case "Order":
                // Order can't be chosen from list - reset value to previous
                var confirmText = " Order can't be chosen from list";
                var confirmTitle = "Confirmation";
                formContext.openAlertDialog(confirmTitle, confirmText)

                break;
            case "Sale":
                // Sale can't be chosen from list - reset value to previous

                break;
            case "Lost":
                if (ChangeFromMultistage() == true) {
                    saveform("new_lostdate");
                }
                break;
            case "Multi-Stage":
                formContext.data.entity.save();
                break;
            default:
                break;
        }

        function saveform(stageDate) {

            formContext.setFieldValue(stageDate, new Date());
            CheckStageDateExists(stage);
            formContext.setFieldSubmitMode("new_stage");
            formContext.data.entity.save();
        }

        function ChangeFromMultistage() {
            if (stage !== "Multi-Stage") {
                var confirmText = "Caution: Deselecting Multi-Stage assumes all products are in the same Stage. This action will set all related Products to this Stage and Stage Date when you save this record. \n \n Are you sure you wish to proceed?";
                var confirmTitle = "Confirmation";
                formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                    function (success) {
                        if (success.confirmed) {
                            return true;
                        }
                        else {
                            return false;
                        }

                    });

            }
            return true;
        }

        // Call function to determine if subsequent stage dates exist and clear them if so after user confirms
        if (stage !== "" && stage !== "Multi-Stage") {
            CheckStageDateExists(stage);
        }

        function CheckStageDateExists(stage) {
            var stagedate = null;
            // Set stagedate to string of stagedates to be used later in function
            switch (stage) {
                case "Lead":
                    stagedate = ["new_designdate", "new_quoteddate", "new_ordereddate", "new_saledate", "new_lostdate"];
                    break;
                case "Design":
                    stagedate = ["new_quoteddate", "new_ordereddate", "new_saledate", "new_lostdate"];
                    break;
                case "Quote":
                    stagedate = ["new_ordereddate", "new_saledate", "new_lostdate"];
                    break;
                case "Lost":
                    break;
                default:
                    break;
            }

            if (stagedate) {
                for (let i = 0; i < stagedate.length; i++) {
                    var field = formContext.getAttribute(stagedate[i]);
                    if (field && field.getValue() !== null) { // if date exists
                        if (ConfimDateChange()) {
                            for (let j = 0; j < stagedate.length; j++) {
                                formContext.getAttribute(stagedate[j]).setValue(null); // Clear the date fields
                            }
                        } else {


                        }
                        break;
                    }
                }
            }
        }

        // Asks user if they really want to change the date and returns user response
        function ConfimDateChange() {

            var confirmText = "This project has a date in a Stage Date field that comes after or matches the Stage that you have selected. \nSelecting this earlier stage will remove the date from all subsequent Stage Date fields in this project record, and those of its Products. \nAre you sure you want to change the Stage?";
            var confirmTitle = "Confirmation";

            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    if (success.confirmed) {
                        return true;
                    }
                    else {
                        return false;
                    }

                });
        }
    }

    function onTabStateChangeOfActivities() {
        var tab = formContext.ui.tabs.get("activities"); // tab where Notes grid is
        if (tab) {
            if (tab.getDisplayState() === "expanded") {
                // run your logic when tab opens
                Quikrete.ISVFunctions.HideNotSubgridAddButtons("notes");
                Quikrete.ISVFunctions.HideActivitiesSubgridButton();
            }
        }
    }

    return {
        Init: init,
        FormOnLoad: formOnLoad
    }
}());