﻿var Quikrete = Quikrete || {};
Quikrete.PAMProduct = (function () {
    var formContext = null;
    var entityName = '', request = '';

    function init(executionContext) {
        formContext = executionContext?.getFormContext();
    }

    function callPublishAutomate(executionContext) {
        debugger;
        Xrm.Utility.showProgressIndicator("Please wait...");
        if (formContext === null) {
            formContext = executionContext;
        }

        try {
            var flowUrl = Quikrete.Common.PublishAPI;

            const response = fetch(flowUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({})
            });

            response.then(function (res) {
                if (res.ok) {
                    Xrm.Utility.alertDialog("Publish succeeded..!\n\nStatus Code: " + res.status + "\n" + "The PAM Product entity successfully published.");
                } else {
                    Xrm.Utility.alertDialog("Publish failed..! \n\nStatus Code: " + res.status + "\n" + "There another publish is running, cant  able to publish PAM Product entity.\nPlease try after some time.");
                }
                Xrm.Utility.closeProgressIndicator();
            });
        }
        catch (e) {
            Xrm.Utility.alertDialog("There is multiple publish running in background, please try after some time.");
            Xrm.Utility.closeProgressIndicator();
        }
    }

    return {
        Init: init,
        CallPublishAutomate: callPublishAutomate
    }
}());