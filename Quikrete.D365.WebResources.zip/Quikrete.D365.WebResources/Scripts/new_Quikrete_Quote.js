﻿var Quikrete = Quikrete || {};

Quikrete.Quote = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    var userHasAdministratorRole = false;
    var appName = "";

    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        // Configure Grid Control
        configGrid();

        // Override Create Order Dialog function
        formContext.data.addOnLoad(configureShowCreateOrderDialog);

        // Adds a function to be called when form data is loaded.
        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);
        //Adds a function to be called when the OnSave event is triggered.
        //The event occurs before the save occurs, giving the handler an option to cancel the save operation.

        if (formContext.getAttribute("billto_fax") != null)
            formContext.getAttribute("billto_fax").addOnChange(onChangeOfBillToFax);

        if (formContext.getAttribute("billto_telephone") != null)
            formContext.getAttribute("billto_telephone").addOnChange(onChangeOfBillToTelephone);

        if (formContext.getAttribute("new_copymanufacturinglocationtoallproducts") != null)
            formContext.getAttribute("new_copymanufacturinglocationtoallproducts").addOnChange(onChangeOfCopyMfgLocationtoAllProduct);

        if (formContext.getAttribute("new_copyrequesteddatetoallproducts") != null)
            formContext.getAttribute("new_copyrequesteddatetoallproducts").addOnChange(onChangeOfCopyRequestedDateToAllProducts);

        if (formContext.getAttribute("new_zipaddress1_lookup") != null)
            formContext.getAttribute("new_zipaddress1_lookup").addOnChange(onChangeOfAddress1ZipCode);

        if (formContext.getAttribute("shipto_telephone") != null)
            formContext.getAttribute("shipto_telephone").addOnChange(onChangeOfShipToTelephone);

        if (formContext.getAttribute("shipto_fax") != null)
            formContext.getAttribute("shipto_fax").addOnChange(onChangeOfShipToFax);

        if (formContext.getAttribute("new_requesteddate") != null)
            formContext.getAttribute("new_requesteddate").addOnChange(onChangeOfRequestedDate);

        if (formContext.getAttribute("customerid") != null)
            formContext.getAttribute("customerid").addOnChange(onChangeOfCustomer);

        if (formContext.getAttribute("new_bidderslistid") != null)
            formContext.getAttribute("new_bidderslistid").addOnChange(onChangeOfBidderList);

        if (formContext.getAttribute("new_freightsurcharge") != null)
            formContext.getAttribute("new_freightsurcharge").addOnChange(onChangeOfFreightCharge);

        if (formContext.getAttribute("freighttermscode") != null)
            formContext.getAttribute("freighttermscode").addOnChange(onChangeOfFreightTermsCode);

        // Soft bind sales person lookup change
        if (formContext.getAttribute("new_salesperson") != null)
            formContext.getAttribute("new_salesperson").addOnChange(onSalesPersonChange);

        // Soft bind enable of miles change
        if (formContext.getAttribute("new_enablenumberofmiles") != null)
            formContext.getAttribute("new_enablenumberofmiles").addOnChange(onChangeOfEnableOfMile);


        // Soft bind enable of calculate miles change
        if (formContext.getAttribute("new_calculatemiles") != null)
            formContext.getAttribute("new_calculatemiles").addOnChange(onChangeOfCalculateMiles);

        // --- Subgrid hiding: bind to tab expand ---
        if (formContext.ui.tabs.get("activities") != null)
            formContext.ui.tabs.get("activities").addTabStateChange(onTabStateChangeOfActivities);

        //---ExpectBidDateUnknow
        if (formContext.getAttribute("new_expectedbiddateunknown")) {
            formContext.getAttribute("new_expectedbiddateunknown").addOnChange(onChangeExpectBidDateUnknown);
        }
        //DOTPROJECT
        if (formContext.getAttribute("new_dotproject")) {
            formContext.getAttribute("new_dotproject").addOnChange(OnChangeDOTProject);
        }

    }

    function configGrid() {
        const grid = formContext.getControl("connections");
        if (!grid) return;

        const isCreate = formContext.getFormType() === Quikrete.Common.FormType.Create;

        const project = formContext.getAttribute("opportunityid")?.getValue();
        let recordId = isCreate ? null : project?.[0]?.id || formContext.data.entity.getId();

        // Use Guid.Empty for Create form
        recordId = recordId || "00000000-0000-0000-0000-000000000000";

        const filterXml =
            `<filter type='and'>
            <condition attribute='record1id' operator='eq' value='${recordId}' />
         </filter>`;

        grid.setFilterXml(filterXml);
        grid.refresh();
    }

    function OnChangeDOTProject() {
        formContext.clearFieldValidationMessage("new_dotproject");
        formContext.getAttribute("new_dotproject").setSubmitMode("always");
    }
    function configureShowCreateOrderDialog() {
        overrideCreateOrder();
        let acceptQuoteOrCreateFunction = Sales.QuoteRibbonActions.Instance.acceptQuoteOrCreateOrder;
        if (typeof (acceptQuoteOrCreateFunction) === "function") {
            Sales.QuoteRibbonActions.Instance.acceptQuoteOrCreateOrder = function () {
                var confirmText = "Are you sure you want to create an Order?\nClick OK to create the Order or click Cancel.";
                var confirmTitle = "Confirmation";
                formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                    async function (success) {
                        if (success.confirmed) {
                            var stateCodeAttribute = Xrm.Page.data.entity.attributes.get('statecode');
                            if (!stateCodeAttribute) {
                                return;
                            }
                            var stateCode = stateCodeAttribute.getValue();
                            if (stateCode === Sales.QuoteState.Active) {
                                let quoteId = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
                                await WonQuote(quoteId);
                                formContext.show('Creating Order');
                                Sales.QuoteRibbonActions.Instance.CreateOrder();
                            }
                            if (stateCode === Sales.QuoteState.Won) {
                                Sales.QuoteRibbonActions.Instance.CreateOrder();
                            }
                        }
                    });
            }

        }
    }

    function overrideCreateOrder() {
        let createOrder = Sales.QuoteRibbonActions.Instance.CreateOrder;
        if (typeof (createOrder) === "function") {
            Sales.QuoteRibbonActions.Instance.CreateOrder = function () {
                formContext.show('Please Wait');
                Sales.QuoteRibbonActions.Instance.checkCurrentUserisAdmin().then(function (isAdmin) {
                    if (isAdmin) {
                        Sales.QuoteRibbonActions.Instance.CreateQuoteToOrder();
                    }
                    else {
                        Sales.QuoteRibbonActions.Instance.IgnoreAttributeOnNonAdminMode();
                        Sales.QuoteRibbonActions.Instance.CreateQuoteToOrder();
                    }
                }).catch(function (error) { ClientUtility.ActionFailedHandler.actionFailedCallback; });

            }

        }

    }

    async function WonQuote(quoteId) {
        const request = {
            QuoteClose: {
                subject: "Quote Won",
                actualend: new Date(),
                "quoteid@odata.bind": `/quotes(${quoteId})`
            },
            Status: -1, // or 5 depending on your business status value

            getMetadata: function () {
                return {
                    boundParameter: null,
                    parameterTypes: {
                        "QuoteClose": {
                            typeName: "Microsoft.Dynamics.CRM.quoteclose",
                            structuralProperty: 5
                        },
                        "Status": {
                            typeName: "Edm.Int32",
                            structuralProperty: 1
                        }
                    },
                    operationType: 0, // Action
                    operationName: "WinQuote"
                };
            }
        };
        await formContext.execute(request)
    }
    async function onChangeOfShipToFax() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "shipto_fax");
    }

    async function onChangeOfBillToFax() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "billto_fax");
    }

    async function onChangeOfBillToTelephone() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "billto_telephone");
    }

    function onChangeOfCopyMfgLocationtoAllProduct() {
        var copyMfgLocationToProduct = formContext.getFieldValue("new_copymanufacturinglocationtoallproducts");
        if (copyMfgLocationToProduct == true) {
            formContext.makeFieldRequired("new_suggestedmanufacturinglocationid", true);
            var confirmText = "By checking this checkbox, this information will be copied to all products on this Quote. Click Ok to proceed or click Cancel.";
            var confirmTitle = "Confirmation";
            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    formContext.setFieldValue("new_copymanufacturinglocationtoallproducts", success.confirmed);

                    if (formContext.getFieldValue("new_numberofmiles") != null &&
                        (userBUID == Quikrete.Common.RinkerBU || userBUID == Quikrete.Common.FoleyBU
                            || userBUID == Quikrete.Common.OldCastleBU || userBUID == Quikrete.Common.USPipe)) {
                        if (formContext.getFieldValue("new_enablenumberofmiles") == false) {
                            formContext.setFieldValue("new_numberofmiles", null);
                        }
                    }
                    formContext.data.entity.save();
                });

        }
        else {
            formContext.makeFieldRequired("new_suggestedmanufacturinglocationid", false);
        }
    }

    function onChangeOfCopyRequestedDateToAllProducts() {
        var copyRequestedDate = formContext.getFieldValue("new_copyrequesteddatetoallproducts");
        if (copyRequestedDate == true) {
            var confirmText = "By Checking this checkbox, this information will be copied to all products on this Quote. Click Ok to proceed or click cancel.";
            var confirmTitle = "Confirmation";
            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    formContext.setFieldValue("new_copyrequesteddatetoallproducts", success.confirmed);
                    formContext.data.entity.save();
                });
        }
        else {
            formContext.makeFieldRequired("new_copyrequesteddatetoallproducts", false);
        }
    }

    async function onChangeOfAddress1ZipCode() {
        await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipaddress1_lookup", "new_cityaddress1_lookup", "new_stateaddress1_lookup", "new_countyaddress1_lookup", "new_countryaddress1_lookup");
    }
    async function onChangeOfShipToTelephone() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "shipto_telephone");
    }

    function onChangeOfRequestedDate() {

        var requestedDate = formContext.getFieldValue("new_requesteddate");
        if (requestedDate !== null) {
            requestedDate.setHours(requestedDate.getHours() + 12, 0, 0); // Add 12 hours and set minutes/seconds to 0
            formContext.setFieldValue("new_requesteddate", requestedDate);
        }
    }

    async function onChangeOfCustomer() {
        var customer = formContext.getFieldValue("customerid");

        if (customer && customer.length > 0) {
            var customerId = customer[0].id;
            var entityType = customer[0].entityType;
            var entAccount = null;

            if (entityType === "account") {
                const queryParam = `?$select=_ownerid_value,address2_line1,address2_line2,address2_line3,address2_postalcode,address2_city,address2_stateorprovince,address2_county,address2_country,address2_telephone1,address2_fax,emailaddress2,_new_zipaddress2_lookup_value,_new_cityaddress2_lookup_value,_new_countyaddress2_lookup_value,_new_countryaddress2_lookup_value`;
                entAccount = await formContext.retrieveRecord("account", customerId, queryParam);

                if (entAccount != null) {
                    var accountOwner = entAccount["_ownerid_value@OData.Community.Display.V1.FormattedValue"];
                    var billto_postalcode = entAccount["_new_zipaddress2_lookup_value@OData.Community.Display.V1.FormattedValue"];
                    var billto_city = entAccount["_new_cityaddress2_lookup_value@OData.Community.Display.V1.FormattedValue"];
                    var billto_country = entAccount["_new_countryaddress2_lookup_value@OData.Community.Display.V1.FormattedValue"];
                    var billto_county = entAccount["_new_countyaddress2_lookup_value@OData.Community.Display.V1.FormattedValue"];

                    formContext.setFieldValue("new_accountowner", accountOwner || null);
                    formContext.setFieldValue("billto_line1", entAccount.address2_line1 || null);
                    formContext.setFieldValue("billto_line2", entAccount.address2_line2 || null);
                    formContext.setFieldValue("billto_line3", entAccount.address2_line3 || null);
                    formContext.setFieldValue("billto_postalcode", billto_postalcode || null);
                    formContext.setFieldValue("billto_city", billto_city || null);
                    formContext.setFieldValue("billto_country", billto_country || null);
                    formContext.setFieldValue("new_countybt", billto_county || null);
                    formContext.setFieldValue("billto_telephone", entAccount.address2_telephone1 || null);
                    formContext.setFieldValue("billto_fax", entAccount.address2_fax || null);
                    formContext.setFieldValue("billto_stateorprovince", entAccount.address2_stateorprovince || null);
                    formContext.setFieldValue("new_billtoemailaddress", entAccount.emailaddress2 || null);
                }
            }
        }
    }

    function onChangeOfFreightCharge() {
        var freightSurCharge = (formContext.getFieldValue("new_freightsurcharge")) || 0.00;
        var fuelCharge = (formContext.getFieldValue("new_fuelcharge")) || 0.00;
        var freightAmount = (formContext.getFieldValue("freightamount")) || 0.00;
        var calFreightAmount = freightSurCharge + fuelCharge;
        if (freightAmount != 0 || calFreightAmount != 0) {
            formContext.setFieldValue("freightamount", calFreightAmount);
        }
    }

    function OnchangeOfFuelCode() {
        if (formContext.getFieldValue("new_fuelcode") != null) {
            formContext.setFieldValue("new_fuelcharge", null);
            formContext.makeFieldDisabled("new_fuelcharge", true);
            formContext.setFieldSubmitMode("new_fuelcharge");
        }
        else {
            formContext.makeFieldDisabled("new_fuelcharge", false);
        }
        onChangeOfFreightCharge();


    }

    function onChangeOfFreightTermsCode() {
        var freightTermsCode = formContext.getFieldValueText("freighttermscode");
        if (freightTermsCode != '') {
            var fcode = freightTermsCode.substring(freightTermsCode.indexOf("(") + 1, freightTermsCode.indexOf(")"));
            if (fcode === 'COL') {
                formContext.setFieldValue("new_fuelcode", 7);
                formContext.setFieldSubmitMode("new_fuelcode");
                formContext.setFieldValue("new_freightsurcharge", null);
                formContext.makeFieldDisabled("new_freightsurcharge", true);
                formContext.setFieldSubmitMode("new_freightsurcharge");
            }
            else if (fcode === 'CPU') {
                formContext.setFieldValue("new_fuelcode", 5);
                formContext.setFieldSubmitMode("new_fuelcode");
                formContext.setFieldValue("new_freightsurcharge", null);
                formContext.makeFieldDisabled("new_freightsurcharge", true);
                formContext.setFieldSubmitMode("new_freightsurcharge");
            }
            else {
                if (fcode === 'PPD') {
                    formContext.setFieldValue("new_freightsurcharge", null);
                    formContext.makeFieldDisabled("new_freightsurcharge", true);
                    formContext.setFieldSubmitMode("new_freightsurcharge");
                } else {
                    formContext.makeFieldDisabled("new_freightsurcharge", false);
                }
            }
        }
        else {
            formContext.makeFieldDisabled("new_freightsurcharge", false);
        }
        OnchangeOfFuelCode();
        disableFreightTermsControl();
    }

    function onChangeOfBidderList() {
        formContext.data.entity.save();
    }

    function disableFreightTermsControl() {
        let freightTerms = formContext.getFieldValueText("freighttermscode");
        let fuelCode = formContext.getFieldValueText("new_fuelcode");

        if (freightTerms == 'Collect (COL)' || freightTerms == 'Customer Pick Up (CPU)' || freightTerms == 'Prepaid (PPD)') {

            formContext.makeFieldDisabled("new_freightsurcharge");
            //formContext.setFieldValue("new_freightsurcharge", null);

            if ((freightTerms == 'Collect (COL)' || freightTerms == 'Customer Pick Up (CPU)') && fuelCode != null) {

                formContext.makeFieldDisabled("new_fuelcharge");
                formContext.setFieldValue("new_fuelcharge", null);

            } else if (freightTerms == 'Prepaid (PPD)' && fuelCode == null) {
                formContext.makeFieldDisabled("new_fuelcharge", false);
                formContext.setFieldValue("new_fuelcharge", null);
            }
        } else if (freightTerms == 'PPA Port Col Dest (PPAPCD)' || freightTerms == 'Prepaid & Add (PPA)' || freightTerms == 'Prepaid & Add Port (PPAP)' || freightTerms == 'Prepaid Port (PPDP)') {

            formContext.makeFieldDisabled("new_freightsurcharge", false);
        } else if (freightTerms == null) {
            formContext.makeFieldDisabled("new_freightsurcharge", false);
        }
    }

    async function formOnLoad() {
        var buid = formContext.getAttribute('owningbusinessunit')?.getValue();

        if (buid && buid.length > 0 && buid[0].id) {
            userBUID = buid[0].id.replace(/[{}]/g, "");
        } else {
            userID = formContext.getCurrentUserId();
            userBUID = await formContext.getBusinessUnit(userID);
        }

        userHasAdministratorRole = formContext.isUserAdministrator();

        appName = await formContext.getCurrentAppUniqueName();
        //Skip event binding if app is for Quikrete Hardscapes Sales Hub
        if (appName.toLowerCase() == "new_quikretehardscapessaleshub") {
            formOnLoadForHardScapes();
            return; // Exits the function here
        }

        //Filter Manufaturing Location By Buisness Unit Id.
        Quikrete.ISVFunctions.FilterLookup(formContext, "new_manufacturinglocationid", userBUID, "new_owningbusinessunit");

        var formType = formContext.getFormType();
        if (formType === Quikrete.Common.FormType.Create || formType === Quikrete.Common.FormType.Update) {

            formContext.setFieldValue("willcall", false);

            if (formContext.getFieldValue("new_copymanufacturinglocationtoallproducts") === true) {
                formContext.setFieldValue("new_copymanufacturinglocationtoallproducts", false);
            }
            if (formContext.getFieldValue("new_copyrequesteddatetoallproducts") === true) {

                formContext.setFieldValue("new_copyrequesteddatetoallproducts", false);
            }
            formContext.setFieldSubmitMode("freightamount");
            formContext.setFieldSubmitMode("new_marketapplication");
            var alertValue = formContext.getFieldValue("new_alert");
            if (alertValue == null || alertValue === false) {
                if (formContext.getFieldValue("new_accounthold") === 1) {

                    var potentialCustomer = formContext.getFieldValue("customerid");
                    var potentialCustomerName = potentialCustomer[0].name;
                    var confirmText = "Potential Customer:" + " " + potentialCustomerName + " " + "is on credit hold";
                    var confirmTitle = "Confirmation";
                    formContext.openAlertDialog(confirmTitle, confirmText);
                    formContext.setFieldValue("new_alert", true);
                }
            }

            if (formType === Quikrete.Common.FormType.Update) {

                OnchangeOfFuelCode();
                if (formContext.getFieldValue("freighttermscode") != null) {
                    var freightTermsCode = formContext.getFieldValue("freighttermscode");
                    freightTermsCode = formContext.getFieldValueText("freighttermscode");
                    if (freightTermsCode != '') {
                        var fcode = freightTermsCode.substring(freightTermsCode.indexOf("(") + 1, freightTermsCode.indexOf(")"));
                        if (fcode === 'COL' || fcode === 'CPU' || fcode === 'PPD') {
                            // formContext.setFieldValue("new_freightsurcharge", null);
                            formContext.makeFieldDisabled("new_freightsurcharge", true);
                            formContext.setFieldSubmitMode("new_freightsurcharge");
                        }
                        else {
                            formContext.makeFieldDisabled("new_freightsurcharge", false);
                        }

                    }
                    else {
                        formContext.makeFieldDisabled("new_freightsurcharge", false);
                    }
                }

            }
        }
        if (formType === Quikrete.Common.FormType.ReadOnly || formType === Quikrete.Common.FormType.Disabled) {
            formContext.makeFieldRequired("shipto_postalcode", false);
        }
        if (formType == Quikrete.Common.FormType.Create) {
            var attribute = formContext.getAttribute("new_dotproject");
            var control = formContext.getControl("new_dotproject");
            attribute.setRequiredLevel("none");
            attribute.setValue(null);
            control.clearNotification();
            attribute.setRequiredLevel("required");
        }
        formContext.makeFieldDisabled("new_marketapplication", true);
        if (formContext.getFieldValue("opportunityid") != null) {
            formContext.makeFieldDisabled("customerid", true);
            formContext.makeFieldVisible("customerid", false);
            formContext.makeFieldRequired("customerid", false);
            formContext.makeFieldRequired("new_bidderslistid", true);
            formContext.makeFieldVisible("new_accountowner", false);
        }
        else {
            formContext.makeFieldVisible("new_bidderslistid", false);
            formContext.makeFieldVisible("opportunityid", false);
            formContext.makeFieldVisible("new_projectnumber", false);
            formContext.makeFieldVisible("new_accountowner", false);
        }
        formContext.makeFieldDisabled("opportunityid", true);
        formContext.makeFieldDisabled("quotenumber", true);

        if (formContext.getFieldValue("new_markasdelete") === true) {
            formContext.makeFieldRequired("name", false);
            formContext.makeFieldRequired("new_endmarketsubtype", false);
            formContext.makeFieldRequired("new_marketapplication", false);
            formContext.makeFieldRequired("pricelevelid", false);
            formContext.makeFieldRequired("customerid", false);
            formContext.makeFieldRequired("ownerid", false);
            formContext.makeFieldRequired("new_bidderslistid", false);
        }
        else {
            formContext.makeFieldRequired("name", true);
            formContext.makeFieldRequired("new_endmarketsubtype", true);
            formContext.makeFieldRequired("new_marketapplication", true);
            formContext.makeFieldRequired("pricelevelid", true);
            formContext.makeFieldRequired("customerid", true);
            formContext.makeFieldRequired("ownerid", true);
            if (formContext.getFieldValue("opportunityid") != null) {
                formContext.makeFieldRequired("new_bidderslistid", true);
            }

        }
        await Quikrete.ISVFunctions.HandleSharePointFileTab(formContext);
        onChangeExpectBidDateUnknown();

    }

    // on Sales Person Change
    async function onSalesPersonChange() {
        await Quikrete.ISVFunctions.onSalesPersonChange(formContext, "new_salesperson", "new_salespersonnumber");
    }

    async function formOnSave(executionContext) {
        var eventArgs = executionContext.getEventArgs();
        const saveMode = eventArgs.getSaveMode();

        if (formContext.getFieldValue("new_biddate") == null && (formContext.getFieldValue("new_expectedbiddateunknown") === 0 || formContext.getFieldValue("new_expectedbiddateunknown") == false)) {
            formContext.setFieldValidationMessage("new_biddate", "Expected Bid Date is required. If unknown, toggle Expected Bid Date Unknown.");
            formContext.makeFieldRequired("new_biddate", "required");
            var confirmText = "Please provide an Expected Bid Date / Time. If the information is currently not available, check the Expected Bid Date Unknown Checkbox";
            var confirmTitle = "Confirmation";
            formContext.openAlertDialog(confirmTitle, confirmText)
            formContext.getControl("new_biddate").setFocus(true);
            if (executionContext != null) {
                var eventArgs = executionContext.getEventArgs();
                eventArgs.preventDefault();
                return;
            }
            return;
        }
        var dotProject = formContext.getAttribute("new_dotproject").getValue();
        if (dotProject === null) {

            formContext.getControl("new_dotproject").setNotification(
                "DOT Project is required.",
                "DOT_REQUIRED"
            );
            var eventArgs = executionContext.getEventArgs();
            eventArgs.preventDefault();
            return;
        }

    }

    async function onChangeOfEnableOfMile() {

        var formType = formContext.getFormType();
        var enablenumberofmiles = formContext.getFieldValue("new_enablenumberofmiles");
        if (enablenumberofmiles != null && (formType === Quikrete.Common.FormType.Create || formType === Quikrete.Common.FormType.Update)) {
            if (enablenumberofmiles === false) {
                onChangeOfCalculateMiles();
            }
        }
    }

    function onChangeExpectBidDateUnknown() {

        var bidDateUnknown = formContext.getFieldValue("new_expectedbiddateunknown");
        var bidDate = formContext.getFieldValue("new_biddate");

        if (bidDateUnknown === false && !bidDate) {
            formContext.makeFieldRequired("new_biddate", "required");
        }

        else if (bidDateUnknown === false && bidDate) {
            formContext.makeFieldRequired("new_biddate", false);
            formContext.makeFieldDisabled("new_expectedbiddateunknown", true);
        }
        else {
            formContext.makeFieldRequired("new_biddate", false);
        }
    }

    async function onChangeOfCalculateMiles() {
        var calculatemiles = formContext.getFieldValue("new_calculatemiles");
        var entityZipCode = formContext.getFieldValue("new_zipaddress1_lookup")[0]?.name;
        var mfgLocation = formContext.getFieldValue("new_suggestedmanufacturinglocationid")[0];

        if (calculatemiles == true && entityZipCode && mfgLocation) {
            var mfgid = mfgLocation?.id.replace('{', '').replace('}', '');
            var mfgLocationResponse = await formContext.retrieveMultipleRecords("new_manufacturinglocation", "?$select=_new_manufacturinglocationzipcode_lookup_value&$filter=new_manufacturinglocationid eq " + mfgid);

            if (mfgLocationResponse.length > 0) {
                var mfgLocationEntity = mfgLocationResponse[0];
                var mfgzipCode = mfgLocationEntity["_new_manufacturinglocationzipcode_lookup_value@OData.Community.Display.V1.FormattedValue"];
                var miles = await Quikrete.ISVFunctions.GetMiles(entityZipCode, mfgzipCode);
                formContext.setFieldValue("new_numberofmiles", miles);

            } else {
                formContext.setFieldValue("new_numberofmiles", null);
            }
        } else {
            formContext.setFieldValue("new_numberofmiles", null);
        }
        formContext.setFieldValue("new_calculatemiles", false);
    }

    async function validateBeforeActive(primaryControl) {
        const formContext = primaryControl;
        const quoteId = formContext.data.entity.getId().replace(/[{}]/g, "");

        // Check Freight Terms required
        formContext.makeFieldRequired("freighttermscode", true);

        // U.S. Pipe business unit check
        if (userBUID === Quikrete.Common.USPipe) {
            formContext.makeFieldRequired("new_biddate", true);
        }

        // Past bid date check
        const bidDateVal = formContext.getFieldValue("new_biddate");
        if (bidDateVal) {
            const bidDate = new Date(bidDateVal);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            if (bidDate < today) {

                const text = "The Expected Bid Date is in the past. To continue Activating the Quote, select Ok.\n\nSelect Cancel if you would like to postpone the Quote Activation and update the Expected Bid Date.";
                const result = await formContext.openConfirmationDialog("Warning", text);

                if (!result.confirmed) {
                    return false;
                }
            }
        }

        if (!formContext.data.isValid()) {
            // Let OOB UI handle highlighting
            Xrm.Page.data.save();
            return false;
        }

        // Retrieve Quote Products via Web API
        const quoteDetails = await formContext.retrieveMultipleRecords(
            "quotedetail",
            `?$select=_new_manufacturinglocationid_value,new_productnumber,_productid_value
            &$filter=_quoteid_value eq ${quoteId}
            &$expand=productid($select=productnumber,new_length,_new_lengthuom_value,statecode,statuscode,_new_family_value)`
        );

        // Product validation deactivation check
        if (quoteDetails) {
            for (const quoteproduct of quoteDetails) {
                if (quoteproduct._productid_value) {
                    let productNode = quoteproduct.productid;
                    if (productNode.statecode === 1 && productNode.statuscode === 2) {
                        formContext.openAlertDialog('Warning', `Part Number ${productNode.productnumber} has been deactivated. Please remove or replace with a valid, active part number in order to activate this Quote.`)
                        return false;
                    }
                }
            }
        }

        // CMP Detention frames & grates check
        let shipState = "";
        const shipStatelookup = formContext.getFieldValue("new_stateaddress1_lookup");
        if (shipStatelookup != null && shipStatelookup.length > 0) {
            shipState = shipStatelookup[0].name;
        }

        if (["TX", "NM", "AZ"].includes(shipState)) {
            const productFamilyRequired = ["CMP Detention"];
            const productMainMap = [
                "HA325-000332",
                "HA325-000350",
                "HA325-003897",
                "HA325-003898",
                "1241008",
                "1241009",
                "1241020",
                "1241021",
                "1249595",
                "1249596"
            ];

            const families = quoteDetails.map(q =>
                (q.productid['_new_family_value@OData.Community.Display.V1.FormattedValue'] || "").trim()
            );

            const productnumbers = quoteDetails.map(q => (q.new_productnumber || "").trim().toUpperCase());

            let isFamilyFound = families.some(f => productFamilyRequired.includes(f));
            let isProductFound = productnumbers.some(p => productMainMap.includes(p));

            if (isFamilyFound && !isProductFound) {
                formContext.openAlertDialog('Warning', "This Quote requires Frames & Grates for the CMP Detention. Please add the appropriate F&G part(s) to the Quote using Get Project Products before activating.");
                return false;
            }
        }

        // If all validations pass → Activate Quote
        Sales.QuoteRibbonActions.Instance.activateQuote();
    }

    function onTabStateChangeOfActivities() {
        var tab = formContext.ui.tabs.get("activities"); // tab where Notes grid is
        if (tab) {
            if (tab.getDisplayState() === "expanded") {
                // run your logic when tab opens
                Quikrete.ISVFunctions.HideNotSubgridAddButtons("notes");
                Quikrete.ISVFunctions.HideActivitiesSubgridButton();
            }
        }
    }

    return {
        Init: init,
        FormOnLoad: formOnLoad,
        FormOnSave: formOnSave,
        OnChangeOfBillToFax: onChangeOfBillToFax,
        OnChangeOfBillToTelephone: onChangeOfBillToTelephone,
        OnChangeOfCopyMfgLocationtoAllProduct: onChangeOfCopyMfgLocationtoAllProduct,
        OnChangeOfCopyRequestedDateToAllProducts: onChangeOfCopyRequestedDateToAllProducts,
        OnChangeOfAddress1ZipCode: onChangeOfAddress1ZipCode,
        OnChangeOfShipToTelephone: onChangeOfShipToTelephone,
        ValidateBeforeActive: validateBeforeActive
    }
}());