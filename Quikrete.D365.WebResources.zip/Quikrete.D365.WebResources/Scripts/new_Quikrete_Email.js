﻿var Quikrete = Quikrete || {};
Quikrete.Email = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    const categoryArr = { outboundEmail: [12, 6, 7, 8, 9, 10, 11] }
    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        // Adds a function to be called when form data is loaded.
        formContext.data.addOnLoad(formOnLoad);

        //call function on change of category
        if (formContext.getAttribute("new_category") != null)
            formContext.getAttribute("new_category").addOnChange(onChangeOfCategory);
        // call function on change of regarding 
        if (formContext.getAttribute("regardingobjectid") != null)
            formContext.getAttribute("regardingobjectid").addOnChange(onChangeOfRegardingObject);
    }


    async function formOnLoad() {

        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);

        //Set focus on "To"
        formContext.getControl("to").setFocus();

        //we do not require to add button logic in online javascript it is provided by OOB feature
        //we do not require to add tab hide show logic in online CRM

        // Get form type
        var formType = formContext.getFormType();
        if (formType === Quikrete.Common.FormType.Create) { // Form type 1: Create

            //when form type is create set scheduled date as currentDate
            formContext.setFieldValue("scheduledend", new Date());
        }
        onChangeOfRegardingObject();

    }

    function setVisibleFields(isVisisble) {
        formContext.makeFieldVisible("new_activitylineitemno", isVisisble);
        formContext.makeFieldVisible("new_productdescription", isVisisble);

    }

    function onChangeOfRegardingObject() {

        //if regardingobject is opportunity then show Product Line Item and Product description
        var regardingobjectid = formContext.getFieldValue("regardingobjectid");
        if (regardingobjectid != null) {
            if (regardingobjectid[0].entityType != 'opportunity') {
                setVisibleFields(false);
            }
            else {
                setVisibleFields(true);
            }
        }
        else {
            setVisibleFields(false);
        }

    }
    function onChangeOfCategory() {

        var category = formContext.getFieldValue("new_category");
        var subCategory = formContext.ui.controls.get("new_subcategory");
        var optionSetValues = subCategory.getAttribute().getOptions();
        subCategory.clearOptions();

        optionSetValues.forEach(function (element) {
            if (category == "100000000") { //100000000 eq Outbound Email
                if (categoryArr.outboundEmail.includes(element.value))
                    subCategory.addOption(element);
                formContext.makeFieldRequired("new_subcategory", true);
            }
            else {
                formContext.makeFieldRequired("new_subcategory", false);
            }

        }
        );
    }

    return {
        Init: init,
        FormOnLoad: formOnLoad,

    }
}());
