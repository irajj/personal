﻿var Quikrete = Quikrete || {};

Quikrete.Phonecall = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    var isAddress1ZipcodeValid = false;

    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        if (formContext.getAttribute("phonenumber") != null)
            formContext.getAttribute("phonenumber").addOnChange(onChangeOfPhonenumber);
    }


    async function onChangeOfPhonenumber() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "phonenumber");
    }

    return {
        Init: init,
    }
}());