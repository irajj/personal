﻿var Quikrete = Quikrete || {};

Quikrete.ProductTodo = (function () {
    var eventsAttached = false;
    var formContext = null;


    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        top.formContext = formContext;
        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;
        formContext.data.addOnLoad(formOnLoad);
        if (formContext.getAttribute("regardingobjectid") != null)
            formContext.getAttribute("regardingobjectid").addOnChange(onChangeOfRegardingobject);
    }

    async function formOnLoad() {

        onChangeOfRegardingobject();
        if (formContext.getFormType() == Quikrete.Common.FormType.Create && formContext.getAttribute("scheduledend")) {
            formContext.setFieldValue("scheduledend", new Date());
        }

    }
    async function cloneRecord() {

        const sourceEntity = "new_producttodo";

        const productEntityFields = {
            statecode: formContext.getFieldValue("statecode"),
            new_category: formContext.getFieldValue("new_category"),
            description: formContext.getFieldValue("description"),
            scheduledend: formContext.getFieldValue("scheduledend"),
            prioritycode: formContext.getFieldValue("prioritycode"),
            new_productdescription: formContext.getFieldValue("new_productdescription"),
            subject: formContext.getFieldValue("subject"),

            projectproductlineitem: formContext.getFieldValue("new_projectproductlineitem") != null ? formContext.getFieldValue("new_projectproductlineitem")[0] : null,
            regardingobject: formContext.getFieldValue("regardingobjectid") != null ? formContext.getFieldValue("regardingobjectid")[0] : null,
            owner: formContext.getFieldValue("ownerid") != null ? formContext.getFieldValue("ownerid")[0] : null,

        };

        var projectproductentityname = productEntityFields?.projectproductlineitem?.entityType;
        var projectproductentityid = productEntityFields?.projectproductlineitem?.id.replace('{', '').replace('}', '');

        var ownerentityname = productEntityFields?.owner?.entityType;
        var ownerid = productEntityFields?.owner?.id.replace('{', '').replace('}', '');

        var regardingid = productEntityFields?.regardingobject?.id.replace('{', '').replace('}', '');
        var regardingentityname = productEntityFields?.regardingobject?.entityType;

        var regardigEntityMetaData = null;

        if (regardingid) {
            regardigEntityMetaData = await formContext.getentityMetadata(regardingentityname, []);
        }

        var ownerEntityMetaData = null;
        if (ownerid) {
            ownerEntityMetaData = await formContext.getentityMetadata(ownerentityname, []);
        }


        const cloneRecordField = {
            subject: productEntityFields.subject ?? '',
            description: productEntityFields.description ?? '',
            prioritycode: productEntityFields.prioritycode,
            scheduledend: productEntityFields.scheduledend,
            new_category: productEntityFields.new_category,
            new_productdescription: productEntityFields.new_productdescription,
        };

        //Regarding Field 
        if (regardingid) {
            cloneRecordField[`regardingobjectid_${regardigEntityMetaData.LogicalName}_new_producttodo@odata.bind`] = `/${regardigEntityMetaData?.EntitySetName}(${regardingid})`;
        }

        //Owner Field 
        if (ownerid) {
            cloneRecordField["ownerid_new_producttodo@odata.bind"] = `/${ownerEntityMetaData?.EntitySetName}(${ownerid})`;
        }
        //Product Project
        if (projectproductentityid) {
            cloneRecordField["new_projectproductlineitem_new_producttodo@odata.bind"] = `/opportunityproducts(${projectproductentityid})`;
        }

        try {
            const cloneRecordID = await formContext.createRecord(sourceEntity, cloneRecordField);

            var entityFormOptions = {
                entityName: "new_producttodo",
                entityId: cloneRecordID.id,
                openInNewWindow: true,
                navbar: "off",
                height: 600,
                width: 800
            };

            formContext.openForm(entityFormOptions);
        } catch (error) {
            console.error("Error while cloning the record: ", error);
        }
    }

    async function onChangeOfRegardingobject() {
        var regardingobjectid = formContext.getFieldValue("regardingobjectid");
        if (regardingobjectid != null) {
            if (regardingobjectid[0].entityType == 'opportunity') {
                formContext.makeFieldVisible("new_quoteproductlineitem", false);
                formContext.makeFieldVisible("new_orderproductlineitem", false);
            }
            if (regardingobjectid[0].entityType == 'quote') {
                formContext.makeFieldVisible("new_projectproductlineitem", false);
                formContext.makeFieldVisible("new_orderproductlineitem", false);
            }
            if (regardingobjectid[0].entityType == 'salesorder') {
                formContext.makeFieldVisible("new_projectproductlineitem", false);
                formContext.makeFieldVisible("new_quoteproductlineitem", false);
            }
        }

    }

    return {
        Init: init,
        CloneRecord: cloneRecord,
        OnChangeOfRegardingobject: onChangeOfRegardingobject

    }
}());