﻿var Quikrete = Quikrete || {};

Quikrete.SalesOrderDetail = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    var originalMilestoneValues = {};
    var recordBuid = null;
    var isdiscountpercentchange = false
    function init(executionContext) {
        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();
        top.FormContext = formContext;
        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        // Adds a function to be called when form data is loaded.
        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);
        formContext.data.entity.addOnPostSave(onPostSaveHandler)
        // call function on change of price per unit
        if (formContext.getAttribute("priceperunit") != null)
            formContext.getAttribute("priceperunit").addOnChange(onChangeOfPricePerUnit);

        // call function on change of Pcs/qty
        if (formContext.getAttribute("new_pcs") != null)
            formContext.getAttribute("new_pcs").addOnChange(onChangeOfPcsPerQty);

        // call function on change of discount percentage
        if (formContext.getAttribute("new_discountpercent") != null)
            formContext.getAttribute("new_discountpercent").addOnChange(onChangeOfDiscountPercentage);

        // call function on change of Manual Discount Amount
        if (formContext.getAttribute("manualdiscountamount") != null)
            formContext.getAttribute("manualdiscountamount").addOnChange(onChangeOfManualDiscount);

        // Milestone Dates
        const milestoneFields = [
            "requestdeliveryby",
            "new_sdi",
            "new_sda",
            "new_fabricationdrawingissued",
            "new_fabricationdrawingapproved"
        ];

        milestoneFields.forEach((fieldName, index) => {
            const attribute = formContext.getAttribute(fieldName);
            if (attribute) {
                originalMilestoneValues[fieldName] = attribute.getValue(); // Capture original value
                attribute.addOnChange(() => handleMilestoneChange(fieldName, index));
            }
        });

        // call function on change of UOM
        if (formContext.getAttribute("uomid") != null)
            formContext.getAttribute("uomid").addOnChange(onChangeOfUOMId);
    }

    function handleMilestoneChange(attributeName, index) {

        const attribute = formContext.getAttribute(attributeName);
        const currentValue = attribute.getValue();
        const originalValue = originalMilestoneValues[attributeName];

        let datestobecopiedAttr = formContext.getAttribute("new_datestobecopied");
        let currentDigits = datestobecopiedAttr.getValue() || "";
        let digitsArray = currentDigits.split('').filter(char => char !== '');

        const digit = index.toString();
        const isChanged = !areDatesEqual(currentValue, originalValue);

        if (isChanged && !digitsArray.includes(digit)) {
            digitsArray.push(digit);
        } else if (!isChanged && digitsArray.includes(digit)) {
            digitsArray = digitsArray.filter(d => d !== digit);
        }

        // Sort numerically and update the field
        digitsArray.sort((a, b) => parseInt(a) - parseInt(b));
        datestobecopiedAttr.setValue(digitsArray.join(''));
    }

    function areDatesEqual(date1, date2) {
        if (!date1 && !date2) return true;
        if (!date1 || !date2) return false;

        return (
            date1.getFullYear() === date2.getFullYear() &&
            date1.getMonth() === date2.getMonth() &&
            date1.getDate() === date2.getDate()
        );
    }


    async function formOnLoad() {

        var formType = formContext.getFormType();
        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);
        recordBuid = await Quikrete.ISVFunctions.GetRecordBuidFromLookup(formContext, "salesorderid");

        formContext.setFieldSubmitMode("new_productcode");
        formContext.setFieldSubmitMode("new_segment_lookup");
        formContext.setFieldSubmitMode("new_supersegment_lookup");

        formContext.setFieldSubmitMode("quantity");
        formContext.setFieldSubmitMode("new_priceperpound");
        formContext.setFieldSubmitMode("new_extendedpriceperunit");
        formContext.setFieldSubmitMode("new_productdescriptioneditable");
        formContext.setFieldSubmitMode("new_altproductdescription");
        formContext.setFieldSubmitMode("new_totalweight");
        formContext.setFieldSubmitMode("new_weightperunit");
        formContext.setFieldSubmitMode("new_weightuom");


        //Filter Manufaturing Location By Buisness Unit Id.
        Quikrete.ISVFunctions.FilterLookup(formContext, "new_manufacturinglocationid", recordBuid, "new_owningbusinessunit");


        //*********** MileStones Dates Logic Starts*******************************************************

        var LineSequenceNo = null;
        var GPOrderNumber = null;

        if (formContext.getFieldValue("lineitemnumber") != null)
            LineSequenceNo = formContext.getFieldValue("lineitemnumber");

        if (formContext.getFieldValue("new_gpordernumber") != null)
            GPOrderNumber = formContext.getFieldValue("new_gpordernumber");

        //Xrm.Page.getControl('IFRAME_MilestoneDates').setSrc(GetCustomPageLocationURL() + '/MilestoneDates.aspx?SalesOrderId=' + Xrm.Page.getAttribute("salesorderid").getValue() + '&LineSequenceNo=' + LineSequenceNo + '&GPOrderNumber=' + GPOrderNumber + "&ORGUNIQUENAME=" + Xrm.Page.context.getOrgUniqueName());

        //*********** MileStones Dates Logic Ends**********************************************************
        formContext.setFieldSubmitMode("shipto_city");
        formContext.setFieldSubmitMode("new_leadtime");
        formContext.setFieldSubmitMode("new_rtm");

        if (formType === Quikrete.Common.FormType.Update) {
            if (formContext.getFieldValue("new_leadtime") != null) {
                if (formContext.getFieldValue("new_leadtime") == 0) {
                    formContext.setFieldValue("new_leadtime", null);
                }
            }
        }
        var salesOrderDotProject = null, salesOrderManufacturingId = null, requestedDate = null;
        if (formType === Quikrete.Common.FormType.Create) { // Form type 1: Create
            formContext.setFieldValue("quantity", 1.0);
            formContext.setFieldValue("new_pcs", 1.0);
            var salesOrder = formContext.getFieldValue("salesorderid");
            if (salesOrder) {
                var salesOrderID = salesOrder[0].id;
                const queryParameterForOrder = `?$select=new_dotproject,_new_suggestedmanufacturinglocationid_value,new_requesteddate`;
                var salesOrderResponse = await formContext.retrieveRecord("salesorder", salesOrderID, queryParameterForOrder);
                if (salesOrderResponse) {
                    salesOrderDotProject = salesOrderResponse.new_dotproject;
                    if (salesOrderDotProject == "1") {

                        formContext.setFieldValue("new_followdotspecs", true);
                    }
                    else {
                        formContext.setFieldValue("new_followdotspecs", false);
                    }
                    salesOrderManufacturingId = salesOrderResponse._new_suggestedmanufacturinglocationid_value;
                    if (salesOrderManufacturingId) {
                        var lookupValue = new Array();
                        lookupValue[0] = new Object();

                        lookupValue[0].id = salesOrderResponse["_new_suggestedmanufacturinglocationid_value"];
                        lookupValue[0].name = salesOrderResponse["_new_suggestedmanufacturinglocationid_value@OData.Community.Display.V1.FormattedValue"];
                        lookupValue[0].entityType = salesOrderResponse["_new_suggestedmanufacturinglocationid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        formContext.setFieldValue("new_manufacturinglocationid", lookupValue);
                    }
                    requestedDate = salesOrderResponse["new_requesteddate@OData.Community.Display.V1.FormattedValue"];
                    if (requestedDate != null) {
                        var date = new Date(requestedDate);
                        formContext.setFieldValue("requestdeliveryby", date);
                    }
                }
            }
        }
        if (formType === Quikrete.Common.FormType.Update || formType === Quikrete.Common.FormType.Readonly || formType === Quikrete.Common.FormType.Disabled) {

            if (formContext.getFieldValue("lineitemnumber") != null) {
                formContext.makeFieldVisible("new_sequencechange", false);
            }
        }

        if (formContext.getFieldValue("new_productnumber") != null) {
            var product = formContext.getFieldValue("productid");
            var productId = product[0].id;
            validateSourceSystem(productId);
        }

        if (formContext.getFieldValue("new_productnumber") == "700009") {
            formContext.makeFieldDisabled("new_productdescriptioneditable", false);
        }
        setPricingfields(formType);
    }

    function setPricingfields(formType) {

        formContext.setFieldValue("isproductoverridden", false);
        formContext.getAttribute("isproductoverridden").fireOnChange();

        if (recordBuid.toUpperCase() === Quikrete.Common.RinkerBU) {
            formContext.setFieldValue("ispriceoverridden", false);
        }
        else {
            formContext.setFieldValue("ispriceoverridden", true);
        }

        formContext.getAttribute("ispriceoverridden").fireOnChange();
        formContext.makeFieldVisible("productid", false);
        formContext.makeFieldVisible("productdescription", false);
        formContext.getControl("new_manufacturinglocationid").setFocus(true);

        if (formType != Quikrete.Common.FormType.Create) {
            formContext.setFieldSubmitMode("isproductoverridden", "never");
            formContext.makeFieldDisabled("uomid", false);
        }
        else {
            formContext.makeFieldDisabled("uomid", true);
        }

        setTimeout(async () => {
            formContext.makeFieldDisabled("ispriceoverridden", true);
            formContext.ui.tabs.get("Admin")?.sections.get("Hidden")?.setVisible(false);
        }, 500);

    }


    async function validateSourceSystem(productId) {
        const queryParameter = `?$select=new_sourcesystem,_new_family_value`;
        var result = await formContext.retrieveRecord("product", productId, queryParameter);
        if (result != null) {

            const writeInValues = [
                "Write In - EC", // 141 (excluded/commented)
                "Write In - Geosynthetics", // 146
                "Write In - Metal Bridge", // 144
                "Write In - Walls",      // 145
                "Write In - Pipe",//	28
                "Structural Plate Detention",//	117
                "Lump Sum Product", //	121
                "Write In - Sanitary"//	174
            ];

            var familyname = result["_new_family_value@OData.Community.Display.V1.FormattedValue"];
            if (result.new_sourcesystem != null && result.new_family != null) {
                let isNotWriteIn = !writeInValues.includes(familyname);
                if (result.new_sourcesystem == "1" && isNotWriteIn) {
                    formContext.makeFieldDisabled("new_productdescriptioneditable", true);
                }
                else {
                    formContext.makeFieldDisabled("new_productdescriptioneditable", false);
                }
            }
        }
    }


    async function formOnSave(e) {
        var eventArgs = e?.getEventArgs();
        if (formContext.getFieldValue("salesorderid") != null) {
            let oppId = formContext.getFieldValue("salesorderid");
            let result = await formContext.retrieveRecord("salesorder", oppId[0].id, "?$select=statecode");
            if (result != null && result["statecode"] != 0) {
                eventArgs.preventDefault();
                return;
            }
        }

        await Quikrete.ISVFunctions.SavePCFData(formContext, e);
        calculateAmounts();

        var itemNumber = formContext.getFieldValue("new_itemno") ? formContext.getFieldValue("new_itemno") : null;
        var description = formContext.getFieldValue("new_productdescriptioneditable") ? formContext.getFieldValue("new_productdescriptioneditable") : null;
        var combineValue = null;
        if (itemNumber && description) {
            combineValue = itemNumber + "-" + description;
        }
        else if (!itemNumber && description) {
            combineValue = description;
        }
        else if (itemNumber && !description) {
            combineValue = itemNumber
        }
        formContext.setFieldValue("new_productdescriptionwithitemnumber", combineValue);

    }


    function onChangeOfPricePerUnit() {
        calculateAmounts();
    }

    function onChangeOfPcsPerQty() {
        calculateAmounts();
    }

    async function onChangeOfManualDiscount() {
        var manualDiscount = formContext.getFieldValue("manualdiscountamount");
        const baseAmount = formContext.getFieldValue('baseamount');
        if (manualDiscount > baseAmount) {
            var confirmText = "Discount Amount cannot exceed Actual Amount.";
            var confirmTitle = "Alert";
            await formContext.openAlertDialog(confirmTitle, confirmText);
            formContext.setFieldValue("manualdiscountamount", 0);
            return false;
        }
        if (manualDiscount != null) {
            isdiscountpercentchange = false;
            calculateAmounts();
        }
    }

    function onChangeOfDiscountPercentage() {
        var discountPercent = formContext.getFieldValue("new_discountpercent");
        if (discountPercent != null) {
            isdiscountpercentchange = true;
            calculateAmounts();
        }
    }

    function calculateAmounts() {

        var uomlist = formContext.getFieldValue("new_pamuomlist");
        var uomText = formContext.getLookupFieldText("uomid");

        let needLengthMultiplier = true;

        if (uomlist && uomText) {
            const uomlistArray = uomlist.split(",");
            needLengthMultiplier = uomlistArray.some(u => u.trim().toLowerCase() === uomText.toLowerCase());
        }

        var lengthMultiplier = Number(formContext.getFieldValue("new_lengthmultiplier")) || 1.0;
        var pcsPerQty = Number(formContext.getFieldValue("new_pcs")) || 0;

        // Calculate quantity exactly like legacy intent
        const quantity = needLengthMultiplier ? pcsPerQty * lengthMultiplier : pcsPerQty;

        var unitPrice = Number(formContext.getFieldValue("priceperunit"));
        var discountpercent = Number(formContext.getFieldValue("new_discountpercent"));
        var manualDiscount = Number(formContext.getFieldValue("manualdiscountamount"));

        // Clean up invalid values
        if (isNaN(unitPrice)) unitPrice = 0;
        if (isNaN(discountpercent)) discountpercent = 0;
        if (isNaN(manualDiscount)) manualDiscount = 0;

        // --- Discount calculation ---
        if (isdiscountpercentchange) {
            manualDiscount = ((unitPrice * quantity) * discountpercent) / 100;
            if (isNaN(manualDiscount)) manualDiscount = 0;
        } else {
            if (unitPrice > 0 && quantity > 0) {
                discountpercent = (100 * manualDiscount) / (unitPrice * quantity);
                if (isNaN(discountpercent)) discountpercent = 0;
            } else {
                discountpercent = 0;
            }
        }

        // --- Extended and Base Calculations ---
        var extendedpriceperunit = unitPrice - ((unitPrice * discountpercent) / 100);
        if (isNaN(extendedpriceperunit)) extendedpriceperunit = 0;

        var extendedAmount = extendedpriceperunit * quantity;
        if (isNaN(extendedAmount)) extendedAmount = 0;

        var baseAmount = unitPrice * quantity;
        if (isNaN(baseAmount)) baseAmount = 0;

        // --- Update fields safely ---
        formContext.setFieldValue("quantity", quantity);
        formContext.setFieldValue("manualdiscountamount", manualDiscount);
        formContext.setFieldValue("new_discountpercent", discountpercent);
        formContext.setFieldValue("new_extendedpriceperunit", extendedpriceperunit);
        formContext.setFieldValue("extendedamount", extendedAmount);
        formContext.setFieldValue("baseamount", baseAmount);
    }


    async function onPostSaveHandler() {
        await Quikrete.ISVFunctions.PostSaveHandlerForPCF(formContext);
    }

    function assignInsertSequenceNumber(executionContext) {
        const formContext = executionContext.getFormContext();
        var primaryEntityName = formContext.data.entity.getEntityName();
        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
        top.Quikrete = Quikrete;
        top.primaryEntityName = primaryEntityName
        const stdButtonAttr = formContext.getAttribute("new_sequencechange");
        const stdValue = stdButtonAttr?.getValue();
        if (stdValue === "Assign/Insert Sequence #") {
            try {
                let OrderDetailsId = formContext.getCurrentRecordId();

                let pageInput = {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_InsertProduct",
                    data: new URLSearchParams({ OrderDetailsId }).toString(),
                };
                let navigationOptions = {
                    target: 2,
                    width: { value: 50, unit: "%" },
                    height: { value: 50, unit: "%" },
                    position: 1
                };
                formContext.navigateTo(pageInput, navigationOptions);
            }
            catch (error) {
                console.log("Error: " + error.message);
            }
        }
        stdButtonAttr.setValue(null);
        stdButtonAttr.setSubmitMode("never");
    }

    async function onChangeOfUOMId() {
        calculateAmounts();
    }

    return {
        Init: init,
        FormOnLoad: formOnLoad,
        FormOnSave: formOnSave,
        OnChangeOfPricePerUnit: onChangeOfPricePerUnit,
        OnChangeOfPcsPerQty: onChangeOfPcsPerQty,
        OnChangeOfDiscountPercentage: onChangeOfDiscountPercentage,
        OnChangeOfManualDiscount: onChangeOfManualDiscount,
        AssignInsertSequenceNumber: assignInsertSequenceNumber
    }
}());