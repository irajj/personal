﻿var Quikrete = Quikrete || {};

Quikrete.Account = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    var userHasAdministratorRole = false;
    var appName = "";

    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext.getFormContext();

        top.formContext = formContext;

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        // Adds a function to be called when form data is loaded.
        formContext.data.addOnLoad(formOnLoad);

        //Adds a function to be called when the OnSave event is triggered.
        //The event occurs before the save occurs, giving the handler an option to cancel the save operation.
        formContext.data.entity.addOnSave(formOnSave);

        if (formContext.getAttribute("telephone1") != null)
            formContext.getAttribute("telephone1").addOnChange(onChangeOfAddress1Telephone1);

        if (formContext.getAttribute("telephone2") != null)
            formContext.getAttribute("telephone2").addOnChange(onChangeOfAddress1Telephone2);

        if (formContext.getAttribute("fax") != null)
            formContext.getAttribute("fax").addOnChange(onChangeOfAddress1Fax);

        if (formContext.getAttribute("address2_telephone1") != null)
            formContext.getAttribute("address2_telephone1").addOnChange(onChangeOfAddress2Telephone1);

        if (formContext.getAttribute("address2_fax") != null)
            formContext.getAttribute("address2_fax").addOnChange(onChangeOfAddress2Fax);

        if (formContext.getAttribute("new_updatebilltoaddress") != null)
            formContext.getAttribute("new_updatebilltoaddress").addOnChange(onChangeOfBillAddress);

        if (formContext.getAttribute("new_updateaddresschangetocontacts") != null)
            formContext.getAttribute("new_updateaddresschangetocontacts").addOnChange(onChangeUpdateAddresstoContacts);

        if (formContext.getAttribute("new_updatetelephonefaxchangetocontacts") != null)
            formContext.getAttribute("new_updatetelephonefaxchangetocontacts").addOnChange(onChangeUpdateTelephoneFaxtoContacts);

        if (formContext.getAttribute("new_billtoshiptorequest") != null)
            formContext.getAttribute("new_billtoshiptorequest").addOnChange(onChangeSendBillToShipToRequest);

        if (formContext.getAttribute("new_billtorequest") != null)
            formContext.getAttribute("new_billtorequest").addOnChange(onChangeSendBillToRequest);

        if (formContext.getAttribute("new_zipaddress1_lookup") != null)
            formContext.getAttribute("new_zipaddress1_lookup").addOnChange(onChangeOfAddress1ZipCode);

        if (formContext.getAttribute("new_zipaddress2_lookup") != null)
            formContext.getAttribute("new_zipaddress2_lookup").addOnChange(onChangeOfAddress2ZipCode);

        if (formContext.getAttribute("new_accounttypenew") != null)
            formContext.getAttribute("new_accounttypenew").addOnChange(onChangAccountType);

        // --- Subgrid hiding: bind to tab expand ---
        if (formContext.ui.tabs.get("activities") != null)
            formContext.ui.tabs.get("activities").addTabStateChange(onTabStateChangeOfActivities);

    }

    async function onChangeOfAddress1ZipCode() {
        await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipaddress1_lookup", "new_cityaddress1_lookup", "new_stateaddress1_lookup", "new_countyaddress1_lookup", "new_countryaddress1_lookup", "new_pipesalesmanager", "new_fabsalesmanager");
    }

    async function onChangeOfAddress2ZipCode() {
        await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipaddress2_lookup", "new_cityaddress2_lookup", "new_stateaddress2_lookup", "new_countyaddress2_lookup", "new_countryaddress2_lookup");
    }

    async function onChangeOfAddress1Telephone1() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "telephone1");
    }

    async function onChangeOfAddress1Telephone2() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "telephone2");
    }

    async function onChangeOfAddress1Fax() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "fax");
    }

    async function onChangeOfAddress2Telephone1() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "address2_telephone1");
    }

    async function onChangeOfAddress2Fax() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "address2_fax");
    }

    async function onChangeOfBillAddress() {
        const updateToFieldAddress = formContext.getFieldValue("new_updatebilltoaddress");
        if (updateToFieldAddress == true) {
            var confirmText = "Are you sure account Physical Location and  Bill To Address are same?";
            var confirmTitle = "Confirmation";
            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    if (success.confirmed) {
                        formContext.setFieldValue("address2_line1", formContext.getFieldValue("address1_line1"));
                        formContext.setFieldValue("address2_line2", formContext.getFieldValue("address1_line2"));
                        formContext.setFieldValue("address2_line3", formContext.getFieldValue("address1_line3"));
                        formContext.setFieldValue("new_zipaddress2_lookup", formContext.getFieldValue("new_zipaddress1_lookup"));
                        formContext.setFieldValue("new_cityaddress2_lookup", formContext.getFieldValue("new_cityaddress1_lookup"));
                        formContext.setFieldValue("new_stateaddress2_lookup", formContext.getFieldValue("new_stateaddress1_lookup"));
                        formContext.setFieldValue("new_countyaddress2_lookup", formContext.getFieldValue("new_countyaddress1_lookup"));
                        formContext.setFieldValue("new_countryaddress2_lookup", formContext.getFieldValue("new_countryaddress1_lookup"));
                        formContext.setFieldValue("address2_telephone1", formContext.getFieldValue("telephone1"));
                        formContext.setFieldValue("emailaddress2", formContext.getFieldValue("emailaddress1"));
                        formContext.setFieldValue("address2_fax", formContext.getFieldValue("fax"));
                    }
                    formContext.setFieldValue("new_updatebilltoaddress", false);
                });
        }
    }

    async function formOnLoad() {

        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);
        userHasAdministratorRole = formContext.isUserAdministrator();

        if (userHasAdministratorRole) {
            formContext.makeFieldDisabled("new_shiptono", false);
            formContext.makeFieldDisabled("header_accountnumber", false);
            formContext.makeFieldDisabled("new_pipesalesmanager", false);
            formContext.makeFieldDisabled("new_fabsalesmanager", false)
        }
        else {
            formContext.makeFieldDisabled("new_shiptono", true);
            formContext.makeFieldDisabled("header_accountnumber", true);
            formContext.makeFieldDisabled("new_pipesalesmanager", true);
            formContext.makeFieldDisabled("new_fabsalesmanager", true)
        }

        appName = await formContext.getCurrentAppUniqueName();
        //Skip event binding if app is for Quikrete Hardscapes Sales Hub
        if (appName.toLowerCase() == "new_quikretehardscapessaleshub") {
            return; // Exits the function here so next lines are not perform
        }

        //Code for Disable Account Bill to address after creating A3#
        var accountNuber = formContext.getFieldValue("accountnumber");

        setJDEBillToRequest();

        if (accountNuber != null) {
            if (accountNuber.toLowerCase() != 'rejected') {
                if (userHasAdministratorRole) {
                    setDisabledFields(false);
                }
                else {
                    setDisabledFields(true);
                }
            }
            else {
                setDisabledFields(false);
            }
        }
        else {
            setDisabledFields(false);
        }

        if (formContext.getControl("transactioncurrencyid") != null) {
            formContext.makeFieldVisible("transactioncurrencyid", false);
        }


        var teamNameArray = await formContext.getUserTeams(userID);
        if (teamNameArray !== null) {
            if (teamNameArray.some(t => t.TeamName.toUpperCase() == "DISTRIBUTION TEAM")) {
                formContext.makeFieldDisabled("new_distributionstratification", false);
                formContext.makeFieldDisabled("new_distributionnationalaccount", false);
            }
            else {
                formContext.makeFieldDisabled("new_distributionstratification", true);
                formContext.makeFieldDisabled("new_distributionnationalaccount", true);
            }
        }


        await Quikrete.ISVFunctions.HandleSharePointFileTab(formContext);

    }

    function setDisabledFields(isDisable) {
        formContext.makeFieldDisabled("address2_line1", isDisable);
        formContext.makeFieldDisabled("address2_line2", isDisable);
        formContext.makeFieldDisabled("address2_line3", isDisable);
        formContext.makeFieldDisabled("address2_telephone1", isDisable);
        formContext.makeFieldDisabled("address2_fax", isDisable);
        formContext.makeFieldDisabled("emailaddress2", isDisable);

        formContext.makeFieldDisabled("new_zipaddress2_lookup", isDisable);
        formContext.makeFieldDisabled("new_cityaddress2_lookup", isDisable);
        formContext.makeFieldDisabled("new_stateaddress2_lookup", isDisable);
        formContext.makeFieldDisabled("new_countyaddress2_lookup", isDisable);
        formContext.makeFieldDisabled("new_countryaddress2_lookup", isDisable);

        formContext.makeFieldDisabled("new_billtorequest", isDisable);
        formContext.makeFieldDisabled("new_billtoshiptorequest", isDisable);
        formContext.makeFieldDisabled("new_updatebilltoaddress", isDisable);

        formContext.makeFieldDisabled("new_iscashaccount", isDisable);
        formContext.makeFieldDisabled("new_delete", isDisable);
        formContext.makeFieldDisabled("new_deletereason", isDisable);


        if (userBUID == Quikrete.Common.OldCastleBU) {
            formContext.makeFieldDisabled("new_customernumber", false);
        }

        // When User is Admin and BU is USPipe then it show USPipe Manager and enabled.
        if (userBUID == Quikrete.Common.USPipe) {

            formContext.makeFieldDisabled("new_pipesalesmanager", isDisable);
            formContext.makeFieldDisabled("new_fabsalesmanager", isDisable);

            formContext.makeFieldVisible("new_pipesalesmanager", true);
            formContext.makeFieldVisible("new_fabsalesmanager", true);

        }

        if (userBUID == Quikrete.Common.CustomBuilding) {
            formContext.makeFieldDisabled("new_customterritorymanager", isDisable);
            formContext.makeFieldDisabled("new_customregionalmanager", isDisable);
        }

        if (userBUID == Quikrete.Common.FoleyBU || userBUID == Quikrete.Common.OldCastleBU) {
            formContext.makeFieldDisabled("new_billtorequest", true);
            formContext.makeFieldDisabled("new_billtoshiptorequest", true);
        }

        //Code for Disable Account Bill to address after creating A3#
        var accountNuber = formContext.getFieldValue("accountnumber");

        if (accountNuber !== null) {
            if (accountNuber.toLowerCase() === 'rejected') {
                formContext.makeFieldDisabled("new_billtorequest", false);
                formContext.makeFieldDisabled("new_billtoshiptorequest", false);
            }
            if (accountNuber.toLowerCase() !== 'rejected') {
                formContext.makeFieldDisabled("new_billtorequest", true);
                formContext.makeFieldDisabled("new_billtoshiptorequest", true);
            }
            if (accountNuber.toLowerCase() !== 'rejected' &&
                accountNuber.toLowerCase() !== 'request has been sent for account creation') {
                formContext.makeFieldDisabled("name", true);
            }
        }
    }

    async function formOnSave(executionContext) {

        //Skip event binding if app is for Quikrete Hardscapes Sales Hub
        if (appName.toLowerCase() == "new_quikretehardscapessaleshub") {
            return; // Exits the function here
        }

        // #region Define Variable 
        var eventArgs = executionContext.getEventArgs();
        const saveMode = eventArgs.getSaveMode();

        if (saveMode === Quikrete.Common.SaveMode.AutoSave) {
            eventArgs.preventDefault();
            return;
        }

        //this condition is used becuase in some cases record status is not reflected properly on screen.
        // so we forcefully open this record so it open with proper status.
        if (saveMode === Quikrete.Common.SaveMode.Reactivate) {
            formContext.openForm({
                entityName: formContext.data.entity.getEntityName(),
                entityId: formContext.data.entity.getId()
            });
        }

        // Check if the form is dirty (has unsaved changes) so we dont need to check zip code value.
        if (!formContext.data.entity.getIsDirty()) {
            console.log("No changes detected. Exiting function.");
            return;
        }

        if (formContext.getFieldValue("parentaccountid") == null) {
            // if parentaccount is null then account itself should be parent account flag
            formContext.setFieldValue("new_isparentaccount", true);
        }
        // #region Set Account Sub Type To Hidden Field Account Sub Type Text
        var accountsubtypetext = formContext.getLookupFieldText("new_accountsubtypenew");
        formContext.setFieldValue("new_accountsubtypetext", accountsubtypetext);
        // #endregion

        setJDEBillToRequest();

        setLookupValuesofAddresstoText();
    }

    function setLookupValuesofAddresstoText() {

        //Set text Value from lookup field for Address 1
        var postalcode1 = formContext.getLookupFieldText("new_zipaddress1_lookup");
        var city1 = formContext.getLookupFieldText("new_cityaddress1_lookup");
        var state1 = formContext.getLookupFieldText("new_stateaddress1_lookup");
        var county1 = formContext.getLookupFieldText("new_countyaddress1_lookup");
        var country1 = formContext.getLookupFieldText("new_countryaddress1_lookup");

        formContext.setFieldValue("address1_postalcode", postalcode1);
        formContext.setFieldValue("address1_city", city1);
        formContext.setFieldValue("address1_stateorprovince", state1);
        formContext.setFieldValue("address1_county", county1);
        formContext.setFieldValue("address1_country", country1);


        //Set text Value from lookup field for Address 2
        var postalcode2 = formContext.getLookupFieldText("new_zipaddress2_lookup");
        var city2 = formContext.getLookupFieldText("new_cityaddress2_lookup");
        var state2 = formContext.getLookupFieldText("new_stateaddress2_lookup");
        var county2 = formContext.getLookupFieldText("new_countyaddress2_lookup");
        var country2 = formContext.getLookupFieldText("new_countryaddress2_lookup");

        formContext.setFieldValue("address2_postalcode", postalcode2);
        formContext.setFieldValue("address2_city", city2);
        formContext.setFieldValue("address2_stateorprovince", state2);
        formContext.setFieldValue("address2_county", county2);
        formContext.setFieldValue("address2_country", country2);

    }
    function setJDEBillToRequest() {
        // #region bl#4 toggle fields based on address fields and JDE Field

        // Get form type
        var formType = formContext.getFormType();

        if (formType === Quikrete.Common.FormType.Create) { // Form type 1: Create

            formContext.setFieldValue("new_isparentaccount", true);
            formContext.makeFieldDisabled("new_billtorequest", true);
            formContext.makeFieldDisabled("new_billtoshiptorequest", true);
        }
        else if (formType === Quikrete.Common.FormType.Update) { // Form type 2: Update

            if (formContext.getFieldValue("new_jdeformnumber") != null) {
                formContext.makeFieldDisabled("new_billtorequest", true);
                formContext.makeFieldDisabled("new_billtoshiptorequest", true);
            }
            else {

                var street1 = formContext.getFieldValue("address2_line1");
                var postalcode = formContext.getLookupFieldText("new_zipaddress2_lookup");
                var city = formContext.getLookupFieldText("new_cityaddress2_lookup");
                var state = formContext.getLookupFieldText("new_stateaddress2_lookup");
                var county = formContext.getLookupFieldText("new_countyaddress2_lookup");
                var country = formContext.getLookupFieldText("new_countryaddress2_lookup");
                var phoneno = formContext.getFieldValue("address2_telephone1");

                if (formContext.getFieldValue("new_billtorequest") === false && formContext.getFieldValue("new_billtoshiptorequest") === false) {

                    if (street1 != null && postalcode != null && city != null && state != null && county != null && country != null && phoneno != null) {

                        if (street1 != "" || postalcode != "" || city != "" || state != "" || county != "" || country != "" || phoneno != "") {

                            formContext.makeFieldDisabled("new_billtorequest", false);
                            formContext.makeFieldDisabled("new_billtoshiptorequest", false);  // Added by Hshah for spec #500 6M2017
                        }
                        else {
                            formContext.makeFieldDisabled("new_billtorequest", true);
                            formContext.makeFieldDisabled("new_billtoshiptorequest", true); // Added by Hshah for spec #500 6M2017
                        }
                    }
                    else {
                        formContext.makeFieldDisabled("new_billtorequest", true);
                        formContext.makeFieldDisabled("new_billtoshiptorequest", true); // Added by Hshah for spec #500 6M2017
                    }
                }
            }
        }

        if (userBUID === Quikrete.Common.FoleyBU) {
            formContext.makeFieldDisabled("new_billtorequest", true);
            formContext.makeFieldDisabled("new_billtoshiptorequest", true);
        }
    }

    async function onChangeUpdateAddresstoContacts() {
        if (formContext.getFieldValue("new_updateaddresschangetocontacts") === true) {

            var confirmText = "Are you sure you want to update account Address details on all contacts?";
            var confirmTitle = "Confirmation";
            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    formContext.setFieldValue("new_updateaddresschangetocontacts", success.confirmed);
                });
        }
    }

    async function onChangeUpdateTelephoneFaxtoContacts() {

        if (formContext.getFieldValue("new_updatetelephonefaxchangetocontacts") === true) {

            var confirmText = "Are you sure you want to update account Telephone/Fax details on all contacts?";
            var confirmTitle = "Confirmation";

            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    formContext.setFieldValue("new_updatetelephonefaxchangetocontacts", success.confirmed);
                });
        }
    }

    async function onChangeSendBillToShipToRequest() {

        if (formContext.getFieldValue("new_billtoshiptorequest") == true) {
            var street1 = formContext.getFieldValue("address2_line1");
            var postalcode = formContext.getLookupFieldText("new_zipaddress2_lookup");
            var city = formContext.getLookupFieldText("new_cityaddress2_lookup");
            var state = formContext.getLookupFieldText("new_stateaddress2_lookup");
            var county = formContext.getLookupFieldText("new_countyaddress2_lookup");
            var country = formContext.getLookupFieldText("new_countryaddress2_lookup")
            var phoneno = formContext.getFieldValue("address2_telephone1");

            if (street1 == null || postalcode == null || city == null || state == null || county == null || country == null
                || phoneno == null || street1 == "" || postalcode == "" || city == "" || state == "" || county == "" || country == "" || phoneno == "") {
                formContext.setFieldValue("new_billtoshiptorequest", false);
                var confirmText = "On JDE Request, Bill To (Street 1, Zip/Postal Code, City, State, County, Country, Phone) Details are required.";
                var confirmTitle = "Alert";
                formContext.openAlertDialog(confirmTitle, confirmText);

            } else {
                formContext.makeFieldDisabled("new_billtorequest", true);
            }
        }
        else {
            formContext.makeFieldDisabled("new_billtorequest", false);
        }
    }

    async function onChangeSendBillToRequest() {

        if (formContext.getFieldValue("new_billtorequest") == true) {
            var street1 = formContext.getFieldValue("address2_line1");
            var postalcode = formContext.getLookupFieldText("new_zipaddress2_lookup");
            var city = formContext.getLookupFieldText("new_cityaddress2_lookup");
            var state = formContext.getLookupFieldText("new_stateaddress2_lookup");
            var county = formContext.getLookupFieldText("new_countyaddress2_lookup");
            var country = formContext.getLookupFieldText("new_countryaddress2_lookup")
            var phoneno = formContext.getFieldValue("address2_telephone1");

            // Changed & Added by hshah for Spec #500 6M2017
            if (street1 == null || postalcode == null || city == null || state == null || county == null || country == null || phoneno == null
                || street1 == "" || postalcode == "" || city == "" || state == "" || county == "" || country == "" || phoneno == "") {
                formContext.setFieldValue("new_billtorequest", false);
                var confirmText = "On JDE Request, Bill To (Street 1, Zip/Postal Code, City, State, County, Country, Phone) Details are required.";
                var confirmTitle = "Alert";
                formContext.openAlertDialog(confirmTitle, confirmText);

            } else {
                formContext.makeFieldDisabled("new_billtoshiptorequest", true);

                var dataObject = {
                    street1: street1,
                    postalcode: postalcode,
                    city: city,
                    state: state,
                    county: county,
                    country: country,
                    phoneno: phoneno,
                    accountid: formContext.getCurrentRecordId(),
                    businessunitid: userBUID
                };
                top.requestPayload = dataObject;
                top.formContext = formContext;
                let accountId = formContext.getCurrentRecordId();

                formContext.navigateTo(
                    {
                        pageType: "webresource",
                        webresourceName: "new_Quikrete_AssignExistingJDENumber.html",
                        data: new URLSearchParams({ accountId }).toString(),
                    },
                    {
                        target: 2,
                        position: 1,
                        width: { value: 70, unit: "%" },
                        height: { value: 600, unit: "px" },
                        title: "Assign Existing JDE Number",
                    }
                ).then(async function () {

                });
            }
        } else {
            formContext.makeFieldDisabled("new_billtoshiptorequest", false);
        }
    }

    async function formOnLoadForHardScapes() {
        if (userHasAdministratorRole) {
            formContext.makeFieldDisabled("new_shiptono", false);
            formContext.makeFieldDisabled("accountnumber", false);
        }
        else {
            formContext.makeFieldDisabled("new_shiptono", true);
            formContext.makeFieldDisabled("accountnumber", true);
        }
    }
    function onChangAccountType() {
        // Get form type
        var formType = formContext.getFormType();

        if (userBUID == Quikrete.Common.ContechBU && formType === Quikrete.Common.FormType.Update) {
            var confirmText = "On change of Account Type, associated connections will be overridden.";
            var confirmTitle = "Confirmation";
            formContext.openAlertDialog(confirmTitle, confirmText);
            formContext.setFieldValue("new_accountsubtypenew", null);
        }
    }


    function onTabStateChangeOfActivities() {
        var tab = formContext.ui.tabs.get("activities"); // tab where Notes grid is
        if (tab) {
            if (tab.getDisplayState() === "expanded") {
                // run your logic when tab opens
                Quikrete.ISVFunctions.HideNotSubgridAddButtons("notes");
                Quikrete.ISVFunctions.HideActivitiesSubgridButton();
            }
        }
    }

    return {
        Init: init,
        FormOnLoad: formOnLoad,
        FormOnSave: formOnSave,
        OnChangeOfAddress1ZipCode: onChangeOfAddress1ZipCode,
        OnChangeOfAddress2ZipCode: onChangeOfAddress2ZipCode,
        OnChangeOfAddress1Telephone1: onChangeOfAddress1Telephone1,
        OnChangeOfAddress1Telephone2: onChangeOfAddress1Telephone2,
        OnChangeOfAddress1Fax: onChangeOfAddress1Fax,
        OnChangeOfAddress2Telephone1: onChangeOfAddress2Telephone1,
        OnChangeOfAddress2Fax: onChangeOfAddress2Fax,
        OnChangeOfBillAddress: onChangeOfBillAddress,
        OnChangeUpdateAddresstoContacts: onChangeUpdateAddresstoContacts,
        OnChangeUpdateTelephoneFaxtoContacts: onChangeUpdateTelephoneFaxtoContacts,
        OnChangeSendBillToShipToRequest: onChangeSendBillToShipToRequest,
        OnChangeSendBillToRequest: onChangeSendBillToRequest
    }
}());