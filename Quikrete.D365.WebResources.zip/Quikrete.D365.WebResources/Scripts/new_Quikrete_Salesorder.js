﻿var Quikrete = Quikrete || {};
Quikrete.Salesorder = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    let storeCurrentCustomerType = '';

    function init(executionContext) {
        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        // Configure Grid Control
        configGrid();

        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);
        formContext.data.entity.addOnPostSave(onPostSaveHandler);

        // call function on change of Copy Mfg Location to All Products
        if (formContext.getAttribute("new_updatemanufacturinglocationtoallproducts") != null)
            formContext.getAttribute("new_updatemanufacturinglocationtoallproducts").addOnChange(onChangeOfCopyMfgLocationtoAllProduct);

        // call function on change of Copy Requested Date To All Products
        if (formContext.getAttribute("new_copyrequesteddatetoallproducts") != null)
            formContext.getAttribute("new_copyrequesteddatetoallproducts").addOnChange(onChangeOfCopyRequestedDateToAllProducts);

        // call function on change of zipcode
        if (formContext.getAttribute("new_zipaddress1_lookup") != null)
            formContext.getAttribute("new_zipaddress1_lookup").addOnChange(onChangeOfZipecode);

        // call function on change of shipto_fax
        if (formContext.getAttribute("shipto_fax") != null)
            formContext.getAttribute("shipto_fax").addOnChange(onChangeOfShipToFax);

        // call function on change of shipto_telephone
        if (formContext.getAttribute("shipto_telephone") != null)
            formContext.getAttribute("shipto_telephone").addOnChange(onChangeOfShipToTelephone);

        // call function on change of Freight Terms
        if (formContext.getAttribute("freighttermscode") != null)
            formContext.getAttribute("freighttermscode").addOnChange(onChangeOfFreightTerms);

        // call function on change of Jobsite Contact same as Sold To Contact
        if (formContext.getAttribute("new_jobsitecontactsameassoldtocontact") != null)
            formContext.getAttribute("new_jobsitecontactsameassoldtocontact").addOnChange(onChangeOfJobsiteContactSameAsSoldToContact);

        // call function on change of Deposit Required
        if (formContext.getAttribute("new_depositrequired") != null)
            formContext.getAttribute("new_depositrequired").addOnChange(onChangeOfDepositRequired);

        // call function on change of Deposit Waived
        if (formContext.getAttribute("new_depositwaived") != null)
            formContext.getAttribute("new_depositwaived").addOnChange(onChangeOfDepositWaived);

        // call function on change of Ship to Override (Dealer/Cash Account)
        if (formContext.getAttribute("new_passshiptoinfotojde") != null)
            formContext.getAttribute("new_passshiptoinfotojde").addOnChange(onChangeOfShipToOverride);

        // Soft bind sales person lookup change
        if (formContext.getAttribute("new_salesperson") != null)
            formContext.getAttribute("new_salesperson").addOnChange(onSalesPersonChange);

        // Soft bind enable of miles change
        if (formContext.getAttribute("new_enablenumberofmiles") != null)
            formContext.getAttribute("new_enablenumberofmiles").addOnChange(onChangeOfEnableOfMile);


        // Soft bind enable of calculate miles change
        if (formContext.getAttribute("new_calculatemiles") != null)
            formContext.getAttribute("new_calculatemiles").addOnChange(onChangeOfCalculateMiles);

        // --- Subgrid hiding: bind to tab expand ---
        if (formContext.ui.tabs.get("activities") != null)
            formContext.ui.tabs.get("activities").addTabStateChange(onTabStateChangeOfActivities);


        // Soft bind enable of calculate miles change
        if (formContext.getAttribute("customerid") != null)
            formContext.getAttribute("customerid").addOnChange(onChangeOfCustomerId);

        if (formContext.getAttribute("new_contractreceived") != null)
            formContext.getAttribute("new_contractreceived").addOnChange(onChangeOfContractReceived);

        if (formContext.getAttribute("new_letterofintent") != null)
            formContext.getAttribute("new_letterofintent").addOnChange(onChangeOfLetterOfIntent);

        if (formContext.getAttribute("new_verbalorder") != null)
            formContext.getAttribute("new_verbalorder").addOnChange(onChangeOfVerbalOrder);

        if (formContext.getAttribute("new_customerpo") != null)
            formContext.getAttribute("new_customerpo").addOnChange(onChangeOfCustomerPONumber);

        if (formContext.getAttribute("new_dotproject"))
            formContext.getAttribute("new_dotproject").addOnChange(OnchangeDOTProject);

        if (formContext.getAttribute("modifiedon") != null)
            formContext.getAttribute("modifiedon").addOnChange(OnchangeModifiedon);

        if (formContext.getAttribute("new_customertype") != null)
            formContext.getAttribute("new_customertype").addOnChange(onChangeOfCustomerType);
    }

    async function onPostSaveHandler(executionContext) {
        if (userBUID == Quikrete.Common.ContechBU) {
            await Quikrete.SalesCommission.CommissionSave(executionContext);
        }
    }

    function configGrid() {

        const grid = formContext.getControl("connections");
        if (!grid) return;

        const projectId = formContext.getFieldValue("opportunityid")?.[0]?.id;
        const quoteId = formContext.getFieldValue("quoteid")?.[0]?.id;
        const orderId = formContext.getCurrentRecordId();

        const recordId =
            projectId ||
            quoteId ||
            orderId ||
            "00000000-0000-0000-0000-000000000000";

        const filterXml =
            `<filter type='and'>
            <condition attribute='record1id' operator='eq' value='${recordId}' />
         </filter>`;

        grid.setFilterXml(filterXml);
        grid.refresh();
    }


    //on change of Copy Mfg Location to All Products
    function onChangeOfCopyMfgLocationtoAllProduct() {
        var copyMfgLocationToProduct = formContext.getFieldValue("new_updatemanufacturinglocationtoallproducts");
        if (copyMfgLocationToProduct == true) {
            formContext.makeFieldRequired("new_suggestedmanufacturinglocationid", true);
            var confirmText = "By checking this checkbox, this information will be copied to all products on this project. Click Ok to proceed or click Cancel.";
            var confirmTitle = "Confirmation";
            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    formContext.setFieldValue("new_updatemanufacturinglocationtoallproducts", success.confirmed);
                    formContext.data.entity.save();
                });
        }
        else {
            formContext.makeFieldRequired("new_suggestedmanufacturinglocationid", false);
        }
    }

    //on change of Copy Probability to All Products
    function onChangeOfCopyRequestedDateToAllProducts() {

        var copyrequesteddate = formContext.getFieldValue("new_copyrequesteddatetoallproducts");
        if (copyrequesteddate == true) {
            var confirmText = "By Checking this checkbox, this information will be copied to all products on this Order. Click Ok to proceed or click cancel.";
            var confirmTitle = "Confirmation";
            formContext.openConfirmationDialog(confirmTitle, confirmText).then(
                function (success) {
                    formContext.setFieldValue("new_copyrequesteddatetoallproducts", success.confirmed);
                    formContext.data.entity.save();
                });
        }
        else {
            formContext.makeFieldRequired("new_copyrequesteddatetoallproducts", false);
        }
    }

    //on change of zipcode 
    async function onChangeOfZipecode() {
        await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipaddress1_lookup", "new_cityaddress1_lookup", "new_stateaddress1_lookup", "new_countyaddress1_lookup", "new_countryaddress1_lookup");
    }

    async function onChangeOfShipToFax() {
        await Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "shipto_fax");
    }

    async function onChangeOfShipToTelephone() {
        await Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "shipto_telephone");
    }

    function onChangeOfFreightTerms() {

        let freightTerms = formContext.getFieldValueText("freighttermscode");
        let freightsurcharge = formContext.getFieldValue("new_freightsurcharge");
        formContext.makeFieldDisabled("new_freightsurcharge");

        if (freightTerms != null) {
            var fcode = freightTerms.substring(freightTerms.indexOf("(") + 1, freightTerms.indexOf(")"));
            if (fcode == 'COL') {
                // formContext.setFieldValue("new_fuelcode", 7);              this field is deleted
                if (freightsurcharge != null)
                    formContext.setFieldValue("new_freightsurcharge", 0);
            } else if (fcode == 'CPU') {
                //formContext.setFieldValue("new_fuelcode", 5);                this field is deleted
                if (freightsurcharge != null)
                    formContext.setFieldValue("new_freightsurcharge", 0);
            } else if (fcode == 'PPD') {
                if (freightsurcharge != null)
                    formContext.setFieldValue("new_freightsurcharge", 0);
            }
        }

        disableFreightTermsControl();
    }

    function disableFreightTermsControl() {
        let freightTerms = formContext.getFieldValueText("freighttermscode");
        let fuelCode = null;
        if (freightTerms == 'Collect (COL)' || freightTerms == 'Customer Pick Up (CPU)' || freightTerms == 'Prepaid (PPD)') {

            formContext.makeFieldDisabled("new_pertruckfreight");
            formContext.setFieldValue("new_pertruckfreight", false);

            formContext.makeFieldDisabled("new_freightsurcharge");

            if (formContext.getFieldValue("new_freightsurcharge") != null)
                formContext.setFieldValue("new_freightsurcharge", 0);

            formContext.makeFieldDisabled("new_nofreightmaximum");
            formContext.setFieldValue("new_nofreightmaximum", false);

            formContext.makeFieldDisabled("new_totalorderfreightnottoexceed");
            formContext.setFieldValue("new_totalorderfreightnottoexceed", null);

            if ((freightTerms == 'Collect (COL)' || freightTerms == 'Customer Pick Up (CPU)') && fuelCode != null) {

                formContext.makeFieldDisabled("new_fuelcharge");
                formContext.setFieldValue("new_fuelcharge", null);

            } else if (freightTerms == 'Prepaid (PPD)' && fuelCode == null) {
                formContext.makeFieldDisabled("new_fuelcharge", false);
                formContext.setFieldValue("new_fuelcharge", null);
            }
        } else if (freightTerms == 'PPA Port Col Dest (PPAPCD)' || freightTerms == 'Prepaid & Add (PPA)' || freightTerms == 'Prepaid & Add Port (PPAP)' || freightTerms == 'Prepaid Port (PPDP)') {

            formContext.makeFieldDisabled("new_pertruckfreight", false);
            formContext.makeFieldDisabled("new_freightsurcharge", false);

            let perTruckFreight = formContext.getFieldValue("new_pertruckfreight");

            if (perTruckFreight == true) {
                formContext.makeFieldDisabled("new_nofreightmaximum", false);
                formContext.setFieldValue("new_nofreightmaximum", false);
                formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", false);
                formContext.setFieldValue("new_totalorderfreightnottoexceed", null);
            } else {

                formContext.makeFieldDisabled("new_nofreightmaximum");
                formContext.setFieldValue("new_nofreightmaximum", false);
                formContext.makeFieldDisabled("new_totalorderfreightnottoexceed");
                formContext.setFieldValue("new_totalorderfreightnottoexceed", null);
            }
        } else if (freightTerms == null) {
            formContext.makeFieldDisabled("new_pertruckfreight", false);
            formContext.makeFieldDisabled("new_freightsurcharge", false);
            formContext.makeFieldDisabled("new_nofreightmaximum");
            formContext.makeFieldDisabled("new_totalorderfreightnottoexceed");
        }
    }

    //Get and Set Value for Contact Information.
    async function GetSoldToContactInformation() {

        var soldtophone = formContext.getQuickViewControlValue("QuickviewControlOfSoldToContact", "telephone1");
        var soldtoemail = formContext.getQuickViewControlValue("QuickviewControlOfSoldToContact", "emailaddress1");

        var soldtoContact = formContext.getFieldValue("new_soldtocontactid");

        if (soldtoContact != null && (soldtophone == null || soldtoemail == null)) {
            var contactId = soldtoContact[0].id;
            var resultSoldtoContact = await formContext.retrieveRecord("contact", contactId, "?$select=telephone1,emailaddress1");

            if (resultSoldtoContact != null) {
                soldtoemail = resultSoldtoContact["emailaddress1"] || null;
                soldtophone = resultSoldtoContact["telephone1"] || null;
            }
        }

        formContext.setFieldValue("new_soldtophone", soldtophone);
        formContext.setFieldValue("new_soldtoemail", soldtoemail);

        return {
            phone: soldtophone,
            email: soldtoemail
        };
    }

    async function onChangeOfJobsiteContactSameAsSoldToContact(executionContext) {

        formContext = executionContext?.getFormContext();

        let jobsitecontactsameassoldtocontact = formContext.getFieldValue("new_jobsitecontactsameassoldtocontact");

        if (jobsitecontactsameassoldtocontact == true) {
            var resultOfSoldtoContactInformation = await GetSoldToContactInformation();
            var soldtophone = resultOfSoldtoContactInformation.phone;
            var soldtoemail = resultOfSoldtoContactInformation.email;

            var soldtoContactName = formContext.getLookupFieldText("new_soldtocontactid");
            if (soldtoContactName == null) {
                await formContext.openAlertDialog('Warning', 'Please select Sold To Contact');
                formContext.setFieldValue("new_jobsitecontactsameassoldtocontact", false);
                return;
            }
            else if (soldtophone == null) {
                await formContext.openAlertDialog('Warning', 'Please select Sold To Phone');
                formContext.setFieldValue("new_jobsitecontactsameassoldtocontact", false);
                return;
            }
            else {
                formContext.setFieldValue("new_jobsitecontact", soldtoContactName);
                formContext.getAttribute("new_jobsitecontact").fireOnChange();
                formContext.setFieldValue("shipto_telephone", soldtophone);
                formContext.getAttribute("shipto_telephone").fireOnChange();
                formContext.setFieldValue("new_jobsiteemail", soldtoemail);
                formContext.getAttribute("new_jobsiteemail").fireOnChange();
            }
        }
        else {
            formContext.setFieldValue("new_jobsitecontact", null);
            formContext.getAttribute("new_jobsitecontact").fireOnChange();
            formContext.setFieldValue("shipto_telephone", null);
            formContext.getAttribute("shipto_telephone").fireOnChange();
            formContext.setFieldValue("new_jobsiteemail", null);
            formContext.getAttribute("new_jobsiteemail").fireOnChange();
        }
    }

    async function onChangeOfDepositRequired() {
        let depositrequired = formContext.getFieldValue("new_depositrequired");
        if (depositrequired == true) {
            let totalAmount = formContext.getFieldValue("totalamount");
            if (totalAmount != null) {
                await isNonStandardProductExits(true);
            }
        }
    }

    async function isNonStandardProductExits(isRequiredChecked) {

        let customerType = formContext.getFieldValueText("new_customertype");

        if (customerType == 'Dealer' && isRequiredChecked == false) {

            formContext.setFieldValue("new_depositrequired", false);
            formContext.setFieldValue("new_waiveddepositamount", 0);
            formContext.setFieldValue("new_orderdepositamount", 0);
            formContext.setFieldValue("new_depositwaived", false);
            formContext.setFieldValue("new_depositwaivedbyid", null);

            formContext.makeFieldDisabled("new_depositrequired", false);
            formContext.makeFieldDisabled("new_depositwaived", false);
            formContext.makeFieldDisabled("new_orderdepositamount");
            formContext.makeFieldDisabled("new_waiveddepositamount");
            formContext.makeFieldDisabled("new_depositwaivedbyid");

            formContext.makeFieldRequired("new_waiveddepositamount", false);
            formContext.makeFieldRequired("new_orderdepositamount", false);
            formContext.makeFieldRequired("new_depositwaivedbyid", false);
            return;
        }

        //make suere this family also needs to be update in plugin for deposite count
        var nonStandardProductList = new Array('Bebo',
            'Con/Span',
            'Con/Span O-Series',
            'Con/Span BO-Series',
            'Precast Custom Foundations',
            'Precast Express Foundations',
            'Continental Pedestrian Truss',
            'Steadfast Vehicular Truss',
            'ConSpan Detention',
            'US Bridge Vehicular Truss',
            'Aluminum Structural Plate',
            'Aluminum Box Culvert',
            'BridgeCor',
            'CON/SPAN i-Series',
            'Multi-Plate',
            'Continental Express Truss',
            'SuperPlate',
            'SuperSpan',
            'Big R Rolled Girder',
            'Cattleguards',
            'ClearCast',
            'ClearShield'
        );

        let totallineitemamount = formContext.getFieldValue("totallineitemamount");
        if (totallineitemamount >= 25000) {

            let salesorderid = formContext.getCurrentRecordId();;
            let orderProductFamilyList = await formContext.retrieveMultipleRecords("salesorderdetail", `?$select=extendedamount,tax,salesorderdetailid,_salesorderid_value&$expand=productid($select=_new_family_value)&$filter=_salesorderid_value eq '${salesorderid}'`)
            var isNonStandardProductExists = false;
            var total = 0;

            for (let orderProduct of orderProductFamilyList) {
                let familyName = orderProduct?.productid['_new_family_value@OData.Community.Display.V1.FormattedValue'];
                if (familyName != null) {
                    if (nonStandardProductList.some(t => t.toLowerCase() == familyName.toLowerCase())) {
                        isNonStandardProductExists = true;

                        var temp = orderProduct?.extendedamount;
                        var tax = orderProduct?.tax;

                        if (tax != null) {
                            total = parseFloat(total) + parseFloat(temp) - parseFloat(tax);
                        } else {
                            total = parseFloat(total) + parseFloat(temp);
                        }
                    }
                }
            }

            let totalAmt = parseFloat(total);
            let depositwaived = formContext.getFieldValue("new_depositwaived");

            if (totalAmt >= 25000) {
                if (isNonStandardProductExists == true && depositwaived == false) {
                    formContext.setFieldValue("new_depositrequired", true);
                    totalAmt = totalAmt / 3;
                    totalAmt = parseInt(totalAmt + 0.5);
                    formContext.setFieldValue("new_orderdepositamount", totalAmt);
                }
                else if (isNonStandardProductExists == true && depositwaived == true) {
                    totalAmt = totalAmt / 3;
                    totalAmt = parseInt(totalAmt + 0.5);
                    formContext.setFieldValue("new_waiveddepositamount", totalAmt);
                }
                else if (isNonStandardProductExists == false && depositwaived == false) {
                    let isorderfromquote = formContext.getFieldValue("new_isorderfromquote");

                    if (isorderfromquote == false) {
                        formContext.setFieldValue("new_depositrequired", false);
                    }

                    if (formContext.getFieldValue("new_orderdepositamount") != null)
                        formContext.setFieldValue("new_orderdepositamount", 0);
                }
                else if (isNonStandardProductExists == false && depositwaived == true) {
                    if (formContext.getFieldValue("new_waiveddepositamount") != null)
                        formContext.setFieldValue("new_waiveddepositamount", 0);
                }

                let depositrequired = formContext.getFieldValue("new_depositrequired");

                if (depositrequired == true) {
                    formContext.makeFieldDisabled("new_orderdepositamount", false);
                    formContext.makeFieldRequired("new_orderdepositamount");
                } else {
                    formContext.makeFieldDisabled("new_orderdepositamount");
                    formContext.makeFieldRequired("new_orderdepositamount", false);
                }
            }
        }
    }

    async function onChangeOfDepositWaived() {

        let depositwaived = formContext.getFieldValue("new_depositwaived");
        if (depositwaived == false) {
            let totalAmount = formContext.getFieldValue("totalamount");
            if (totalAmount != null) {
                await isNonStandardProductExits(false);
            }
            formContext.setFieldValue("new_waiveddepositamount", 0);
        }
    }

    async function onChangeOfShipToOverride() {
        passShipToInfoToJDE();
        if (formContext.getFieldValue("new_passshiptoinfotojde") != true) {
            formContext.setFieldValue("shipto_line1", null);
            formContext.setFieldValue("shipto_line2", null);
            formContext.setFieldValue("shipto_line3", null);
            formContext.setFieldValue("shipto_postalcode", null);
        }
        else {
            await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipaddress1_lookup", "new_cityaddress1_lookup", "new_stateaddress1_lookup", "new_countyaddress1_lookup", "new_countryaddress1_lookup");
        }
    }

    function passShipToInfoToJDE() {
        if (formContext.getFieldValue("new_passshiptoinfotojde") == true) {
            formContext.makeFieldDisabled("new_jdeshiptonumber", true);
            setDisabledShipToInformation(false);
        }
        else {
            formContext.makeFieldDisabled("new_jdeshiptonumber", true);
            setDisabledShipToInformation(true);
        }
        setSubmitMode();
        disableShipToAddress();
    }

    function setDisabledShipToInformation(value) {
        formContext.makeFieldDisabled("shipto_line1", value);
        formContext.makeFieldDisabled("shipto_line2", value);
        formContext.makeFieldDisabled("shipto_line3", value);
        formContext.makeFieldDisabled("shipto_postalcode", value);
        formContext.makeFieldDisabled("new_zipaddress1_lookup", value);
        formContext.makeFieldDisabled("new_cityaddress1_lookup", value);
        formContext.makeFieldDisabled("new_stateaddress1_lookup", value);
        formContext.makeFieldDisabled("new_countyaddress1_lookup", value);
        formContext.makeFieldDisabled("new_countryaddress1_lookup", value);
    }

    function setSubmitMode() {
        formContext.setFieldSubmitMode("new_jdeshiptonumber");
        formContext.setFieldSubmitMode("shipto_line1");
        formContext.setFieldSubmitMode("shipto_line2");
        formContext.setFieldSubmitMode("shipto_line3");
        formContext.setFieldSubmitMode("shipto_postalcode");
        formContext.setFieldSubmitMode("new_jobsitecontact");
        formContext.setFieldSubmitMode("new_jobsiteemail");
        formContext.setFieldSubmitMode("shipto_telephone");
    }

    function disableShipToAddress() {
        if (formContext.getFieldValue("shipto_addressid") == null) {
            formContext.makeFieldDisabled("new_jdeshiptonumber", true);
            if (formContext.getFieldValue("new_passshiptoinfotojde") == true) {
                setDisabledShipToInformation(false);

            } else {
                formContext.makeFieldDisabled("shipto_line1", true);
                formContext.makeFieldDisabled("shipto_line2", true);
                formContext.makeFieldDisabled("shipto_line3", true);
                formContext.makeFieldDisabled("new_zipaddress1_lookup", false);
                formContext.makeFieldDisabled("new_cityaddress1_lookup", false);
                formContext.makeFieldDisabled("new_stateaddress1_lookup", false);
                formContext.makeFieldDisabled("new_countyaddress1_lookup", false);
                formContext.makeFieldDisabled("new_countryaddress1_lookup", false);
            }

        } else {

            if (formContext.getFieldValue("new_passshiptoinfotojde") == true) {
                setDisabledShipToInformation(false);

            } else {
                formContext.makeFieldDisabled("new_jdeshiptonumber", true);
                setDisabledShipToInformation(true);

            }
        }
        formContext.setFieldSubmitMode("new_zipaddress1_lookup");
        formContext.setFieldSubmitMode("new_cityaddress1_lookup");
        formContext.setFieldSubmitMode("new_stateaddress1_lookup");
        formContext.setFieldSubmitMode("new_countyaddress1_lookup");
        formContext.setFieldSubmitMode("new_countryaddress1_lookup");
    }

    function OnchangeOfFuelCode() {
        var freightSurCharge = formContext.getFieldValue("new_freightsurcharge");
        var existingfreightamount = formContext.getFieldValue("freightamount");
        var fuelCharge = formContext.getFieldValue("new_fuelcharge");
        var freightAmount = freightSurCharge + fuelCharge;

        // Case 1: freightAmount > 0  always update
        if (freightAmount > 0) {
            if (existingfreightamount !== freightAmount) {
                formContext.setFieldValue("freightamount", freightAmount);
            }
        }
        // Case 2: freightAmount == 0 update only if existing value is not null
        else if (freightAmount === 0 && existingfreightamount !== null) {
            if (existingfreightamount !== 0) {
                formContext.setFieldValue("freightamount", 0);
            }
        }
    }

    async function validateBeforeFulfill(primaryControl) {
        formContext = primaryControl;
        var formType = formContext.getFormType();
        let orderId = formContext.data.entity.getId().replace(/[{}]/g, "");
        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);
        let sourcesystem = formContext.getFieldValue("new_sourcesystem");


        formContext.makeFieldRequired("new_soldtocontactid", true);
        formContext.makeFieldRequired("new_jdeshiptonumber", true);
        formContext.makeFieldRequired("shipto_line1", true);
        formContext.makeFieldRequired("freighttermscode", true);
        formContext.makeFieldRequired("shippingmethodcode", true);
        formContext.makeFieldRequired("new_jobsitecontact", true);
        formContext.makeFieldRequired("shipto_telephone", true);

        //Read sold to contact detail and set on field       
        await GetSoldToContactInformation();

        if (!formContext.data.isValid()) {
            // Let OOB UI handle highlighting
            formContext.validateAllRequiredFields();
            Xrm.Page.data.save();
            return false;
        }

        // Validate Freight Terms if total amount is <= 3000
        const totalAmount = formContext.getFieldValue("totalamountlessfreight");
        const freightTerms = formContext.getFieldValue("freighttermscode");

        const salesorderdetails = await formContext.retrieveMultipleRecords(
            "salesorderdetail",
            `?$select=_new_manufacturinglocationid_value,new_productnumber,_productid_value
                &$filter=_salesorderid_value eq ${orderId}
                &$expand=productid($select=productnumber,new_length,_new_lengthuom_value,statecode,statuscode)`
        );

        // Product validation
        if (salesorderdetails) {
            for (const orderproduct of salesorderdetails) {
                if (orderproduct._productid_value) {
                    let productNode = orderproduct.productid;
                    if (productNode.statecode === 1 && productNode.statuscode === 2) {
                        formContext.openAlertDialog('Warning', `Part Number ${productNode.productnumber} has been deactivated. Please remove or replace with a valid, active part number in order to Fulfill this Order.`)
                        return false;
                    }
                }
            }
        }

        if (salesorderdetails != null && salesorderdetails.length > 0) {
            let tempMFGLocation;

            for (const orderproduct of salesorderdetails) {
                const currentMfgLocation = orderproduct["_new_manufacturinglocationid_value@OData.Community.Display.V1.FormattedValue"];
                if (!tempMFGLocation)
                    tempMFGLocation = currentMfgLocation;

                if (currentMfgLocation !== tempMFGLocation) {
                    formContext.openAlertDialog('Warning', 'This Order cannot be fulfilled until all the Order Products have the same Manufacturing Location.  Please update the products and re-fulfill.')
                    return false;
                }
            }
        }

        if (userBUID == Quikrete.Common.ForterraBU) {
            if (salesOrderDetail != null) {

                for (const orderproduct of salesorderdetails) {
                    var productid = orderproduct["_productid_value"];
                    var totalQuantity = orderproduct["quantity"];
                    var LineItemNumber = orderproduct["lineitemnumber"];
                    var uomName = orderproduct["_uomid_value@OData.Community.Display.V1.FormattedValue"];

                    if (orderproduct.productid != null) {
                        var pLength = Number(orderproduct.productid.new_length);
                        var pLengthUOMName = orderproduct.productid["_new_lengthuom_value@OData.Community.Display.V1.FormattedValue"];
                        if (pLength != 0 && uomName == "FT") {
                            if (totalQuantity % pLength != 0) {
                                formContext.openAlertDialog('Warning', "The delivery unit for product sequence " + LineItemNumber + " is " + pLength + " " + pLengthUOMName + ", consider revising Quantity to full stick value.")
                                return false;
                            }
                        }
                    }
                }
            }
        }

        if (sourcesystem == 0 || sourcesystem == null) {
            formContext.openAlertDialog('Warning', 'This Order cannot be fulfilled until all the Order Products have the Source System.  Please update the products and re-fulfill.')
            return false;
        }
        else if (sourcesystem == 7) {
            //for rinker
        }
        else if (sourcesystem == 8) {
            //for forterra
        }
        else if (sourcesystem == 9) {
            //for foley
        }
        else if (sourcesystem == 10) {
            //for OldCastle
        }
        else if (sourcesystem == 11) {
            //for USPipe
        }
        else if ((formType === Quikrete.Common.FormType.Update) && (sourcesystem != 5) && (sourcesystem != 6) && (sourcesystem != 1) && (formContext.getFieldValue("new_projectnumber") == null)) {
            formContext.openAlertDialog('Warning', 'All Orders where the Source System is either Bridge or Storm must be related to a Project.  To proceed, please cancel this Order and create a new one that is associated to a Project.')
            return false;
        }
        if (userBUID == Quikrete.Common.ContechBU) {
            var transactionCurrency = formContext.getFieldValue("transactioncurrencyid");
            var transactionCurrencyName = transactionCurrency[0].name;

            var mfgLocation = formContext.getFieldValue("new_suggestedmanufacturinglocationid");
            var mfgName = "";
            if (mfgLocation != null && mfgLocation[0] != null) {
                var mfgName = mfgLocation[0].name;
            }
            if (transactionCurrency != null && transactionCurrencyName == "Canadian Dollar" && mfgName != "Contech Canada - 5003") {
                formContext.openAlertDialog('Warning', 'All Orders in Canadian Currency must be fulfilled to Plant Contech Canada - #5003. Please update all Order Products on this Order to reflect the correct Plant # prior to Order Fulfillment.')
                return false;
            }
        }
        if (userBUID == Quikrete.Common.RinkerBU || userBUID == Quikrete.Common.ForterraBU || userBUID == Quikrete.Common.OldCastleBU || userBUID == Quikrete.Common.FoleyBU) {
            if (formContext.getFieldValue("new_numberofmiles") != null && (formContext.getFieldValue("new_numberofmiles") == null || (formContext.getFieldValue("new_numberofmiles") == "" && formContext.getFieldValue("new_numberofmiles") != 0))) {
                formContext.openAlertDialog('Warning', 'Number of Miles is required field prior to Fulfillment')
                return false;
            }
        }

        let shippingmethodcode = formContext.getFieldValue("shippingmethodcode");
        if (shippingmethodcode == null || shippingmethodcode == "") {
            formContext.openAlertDialog('Warning', 'Shipping Method is required prior to Fulfillment')
            return false;
        }

        if (formType == Quikrete.Common.FormType.Create || formType == Quikrete.Common.FormType.Update) {
            let contractreceived = formContext.getFieldValue("new_contractreceived");
            let verbalorder = formContext.getFieldValue("new_verbalorder");
            let letterofintent = formContext.getFieldValue("new_letterofintent");
            let customerpo = formContext.getFieldValue("new_customerpo");
            if ((contractreceived == null || contractreceived == false)
                && (verbalorder == null || verbalorder == false)
                && (letterofintent == null || letterofintent == false)
                && (customerpo == '' || customerpo == null)) {
                formContext.openAlertDialog('Warning', 'Your order can not be saved. Please review the Order Documentation section, select at least one item and save this order to proceed.')
                return false;
            }
        }
        if (!validateOrderDocumentation(formContext)) {
            return false;
        }

        // 🔥 SAVE RECORD FIRST (IMPORTANT)
        if (formContext.data.entity.getIsDirty()) {
            await formContext.data.save({ saveMode: 1 });
        }

        await updateOrderStatus(formContext.getCurrentRecordId());
        return true;
        //defualt full fill order command  call after validation.
        //Sales.SalesOrderRibbonActions.Instance.FulfillOrder();
    }

    async function formOnLoad() {
        var buid = formContext.getAttribute('owningbusinessunit')?.getValue();

        storeCurrentCustomerType = formContext.getFieldValueText("new_customertype")?.toLowerCase();

        if (buid && buid.length > 0 && buid[0].id) {
            userBUID = buid[0].id.replace(/[{}]/g, "");
        } else {
            userID = formContext.getCurrentUserId();
            userBUID = await formContext.getBusinessUnit(userID);
        }

        var formType = formContext.getFormType();

        let fromOpportunity = formContext.getFieldValue("opportunityid");
        let isorderfromproject = formContext.getFieldValue("new_isorderfromproject");

        if (formType == Quikrete.Common.FormType.Update && (isorderfromproject == null || isorderfromproject == false)) {
            if (fromOpportunity != null) {
                formContext.setFieldValue("customerid", null);
                formContext.setFieldValue("new_isorderfromproject", true);
            }
        }

        //Filter Manufaturing Location By Buisness Unit Id.
        Quikrete.ISVFunctions.FilterLookup(formContext, "new_suggestedmanufacturinglocationid", userBUID, "new_owningbusinessunit");

        if (formType == Quikrete.Common.FormType.Create) {
            var attribute = formContext.getAttribute("new_dotproject");
            var control = formContext.getControl("new_dotproject");
            attribute.setRequiredLevel("none");
            attribute.setValue(null);
            control.clearNotification();
            attribute.setRequiredLevel("required");
        }

        OnchangeDOTProject();
        suggestedMFLocation();

        formContext.makeFieldDisabled("new_copyrequesteddatetoallproducts", true);
        if (formContext.getFieldValue("new_requesteddate") != null) {
            formContext.makeFieldDisabled("new_copyrequesteddatetoallproducts", false);
        }

        formContext.makeFieldDisabled("new_passshiptoinfotojde", true);

        var customer = formContext.getFieldValue("customerid");
        if (customer && customer.length > 0) {
            var customerId = customer[0].id;
            formContext.makeFieldDisabled("new_soldtocontactid", false);
        } else {
            formContext.makeFieldDisabled("new_soldtocontactid", true);
        }

        if (formType == Quikrete.Common.FormType.Create || formType == Quikrete.Common.FormType.Update) {

            if (formContext.getFieldValue("new_isorderfromquote") == null || formContext.getFieldValue("new_isorderfromquote") == false) {
                isNonStandardProductExits(false);
            }

            if (formContext.getFieldValue("new_depositrequired") == true || formContext.getFieldValue("new_depositwaived") == true) {

                if (formContext.getFieldValue("new_depositwaived") == true) {
                    formContext.makeFieldDisabled("new_depositwaived", true);
                    formContext.makeFieldDisabled("new_depositrequired", false);
                    formContext.makeFieldDisabled("new_waiveddepositamount", false);
                    formContext.makeFieldDisabled("new_depositwaivedbyid", false);
                    formContext.makeFieldDisabled("new_orderdepositamount", true);
                    formContext.makeFieldRequired("new_orderdepositamount", false);
                    formContext.makeFieldRequired("new_waiveddepositamount", true);
                    formContext.makeFieldRequired("new_depositwaivedbyid", true);
                } else {
                    formContext.makeFieldRequired("new_orderdepositamount", true);
                    formContext.makeFieldRequired("new_waiveddepositamount", false);
                    formContext.makeFieldRequired("new_depositwaivedbyid", false);
                    formContext.makeFieldDisabled("new_depositrequired", true);
                    formContext.makeFieldDisabled("new_depositwaived", false);
                }
            }

            if (formContext.getFieldValue("new_depositrequired")) {
                formContext.makeFieldDisabled("new_orderdepositamount", false);
                formContext.makeFieldRequired("new_orderdepositamount", true);
            }
            else {
                formContext.makeFieldDisabled("new_orderdepositamount", true);
                formContext.setFieldSubmitMode("new_orderdepositamount");
                formContext.makeFieldRequired("new_orderdepositamount", false);
            }

            if (formType == Quikrete.Common.FormType.Update) {
                if (formContext.getFieldValue("new_customerpo") != null) {
                    formContext.makeFieldDisabled("new_poreviewstatus", false);
                    formContext.makeFieldRequired("new_poreviewstatus", true);
                }
                if (formContext.getFieldValue("new_verbalorder") != null && formContext.getFieldValue("new_verbalorder") == true) {
                    formContext.makeFieldDisabled("new_verbalby", false);
                }

                OnchangeOfFuelCode();

                if (formContext.getFieldValue("freighttermscode") != '') {
                    var freightTermsCode = formContext.getFieldValueText("freighttermscode");
                    if (freightTermsCode != null) {
                        var fcode = freightTermsCode.substring(freightTermsCode.indexOf("(") + 1, freightTermsCode.indexOf(")"));
                        if (fcode == 'COL' || fcode == 'CPU' || fcode == 'PPD') {

                            if (formContext.getFieldValue("new_freightsurcharge") != null)
                                formContext.setFieldValue("new_freightsurcharge", 0);

                            formContext.makeFieldDisabled("new_freightsurcharge", true);
                            formContext.setFieldSubmitMode("new_freightsurcharge");
                        } else {
                            formContext.makeFieldDisabled("new_freightsurcharge", false);
                        }
                    }

                }
            }
            dealerCreditFieldsBasedOnCustomerType(2);
            if (formContext.getFieldValue("new_updatemanufacturinglocationtoallproducts") !== false) {
                formContext.setFieldValue("new_updatemanufacturinglocationtoallproducts", false);
            }
            if (formContext.getFieldValue("new_copyrequesteddatetoallproducts") !== false) {
                formContext.setFieldValue("new_copyrequesteddatetoallproducts", false);
            }
            if (formContext.getFieldValue("willcall") !== false) {
                formContext.setFieldValue("willcall", false);
            }
        }

        //disable controls
        formContext.makeFieldDisabled("new_projectnumber", true);
        formContext.makeFieldDisabled("quoteid", true);
        formContext.makeFieldDisabled("opportunityid", true);
        formContext.makeFieldDisabled("new_quotenumber", true);

        if (formContext.getFieldValue("opportunityid") == null) {
            formContext.makeFieldVisible("new_projectnumber", false);
            formContext.makeFieldVisible("opportunityid", false);
        }

        if (formContext.getFieldValue("quoteid") == null) {
            formContext.makeFieldVisible("quoteid", false);
            formContext.makeFieldVisible("new_quotenumber", false);
        }
        getAccountAddressAndCreditInfo(false, formType);

        if (formType == Quikrete.Common.FormType.Disabled) {
            getTaxRateDetails();
        }

        var accountNumber = formContext.getFieldValue("new_accountnumber");
        if (accountNumber != null) {
            var startsWithB3 = accountNumber.substring(0, 2) === "B3";
            var startsWithRequest = accountNumber.substring(0, 7) === "Request";

            if (startsWithB3 || startsWithRequest) {
                formContext.makeFieldDisabled("new_newcustomer", true);
            }
            else {
                formContext.makeFieldDisabled("new_newcustomer", false);
                formContext.setFieldValue("new_newcustomer", false);
            }
        }

        onFreightTermsChangeShippingMethod();

        if (formContext.getFieldValue("new_requirecertification") == false) {
            formContext.makeFieldDisabled("new_certsinfoline1", true);
            formContext.makeFieldDisabled("new_certsinfoline2", true);
            formContext.makeFieldDisabled("new_certsinfoline3", true);
            formContext.makeFieldDisabled("new_certsinfoline4", true);
        }

        if (formContext.getFieldValue("new_pertruckfreight") == true) {
            formContext.makeFieldDisabled("new_nofreightmaximum", false);
            formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", false);
        } else {
            formContext.makeFieldDisabled("new_pertruckfreight", false);
            formContext.makeFieldDisabled("new_nofreightmaximum", true);
            formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", true);
        }

        if (formType == Quikrete.Common.FormType.Disabled) {
            formContext.makeFieldDisabled("new_pertruckfreight", true);
            formContext.makeFieldDisabled("new_freightsurcharge", true);
            formContext.makeFieldDisabled("new_nofreightmaximum", true);
            formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", true);
        }
        else {
            disableOnLoad();
        }
        var statcode = formContext.getFieldValue("statecode");

        if (statcode != null) {
            if (statcode == "1" || statcode == "2" || statcode == "3") {
                formContext.makeFieldDisabled("new_soldtocontactid", true);
            } else {
                formContext.setFieldSubmitMode("new_soldtophone");
                formContext.setFieldSubmitMode("new_soldtoemail");
                formContext.makeFieldDisabled("new_soldtocontactid", false);
            }
        }

        passShipToInfoToJDE();// this is call because on premisses system call it when button create

        let statusFlag = formContext.getAttribute("statecode").getValue();
        if (statusFlag == 1) {
            await makeReadOnlyForm(formContext);
        }
        await Quikrete.ISVFunctions.HandleSharePointFileTab(formContext);
    }

    function suggestedMFLocation() {
        formContext.makeFieldDisabled("new_updatemanufacturinglocationtoallproducts", true);
        if (formContext.getFieldValue("new_suggestedmanufacturinglocationid") != null) {
            formContext.makeFieldDisabled("new_updatemanufacturinglocationtoallproducts", false);
        }
    }

    function OnchangeDOTProject() {
        formContext.clearFieldValidationMessage("new_dotproject");
        formContext.getAttribute("new_dotproject").setSubmitMode("always");
    }

    function OnchangeModifiedon(executionContext) {
        if (userBUID == Quikrete.Common.ContechBU) {
            Quikrete.SalesCommission.CommissionReload(executionContext);
        }
    }

    async function onChangeOfCustomerType() {
        debugger
        if (formContext.getFieldValue("new_customertype") == 3 && formContext.getFieldValue("customerid") != null) {
            formContext.setFieldValue('new_primeaddress1new', null);
        }
        dealerCreditFieldsBasedOnCustomerType(1);
        if (formContext.getFieldValueText("new_customertype")?.toLowerCase() == 'dealer') {
            formContext.setFieldValue('new_depositrequired', false);
            formContext.setFieldValue('new_waiveddepositamount', 0.00);
            formContext.setFieldValue('new_orderdepositamount', 0.00);
            formContext.setFieldValue('new_depositwaived', false);
            formContext.setFieldValue('new_depositwaivedbyid', null);
            formContext.setFieldValue('new_depositrequired', false);
            formContext.setFieldValue('new_depositwaived', false);
            formContext.getControl("new_orderdepositamount").setDisabled(true);
            formContext.getControl("new_waiveddepositamount").setDisabled(true);
            formContext.makeFieldRequired("new_waiveddepositamount", false);
            formContext.makeFieldRequired("new_depositwaivedbyid", false);
            formContext.makeFieldRequired("new_orderdepositamount", false);
            formContext.getControl("new_depositwaivedbyid").setDisabled(true);
        }
        else {
            let previousCustomerType = storeCurrentCustomerType;
            if (previousCustomerType == 'dealer')
                await isNonStandardProductExits(false);
            if (formContext.getFieldValue("new_depositrequired") == true)
                formContext.getControl("new_depositrequired").setDisabled(true);
        }

        let customer = formContext.getFieldValueText("new_customertype")?.toLowerCase();
        let isCashAccount;
        if (formContext.getFieldValue("customerid") != null) {
            const customerID = formContext.getFieldValue("customerid")[0].id.replace('{', '').replace('}', '');
            let accountEntityNodes = await getAccountDetailsById(customerID, ["accountnumber", "new_iscashaccount"]);
            if (accountEntityNodes != null) {
                isCashAccount = accountEntityNodes.new_iscashaccount;
            }
        }

        if (customer == 'dealer' || isCashAccount == true) {
            if (formContext.getFieldValue("shipto_addressid") != null) {
                formContext.setFieldValue('new_passshiptoinfotojde', false);
                formContext.getControl("new_passshiptoinfotojde").setDisabled(false);
            } else {
                formContext.setFieldValue('new_passshiptoinfotojde', false);
                formContext.getControl("new_passshiptoinfotojde").setDisabled(true);
            }
        } else {
            formContext.setFieldValue('new_passshiptoinfotojde', false);
            formContext.getControl("new_passshiptoinfotojde").setDisabled(true);
        }
        // fn_PassShipToInfoToJDE_Change();
        onChangeOfShipToOverride();
    }

    function dealerCreditFieldsBasedOnCustomerType(eventMode) {

        var customer = null;
        var customerId = null;
        formContext.setFieldSubmitMode("new_primeaddress1new");
        var deployDate = new Date();
        if (formContext.getFieldValue("new_customertype") == '1') {
            if ((formContext.getFieldValue("customerid") != null && eventMode == 1) || eventMode == 2 && formContext.getFieldValue("modifiedon") < deployDate) {
                customer = formContext.getFieldValue("customerid");
                if (customer != null && customer.length > 0) {
                    customerId = customer[0].id;
                    GetCustomerDataToCustomerTypeFields(customerId, 'PRIME');
                }
            }
        }
        else if (formContext.getFieldValue("new_customertype") == '2') {
            if (eventMode == 2 && formContext.getFieldValue("modifiedon") < deployDate) {
                formContext.setFieldValue("new_primeaddress1new", null);
            }
        }
        else if (formContext.getFieldValue("new_customertype") == '3') {
            customer = formContext.getFieldValue("customerid");
            if (customer != null && customer.length > 0 && eventMode == 1 && formContext.getFieldValue("modifiedon") < deployDate) {
                customerId = customer[0].id;
                GetCustomerDataToCustomerTypeFields(customerId, 'OWNER');
            }
        }
        else if (formContext.getFieldValue("new_customertype") == '4') {
            formContext.setFieldValue("new_primeaddress1new", null);
        }
    }

    async function GetCustomerDataToCustomerTypeFields(customerid, type) {
        if (customerid != "") {
            var account = await getAccountDetailsById(customerid,
                ["name", "telephone1", "address1_line1", "address1_line2", "address1_city", "address1_stateorprovince", "address1_postalcode"]);
            if (!account) return;
        }

        if (account != null) {
            var phoneNode = account.telephone1;
            var address1Node = account.address1_line1;
            var address2Node = account.address1_line2;
            var cityNode = account.address1_city;
            var stateNode = account.address1_stateorprovince;
            var postalCodeNode = account.address1_postalcode;
            var nameNode = account.name;
            var lookupValue = new Array();
            lookupValue[0] = new Object();
            lookupValue[0].id = customerid;
            lookupValue[0].name = nameNode;
            lookupValue[0].entityType = "account";
            if (type == 'PRIME') {
                formContext.setFieldValue("new_primeaddress1new", (address1Node == null) ? null : address1Node);
            } else if (type == 'OWNER') { }
            else if (type == 'BOTH') {
                formContext.setFieldValue("new_primeaddress1new", (address1Node == null) ? null : address1Node);
            }
        }
    }

    async function getAccountAddressAndCreditInfo(changeBool, formType) {

        if (formContext.getFieldValue("customerid") != null) {

            var customer = formContext.getFieldValue("customerid");
            var customerID = customer[0].id;

            var account = await getAccountDetailsById(customerID,
                ["name", "new_accountnumber", "new_customernumber", "new_iscashaccount", "accountnumber"]);
            if (account != null) {

                try {
                    if (formType === Quikrete.Common.FormType.Create || formType === Quikrete.Common.FormType.Update) {
                        formContext.setFieldValue("new_accountnumber", account.accountnumber);
                        if (formContext.getFieldValue("new_accountnumber") != null)
                            formContext.setFieldSubmitMode("new_accountnumber");

                    }
                }
                catch (e) {
                    formContext.setFieldValue("new_accountnumber", '');
                }

                try {
                    if (formType === Quikrete.Common.FormType.Create || formType === Quikrete.Common.FormType.Update)
                        formContext.setFieldValue("new_customernumber", account.new_customernumber);

                    if (formContext.getFieldValue("new_customernumber") != null)
                        formContext.setFieldSubmitMode("new_customernumber");

                }
                catch (e) {
                    formContext.setFieldValue("new_customernumber", '');
                }

                if (formContext.getFieldValue("new_accountnumber") != null) {
                    if (formContext.getFieldValue("new_accountnumber").substring(0, 7) == 'Request') {
                        formContext.makeFieldDisabled("new_newcustomer", true);
                        formContext.setFieldValue("new_newcustomer", false);
                    } else {
                        formContext.makeFieldDisabled("new_newcustomer", false);
                    }
                }

                var isCashAccount = account.new_iscashaccount;

                var customer = formContext.getFieldValueText("new_customertype");
                if (customer == 'Dealer' || isCashAccount == true) {
                    formContext.makeFieldDisabled("new_passshiptoinfotojde", false);
                    passShipToInfoToJDE();

                } else {
                    formContext.setFieldValue("new_passshiptoinfotojde", false);
                    formContext.makeFieldDisabled("new_passshiptoinfotojde", true);
                }
                if (account.new_accountnumber != null) {
                    if (formType === Quikrete.Common.FormType.Create || formType === Quikrete.Common.FormType.Update) {
                        formContext.setFieldValue("new_sourcesystemaccounttext", account.new_accountnumber);
                    }
                }
            }
            else {
                formContext.setFieldValue("new_customernumber", null);
            }
        }
        else {
            formContext.setFieldValue("new_accountnumber", '');
            formContext.setFieldValue("new_customernumber", '');
            formContext.makeFieldDisabled("new_newcustomer", true);
        }
    }

    async function getTaxRateDetails() {

        var postalCode = formContext.getFieldValue("shipto_postalcode");
        var city = formContext.getFieldValue("shipto_city");
        var county = formContext.getFieldValue("new_countyship");
        var state = formContext.getFieldValue("shipto_stateorprovince");
        var willCall = formContext.getFieldValue("willcall");

        // If Will Call is not selected and required fields are missing
        if (willCall === 0 && (!postalCode || !city || !county)) {
            formContext.setFieldValue("new_freighttaxpercent", null);
            return;
        }

        // If any required field is missing, skip the tax retrieval
        if (!postalCode || !city || !county || !state) {
            return;
        }

        const filter = `
            new_zipcode eq '${postalCode}' and 
            new_city eq '${city}' and 
            new_county eq '${county}' and 
            new_state eq '${state}'`;

        const entityTaxRate = await formContext.retrieveMultipleRecords(
            "new_taxrates",
            `?$select=new_cityusetax,new_countyusetax,new_stateusetax&$filter=${filter}`
        );

        // If no tax record is found, reset tax fields
        if (!entityTaxRate || entityTaxRate.length === 0) {
            formContext.setFieldValue("new_taxabletext", null);
            formContext.setFieldValue("new_freighttaxpercent", null);
            return;
        }

        var taxRecord = entityTaxRate[0];
        var cityTaxRate = taxRecord.new_cityusetax ?? null;
        var stateTaxRate = taxRecord.new_stateusetax ?? null;
        var countyTaxRate = taxRecord.new_countyusetax ?? null;
        var isTaxable = cityTaxRate || stateTaxRate || countyTaxRate;

        formContext.setFieldValue("new_taxabletext", isTaxable ? "True" : "False");
    }

    function onFreightTermsChangeShippingMethod() {
        if (formContext.getFieldValueText("freighttermscode") != '') {
            var fcode = formContext.getFieldValue("freighttermscode");
            if (fcode == '200004') {
                formContext.setFieldValue("shippingmethodcode", 7);
            }
        }
    }

    function disableOnLoad() {
        if (formContext.getFieldValue("new_nofreightmaximum") == true) {
            formContext.makeFieldDisabled("new_nofreightmaximum", false);
            formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", true);
        }
        //removing the condition of new_fuelcode as this field is deleted
        if (((formContext.getFieldValueText("freighttermscode") == 'Collect (COL)' || formContext.getFieldValueText("freighttermscode") == 'Customer Pick Up (CPU)')) || formContext.getFieldValueText("freighttermscode") == 'Prepaid (PPD)') {

            formContext.makeFieldDisabled("new_pertruckfreight", true);
            formContext.setFieldValue("new_pertruckfreight", false);

            formContext.makeFieldDisabled("new_freightsurcharge", true);

            if (formContext.getFieldValue("new_freightsurcharge") != null)
                formContext.setFieldValue("new_freightsurcharge", 0);

            formContext.makeFieldDisabled("new_nofreightmaximum", true);
            formContext.setFieldValue("new_nofreightmaximum", false);

            formContext.setFieldValue("new_totalorderfreightnottoexceed", null);
            formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", true);

        }
        //removing the condition of new_fuelcode as this field is deleted
        else if ((formContext.getFieldValueText("freighttermscode") == 'Collect (COL)' || formContext.getFieldValueText("freighttermscode") == 'Customer Pick Up (CPU)' || formContext.getFieldValueText("freighttermscode") == 'Prepaid (PPD)')) {

            formContext.makeFieldDisabled("new_pertruckfreight", true);
            formContext.makeFieldDisabled("new_freightsurcharge", true);
            formContext.makeFieldDisabled("new_nofreightmaximum", true);
            formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", true);
        }
        if (formContext.getFieldValueText("freighttermscode") == 'PPA Port Col Dest (PPAPCD)' || formContext.getFieldValueText("freighttermscode") == 'Prepaid & Add (PPA)' || formContext.getFieldValueText("freighttermscode") == 'Prepaid & Add Port (PPAP)' || formContext.getFieldValueText("freighttermscode") == 'Prepaid Port (PPDP)') {
            formContext.makeFieldDisabled("new_pertruckfreight", false);
            formContext.makeFieldDisabled("new_freightsurcharge", false);

            if (formContext.getFieldValue("new_pertruckfreight") == true) {
                if (formContext.getFieldValue("new_nofreightmaximum") == true) {
                    formContext.makeFieldDisabled("new_nofreightmaximum", false);
                    formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", true);
                    formContext.setFieldValue("new_totalorderfreightnottoexceed", null);
                } else if (formContext.getFieldValue("new_totalorderfreightnottoexceed") != null) {
                    formContext.makeFieldDisabled("new_nofreightmaximum", true);
                    formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", false);
                } else {
                    formContext.makeFieldDisabled("new_nofreightmaximum", false);
                    formContext.makeFieldDisabledl("new_totalorderfreightnottoexceed", false);
                }
            } else {
                formContext.makeFieldDisabled("new_nofreightmaximum", true);
                formContext.setFieldValue("new_totalorderfreightnottoexceed", null);
                formContext.makeFieldDisabled("new_totalorderfreightnottoexceed", true);
            }
        }
    }

    // function GetCommissionForSPECByZipCode(OpportunitID) {

    //     var entityNodes = GetEntityByAttributeByTypeOData('Opportunity', new Array("customerid"), new Array("OpportunityId"), new Array(OpportunitID), new Array("guid"));
    //     var customerid = null;


    //     if (entityNodes != null && entityNodes.results[0] != null) {

    //         var entityNode = entityNodes.results[0];

    //         var customerIdNode = entityNode.CustomerId.Id;
    //         customerid = (customerIdNode == null) ? null : customerIdNode;

    //     }
    //     if (customerid != null) {
    //         var entityNodes = GetEntityByAttributeByTypeOData('Account', new Array("address1_postalcode"), new Array("AccountId"), new Array(customerid), new Array("guid"));
    //         var zipcode = null;
    //         if (entityNodes != null && entityNodes.results[0] != null) {
    //             var entityNode = entityNodes.results[0];

    //             var zipCodeNode = entityNode.Address1_PostalCode;
    //             zipcode = (zipCodeNode == null) ? null : zipCodeNode;
    //         }
    //     }
    // }
    async function formOnSave(executionContext) {

        // executionContext.getEventArgs().disableAsyncTimeout();

        if (formContext.getFieldValue("new_orderdepositamount") != null) {
            if (formContext.getFieldValue("new_depositrequired") == true && formContext.getFieldValue("new_orderdepositamount") == 0) {
                formContext.openAlertDialog('Warning', 'Deposit Amount cannot be 0.00. Please Enter appropriate Deposit Amount.');
                var eventArgs = executionContext.getEventArgs();
                eventArgs.preventDefault();
                return;
            }
        }
        if (!validateOrderDocumentation(formContext)) {
            const eventArgs = executionContext.getEventArgs();
            eventArgs.preventDefault();
            return;
        }

        if (formContext.getFieldValue("new_passshiptoinfotojde") != null) {
            formContext.makeFieldDisabled("new_passshiptoinfotojde", true);
        }


        if (formContext.getFieldValue("new_requirecertification") == true && formContext.getFieldValue("datefulfilled") == null) {
            if (formContext.getFieldValue("new_certsinfoline1") == null) {
                formContext.openAlertDialog('Warning', 'You must provide a value for Certs Info Line 1.');
                var eventArgs = executionContext.getEventArgs();
                eventArgs.preventDefault();
                return;
            }
        }

        if (formContext.getFieldValue("new_passshiptoinfotojde") == true) {
            formContext.setFieldValue("shipto_addressid", null);
        }

        //Read sold to contact detail and set on field
        GetSoldToContactInformation();

        if (formContext.getFieldValue("new_isorderfromproject") == null || formContext.getFieldValue("new_isorderfromproject") == false) {
            if (formContext.getFieldValue("opportunityid") != null) {
                formContext.setFieldValue("new_isorderfromproject", true);
            }
        }

        if (formContext.getFieldValue("new_isorderfromquote") == null || formContext.getFieldValue("new_isorderfromquote") == false) {
            if (formContext.getFieldValue("quoteid") != null) {
                formContext.setFieldValue("new_isorderfromquote", true);
            }
        }
        var dotProject = formContext.getAttribute("new_dotproject").getValue();
        if (dotProject === null) {

            formContext.getControl("new_dotproject").setNotification(
                "DOT Project is required.",
                "DOT_REQUIRED"
            );
            var eventArgs = executionContext.getEventArgs();
            eventArgs.preventDefault();
        }

        var validlimit = await validateCreditLimit();
        if (validlimit) {
            formContext.openAlertDialog('Warning', 'Alert: This Customer is on credit hold in JDE.  Click OK to continue.');
        }
    }

    async function getAccountDetailsById(accountId, selectFields = []) {
        if (!accountId) return null;

        accountId = accountId.replace("{", "").replace("}", "");
        const fieldsQuery = selectFields.length ? `?$select=${selectFields.join(",")}` : "";

        try {
            var account = await Xrm.WebApi.retrieveRecord("account", accountId, fieldsQuery);
            return account;
        } catch (e) {
            console.error("Error retrieving account:", e.message);
            return null;
        }
    }

    // on Sales Person Change
    async function onSalesPersonChange() {
        await Quikrete.ISVFunctions.onSalesPersonChange(formContext, "new_salesperson", "new_salespersonnumber");
    }

    //enable number of miles on change 
    async function onChangeOfEnableOfMile() {

        var formType = formContext.getFormType();
        var enablenumberofmiles = formContext.getFieldValue("new_enablenumberofmiles");
        if (enablenumberofmiles != null && (formType === Quikrete.Common.FormType.Create || formType === Quikrete.Common.FormType.Update)) {
            if (enablenumberofmiles === false) {
                onChangeOfCalculateMiles();
            }
        }
    }

    async function onChangeOfCalculateMiles() {
        var calculatemiles = formContext.getFieldValue("new_calculatemiles");
        var entityZipCode = formContext.getFieldValue("new_zipaddress1_lookup")[0]?.name;
        var mfgLocation = formContext.getFieldValue("new_suggestedmanufacturinglocationid")[0];

        if (calculatemiles == true && entityZipCode && mfgLocation) {
            var mfgid = mfgLocation?.id.replace('{', '').replace('}', '');
            var mfgLocationResponse = await formContext.retrieveMultipleRecords("new_manufacturinglocation", "?$select=_new_manufacturinglocationzipcode_lookup_value&$filter=new_manufacturinglocationid eq " + mfgid);

            if (mfgLocationResponse.length > 0) {
                var mfgLocationEntity = mfgLocationResponse[0];
                var mfgzipCode = mfgLocationEntity["_new_manufacturinglocationzipcode_lookup_value@OData.Community.Display.V1.FormattedValue"];
                var miles = await Quikrete.ISVFunctions.GetMiles(entityZipCode, mfgzipCode);
                formContext.setFieldValue("new_numberofmiles", miles);

            } else {
                formContext.setFieldValue("new_numberofmiles", null);
            }
        } else {
            formContext.setFieldValue("new_numberofmiles", null);
        }
        formContext.setFieldValue("new_calculatemiles", false);
    }

    // Lookup Address Functionality - Override Add Address Function\
    function lookupAddressModal(executionContext) {

        const formContext = executionContext.getFormContext();
        const stdButtonAttr = formContext.getAttribute("new_pcfselectshiptoaddress");
        const stdValue = stdButtonAttr?.getValue();

        if (stdValue === "Select Ship To Address") {
            Sales.CommandBarActions?.Instance?.LookupAddress();
            overrideSetAddressValue(formContext);
        }

        stdButtonAttr.setValue(null);
        stdButtonAttr.setSubmitMode("never");
    }

    function overrideSetAddressValue(formContext) {
        if (Sales.CommandBarActions?.Instance) {

            const commandBar = Sales.CommandBarActions?.Instance;

            if (!commandBar._customSetAddressValueAttached) {
                const originalSetAddressValue = commandBar.setAddressValue;
                commandBar.setAddressValue = async function (response) {

                    console.log("Custom setAddressValue invoked", response);

                    // Simple text field
                    formContext.setFieldValue("shipto_addressid", response.customeraddressid || null);
                    formContext.getAttribute("shipto_addressid").fireOnChange();

                    formContext.setFieldValue("new_jdeshiptonumber", response.new_shiptonumber || null);
                    formContext.getAttribute("new_jdeshiptonumber").fireOnChange();

                    formContext.setFieldValue("shipto_line1", response.line1 || null);
                    formContext.getAttribute("shipto_line1").fireOnChange();

                    formContext.setFieldValue("shipto_line2", response.line2 || null);
                    formContext.getAttribute("shipto_line2").fireOnChange();

                    formContext.setFieldValue("shipto_line3", response.line3 || null);
                    formContext.getAttribute("shipto_line3").fireOnChange();

                    // Lookup helpers
                    if (response.new_zipcode_guid != null) {
                        setLookupValue(formContext, "new_zipaddress1_lookup", response.new_zipcode_guid, response.postalcode, "new_zipcode");
                        formContext.makeFieldDisabled("new_zipaddress1_lookup");
                    }


                    setLookupValue(formContext, "new_cityaddress1_lookup", response.new_city_guid, response.city, "new_citylookup");
                    formContext.makeFieldDisabled("new_cityaddress1_lookup");


                    setLookupValue(formContext, "new_stateaddress1_lookup", response.new_state_guid, response.new_state, "new_state");
                    formContext.makeFieldDisabled("new_stateaddress1_lookup");


                    setLookupValue(formContext, "new_countyaddress1_lookup", response.new_county_guid, response.county, "new_county");
                    formContext.makeFieldDisabled("new_countyaddress1_lookup");


                    setLookupValue(formContext, "new_countryaddress1_lookup", response.new_country_guid, response.country, "new_country");
                    formContext.makeFieldDisabled("new_countryaddress1_lookup");

                    const jobSiteSameAsSoldTo = formContext.getAttribute("new_jobsitecontactsameassoldtocontact");

                    if (jobSiteSameAsSoldTo && jobSiteSameAsSoldTo.getValue() === false) {

                        formContext.setFieldValue("new_jobsitecontact", response.new_jobsitecontact || null);
                        formContext.getAttribute("new_jobsitecontact")?.fireOnChange();

                        formContext.setFieldValue("shipto_telephone", response.new_jobsitephone || null);
                        formContext.getAttribute("shipto_telephone")?.fireOnChange();

                        formContext.setFieldValue("new_jobsiteemail", response.new_jobsiteemail || null);
                        formContext.getAttribute("new_jobsiteemail")?.fireOnChange();

                    }
                    reloadHtmlWebResource(formContext);
                };

                commandBar._customSetAddressValueAttached = true;
            }
        }
    }

    function reloadHtmlWebResource(formContext) {

        // IMPORTANT: This MUST be the CONTROL NAME, not the file name.
        const webResourceControlName = "WebResource_Quikrete_TaxRate";

        const wrCtrl = formContext.getControl(webResourceControlName);
        if (!wrCtrl) {
            console.log("HTML Web Resource control not found:", webResourceControlName);
            return;
        }

        try {
            // Get current SRC
            let src = wrCtrl.getSrc();

            // Add cache-buster
            const newSrc = src.includes("?")
                ? src + "&ts=" + Date.now()
                : src + "?ts=" + Date.now();

            // Reload the web resource by setting new src
            wrCtrl.setSrc(newSrc);

            console.log("HTML Web Resource reloaded:", newSrc);
        } catch (e) {
            console.log("Failed to reload Web Resource:", e);
        }
    }

    // Common Order Document validator
    function validateOrderDocumentation(formContext) {

        // Field reads
        let signedQuote = formContext.getFieldValue('new_contractreceived');
        let verbalOrder = formContext.getFieldValue('new_verbalorder');
        let letterIntent = formContext.getFieldValue('new_letterofintent');
        let poNumber = formContext.getFieldValue('new_customerpo');

        signedQuote = signedQuote == null ? false : signedQuote;
        verbalOrder = verbalOrder == null ? false : verbalOrder;
        letterIntent = letterIntent == null ? false : letterIntent;
        const hasPO = poNumber != null && poNumber !== '';

        if (!signedQuote && !verbalOrder && !letterIntent && !hasPO) {

            formContext.openAlertDialog('Warning', 'Your order can not be saved. Please review the Order Documentation section, select at least one item and save this order to proceed.');
            return false;
        }
        return true;
    }

    function setLookupValue(formContext, fieldName, id, name, entityType) {
        if (id && name) {
            const lookupValue = [{
                id: id,
                name: name,
                entityType: entityType
            }];
            formContext.setFieldValue(fieldName, lookupValue);
            formContext.getAttribute(fieldName).fireOnChange();
        } else {
            formContext.setFieldValue(fieldName, null);
            formContext.getAttribute(fieldName).fireOnChange();
        }
    }

    async function updateOrderStatus(orderId) {
        // Build the request payload
        var data = {
            "statecode": 1,        // Submitted
            "statuscode": 3,        // In Progress
            "submitdate": new Date().toISOString()  // Current date & time          
        };

        try {
            await formContext.updateRecord("salesorder", orderId, data)
            await Xrm.Page.data.refresh(); // optional
        } catch (error) {
            formContext.errorDialog(error.message, JSON.stringify(error));
        }
    }

    function onTabStateChangeOfActivities() {
        var tab = formContext.ui.tabs.get("activities"); // tab where Notes grid is
        if (tab) {
            if (tab.getDisplayState() === "expanded") {
                // run your logic when tab opens
                Quikrete.ISVFunctions.HideNotSubgridAddButtons("notes");
                Quikrete.ISVFunctions.HideActivitiesSubgridButton();
            }
        }
    }

    async function onChangeOfCustomerId() {

        let customerIdLookup = formContext.getAttribute('customerid');
        if (customerIdLookup?.getValue() != null) {
            formContext.setFieldValue('new_soldtocontactid', null);
            formContext.setFieldValue('new_jobsitecontactsameassoldtocontact', false);
            formContext.getAttribute('new_jobsitecontactsameassoldtocontact').fireOnChange();
            var formType = formContext.getFormType();
            getAccountAddressAndCreditInfo(false, formType);

            if (formContext.getFieldValue("new_jdeshiptonumber") != null && formContext.getFieldValue("new_jdeshiptonumber") != "") {
                formContext.setFieldValue("shipto_postalcode", null);
                formContext.setFieldValue("shipto_line2", null);
                formContext.setFieldValue("shipto_line1", null);
                formContext.setFieldValue("shipto_line3", null);
                formContext.setFieldValue("shipto_fax", null);
                formContext.setFieldValue("shipto_addressid", null);
                formContext.setFieldValue("new_jdeshiptonumber", null);
            }
        }
        else {
            //All ShipTo
            // formContext.setFieldValue('shipto_contactname', null);
            // formContext.setFieldValue('shipto_line1', null);
            // formContext.setFieldValue('shipto_line2', null);
            // formContext.setFieldValue('shipto_line3', null);
            // formContext.setFieldValue('shipto_city', null);
            // formContext.setFieldValue('shipto_stateorprovince', null);
            // formContext.setFieldValue('shipto_postalcode', null);
            // formContext.setFieldValue('shipto_country', null);
            // formContext.setFieldValue('shipto_telephone', null);
            // formContext.setFieldValue('shipto_fax', null);
            // formContext.setFieldValue('shipto_freighttermscode', null);
            // formContext.setFieldValue('new_jdeshiptonumber', null);
            // formContext.setFieldValue('shipto_paymenttermscode', null);

            formContext.setFieldValue("shipto_postalcode", null);
            formContext.setFieldValue("shipto_line2", null);
            formContext.setFieldValue("shipto_line1", null);
            formContext.setFieldValue("shipto_line3", null);
            formContext.setFieldValue("shipto_fax", null);
            formContext.setFieldValue("shipto_addressid", null);
            formContext.setFieldValue("new_zipaddress1_lookup", null);
            formContext.setFieldValue("new_cityaddress1_lookup", null);
            formContext.setFieldValue("new_stateaddress1_lookup", null);
            formContext.setFieldValue("new_countyaddress1_lookup", null);
            formContext.setFieldValue("new_countryaddress1_lookup", null);
            formContext.setFieldValue("new_jdeshiptonumber", null);
        }
    }

    async function onChangeOfContractReceived() {
        const contractreceived = formContext.getFieldValue('new_contractreceived');
        if (contractreceived == true) {
            formContext.setFieldValue("new_signedcontechquotedate", new Date());
        }
        else {
            formContext.setFieldValue("new_signedcontechquotedate", null);
        }
    }

    async function onChangeOfLetterOfIntent() {
        const letterofintent = formContext.getFieldValue('new_letterofintent');
        if (letterofintent == true) {
            formContext.setFieldValue("new_letterofintentdate", new Date());
        }
        else {
            formContext.setFieldValue("new_letterofintentdate", null);
        }
    }

    async function onChangeOfVerbalOrder() {
        const verbalorder = formContext.getFieldValue('new_verbalorder');
        if (verbalorder == true) {
            formContext.setFieldValue("new_verbalorderdate", new Date());
        }
        else {
            formContext.setFieldValue("new_verbalorderdate", null);
        }
    }

    async function onChangeOfCustomerPONumber() {
        const verbalorder = formContext.getFieldValue('new_customerpo');
        if (verbalorder) {
            formContext.setFieldValue("new_customerporeceiveddate", new Date());
        }
        else {
            formContext.setFieldValue("new_customerporeceiveddate", null);
        }
    }

    async function makeReadOnlyForm(formContext) {
        // Disable all fields
        formContext.ui.controls.forEach(function (control) {
            try {
                if (control && control.setDisabled) {
                    control.setDisabled(true);
                }
            }
            catch (e) { }
        });

        // Disable all subgrids
        await lockSubgrids(formContext);

        // Optional: Disable header fields
        var headerControls = formContext.ui.controls.get(function (c) {
            return c.getParent() && c.getParent().getName() === "Header";
        });

        headerControls.forEach(function (control) {
            try {
                if (control && control.setDisabled) {
                    control.setDisabled(true);
                }
            }
            catch (e) { }
        });
    }

    function lockSubgrids(formContext) {
        formContext.ui.controls.forEach(function (control) {
            console.log(" - " + control.getControlType());

            if (control.getControlType() === "subgrid") {
                // Hide command bar (Add / Delete / Associate)
                if (control.setShowCommandBar) {
                    control.setShowCommandBar(false);
                }

                // Prevent opening records by double click
                control.addOnLoad(function () {
                    var grid = control.getGrid();
                    if (!grid) return;

                    grid.getRows().forEach(function (row) {
                        row.getData().getEntity().addOnSelectionChange(function () {
                            formContext.ui.setFormNotification("This order is read-only.", "INFO", "READONLY");
                        });
                    });
                });
            }
        });
    }

    async function downloadCustometInfoSheet(primaryControl) {
        try {
            var formContext = primaryControl;
            formContext.show('Generating PDF');
            var apiurl = Quikrete.Common.CustomerInfoAPI;
            var orderId = formContext.getCurrentRecordId();
            var orderNo = formContext.getFieldValue("ordernumber");
            var bu = formContext.getFieldValue("owningbusinessunit")[0].id.toLowerCase().replace("{", "").replace("}", "");
            var shipState = formContext.getFieldValue("new_stateaddress1_lookup")[0]?.name;

            const payload = {
                OrderId: orderId,
                OrderNumber: orderNo,
                BusinessUnit: bu,
                StateCode: shipState
            };

            const response = await fetch(apiurl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                console.error("Failed to download PDF");
            }

            //  Read filename from header
            const contentDisposition = response.headers.get("Content-Disposition");
            let fileName = "CustomerJobInformationSheet.pdf";

            if (contentDisposition && contentDisposition.includes("filename=")) {
                fileName = contentDisposition
                    .split("filename=")[1]
                    .replace(/"/g, "")
                    .trim();
            }

            // Convert to blob
            const blob = await response.blob();
            formContext.close();
            //  Trigger download
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();

            // Cleanup
            a.remove();
            window.URL.revokeObjectURL(url);

        } catch (error) {
            formContext.close();
            console.error("Error:", error);
        }
    }

    async function validateCreditLimit() {
        try {
            var creditonhold = false;
            var customerNumber = formContext.getFieldValue("new_accountnumber");
            customerNumber = parseInt(customerNumber);

            if (customerNumber != "" && !isNaN(customerNumber)) {
                const requestPayload = {
                    action: "execute-sp",
                    storedProcedureConfig: {
                        name: 'GetJDEDetailsForD365',
                        inputs: [
                            {
                                CustomerNumber: customerNumber
                            }
                        ],
                    },
                };

                const myHeaders = new Headers();
                myHeaders.append("Content-Type", "application/json");

                const requestOptions = {
                    method: "POST",
                    headers: myHeaders,
                    body: JSON.stringify(requestPayload)
                };

                const azureapi = Quikrete.Common.AzureAPIURL;

                const response = await fetch(azureapi + "/api/request", requestOptions);
                const result = await response.json();
                if (result.Data && result.Data.length > 0) {
                    const responseData = result.Data[0];

                    if (Number(responseData.HoldSalesOrder) === 1) {
                        creditonhold = true;
                    }
                }
            }
        } catch (err) {
            console.log(err.message);
        }
        formContext.setFieldValue("new_credithold", creditonhold);
        return creditonhold;
    }
    return {
        Init: init,
        FormOnLoad: formOnLoad,
        ValidateBeforeFulfill: validateBeforeFulfill,
        LookupAddressModal: lookupAddressModal,
        DownloadCustometInfoSheet: downloadCustometInfoSheet
    }
}());