﻿var Quikrete = Quikrete || {};

Quikrete.OpportunityQuickCreate = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    var userHasAdministratorRole = null;

    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);

        //new_dotproject
        if (formContext.getAttribute("new_dotproject")) {
            formContext.getAttribute("new_dotproject").addOnChange(OnChangeDOTProject);
        }

        // call function on change of Customer ID
        if (formContext.getAttribute("customerid") != null)
            formContext.getAttribute("customerid").addOnChange(onChangeOfCustomerId);

        //---ExpectBidDateUnknow
        if (formContext.getAttribute("new_expectedbiddateunknown")) {
            formContext.getAttribute("new_expectedbiddateunknown").addOnChange(onChangeExpectBidDateUnknow);
        }

        // call function on change of zipcode
        if (formContext.getAttribute("new_zipaddress1_lookup") != null)
            formContext.getAttribute("new_zipaddress1_lookup").addOnChange(onChangeOfZipecode);
    }

    async function formOnLoad() {

        var buid = formContext.getAttribute('owningbusinessunit')?.getValue();

        if (buid && buid.length > 0 && buid[0].id) {
            userBUID = buid[0].id.replace(/[{}]/g, "");
        } else {
            userID = formContext.getCurrentUserId();
            userBUID = await formContext.getBusinessUnit(userID);
        }

        var formType = formContext.getFormType();
        if (formType == Quikrete.Common.FormType.Create) {
            var attribute = formContext.getAttribute("new_dotproject");
            var control = formContext.getControl("new_dotproject");
            if (!attribute || !control) return;

            attribute.setRequiredLevel("none");
            attribute.setValue(null);
            attribute.setSubmitMode("always");
            control.clearNotification();
            setTimeout(function () {
                attribute.setRequiredLevel("required");
            }, 200);

            //auto-populate Price List field
            setDefaultPriceList();
        }
        formContext.getControl("customerid").setEntityTypes(["account"]);

        //Filter Manufaturing Location By Buisness Unit Id.
        Quikrete.ISVFunctions.FilterLookup(formContext, "new_manufacturinglocationid", userBUID, "new_owningbusinessunit");
    }

    function OnChangeDOTProject() {
        formContext.clearFieldValidationMessage("new_dotproject");
        formContext.getAttribute("new_dotproject").setSubmitMode("always");
    }

    function onChangeOfCustomerId() {
        formContext.setFieldValue("new_specacctcontact", null);

    }

    function onChangeExpectBidDateUnknow() {

        var bidDateUnknown = formContext.getFieldValue("new_expectedbiddateunknown");
        var bidDate = formContext.getFieldValue("new_biddate");

        if (bidDateUnknown === false && !bidDate) {

            formContext.makeFieldRequired("new_biddate", "required");
        }

        else if (bidDateUnknown === false && bidDate) {
            formContext.makeFieldRequired("new_biddate", false);
            formContext.makeFieldDisabled("new_expectedbiddateunknown", false);
        }
        else {
            formContext.makeFieldRequired("new_biddate", false);
        }
    }

    //on change of zipcode 
    async function onChangeOfZipecode() {
        await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipaddress1_lookup", "new_cityaddress1_lookup", "new_stateaddress1_lookup", "new_countyaddress1_lookup", "new_countryaddress1_lookup");
    }

    function formOnSave(executionContext) {
        var eventArgs = executionContext.getEventArgs();
        const saveMode = eventArgs.getSaveMode();

        if (formContext.getFieldValue("new_biddate") == null && formContext.getFieldValue("new_expectedbiddateunknown") == 0 && formContext.getFormType() != 4) {
            formContext.setFieldValidationMessage("new_biddate", "Expected Bid Date is required. If unknown, toggle Expected Bid Date Unknown.");
            formContext.makeFieldRequired("new_biddate", "required");
            var confirmText = "Please provide an Expected Bid Date / Time. If the information is currently not available, check the Expected Bid Date Unknown Checkbox";
            var confirmTitle = "Confirmation";
            formContext.openAlertDialog(confirmTitle, confirmText)
            formContext.getControl("new_biddate").setFocus(true);
            var eventArgs = executionContext.getEventArgs();
            eventArgs.preventDefault();
            return;
        }

        var dotProject = formContext.getAttribute("new_dotproject").getValue();
        if (dotProject === null) {

            formContext.getControl("new_dotproject").setNotification(
                "DOT Project is required.",
                "DOT_REQUIRED"
            );
            var eventArgs = executionContext.getEventArgs();
            eventArgs.preventDefault();
            return;
        }
    }



    async function setDefaultPriceList() {

        if (formContext.ui.getFormType() !== Quikrete.Common.FormType.Create) return;

        var priceListAttr = formContext.getAttribute("pricelevelid");
        if (!priceListAttr) return;


        try {
            var query = "?$select=pricelevelid,name&$filter=contains(name,'Base Price List')";

            var result = await formContext.retrieveMultipleRecords("pricelevel", query);

            if (result == null && result?.length === 0) {
                console.log("No Base Price List found");
                return;
            }

            var priceList = result[0];

            var lookupValue = [{
                id: priceList?.pricelevelid,
                name: priceList?.name,
                entityType: "pricelevel"
            }];

            var priceListAttr = formContext.getAttribute("pricelevelid");

            priceListAttr.setValue(lookupValue);
            priceListAttr.fireOnChange();

        }
        catch (e) {
            console.error("Error while fetching Price List:", e.message);
        }

    }


    return {
        Init: init,
    }

})();