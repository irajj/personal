// JavaScript source code
// Quikrete Common JS file
var Quikrete;

(function (Quikrete) {
    var Common;

    Quikrete.IsDebuggerEnabled = true;

    (function (Common) {

        Common.AzureAPIURL = "https://quikrete-azure-onpremise-api-dev.azurewebsites.net";
        Common.AzureAPICode = "?code=x62biwtjzFQyTAuRL6ETpmg5RWejjeKwRyByll6AKesNAzFuTm-tzQ==";

        // Define constant for OldCastleBU
        Common.QuikreteBU = "2019AAFE-CF91-EF11-8A69-6045BDECBD0A";
        Common.ContechBU = "7EFD48C3-C452-F011-877A-000D3A1F2445";
        Common.RinkerBU = "E8301A8F-1379-E711-8109-00155D82E483";
        Common.ForterraBU = "65F58CC9-1E57-EC11-8112-005056AD7578";
        Common.OldCastleBU = "8D1EAA7A-619F-EC11-8115-005056AD7578";
        Common.FoleyBU = "CA17298F-619F-EC11-8115-005056AD7578";
        Common.USPipe = "AB785698-619F-EC11-8115-005056AD7578";
        Common.CustomBuilding = "0DE1B28E-E6E1-EE11-811D-005056AD3DCB";
        Common.HardscapesAndMasonryBU = "DDFCC478-69ED-EF11-BE21-0022482819B0";

        //Enum for CRM Form Type
        Common.FormType = {
            Undefined: 0,      // Undefined
            Create: 1,         // Create form
            Update: 2,         // Update form
            ReadOnly: 3,       // Read-only form
            Disabled: 4,       // Disabled form
            BulkEdit: 6        // Bulk Edit form
        };

        //Enum for CRM SaveMode Type
        Common.SaveMode = {
            Save: 1,                // Save - All tables
            SaveAndClose: 2,        // Save and Close - All tables
            Deactivate: 5,          // Deactivate - All tables
            Reactivate: 6,          // Reactivate - All tables
            Send: 7,                // Send - Email tables
            Disqualify: 15,         // Disqualify - Lead
            Qualify: 16,            // Qualify - Lead
            Assign: 47,             // Assign - User or Team owned tables
            SaveAsCompleted: 58,    // Save as Completed - Activities
            SaveAndNew: 59,         // Save and New - All tables
            AutoSave: 70            // Auto Save - All tables
        };

        //Flow URLS 
        Common.CommonFlowUrls = {
            OrderFlow: {
                createUpdateSharePoint:
                    "https://9afed35bf326ee4aaf159428749519.1e.environment.api.powerplatform.com/powerautomate/automations/direct/workflows/04739b287fed4c7e98a19b9ba06984de/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=FGcAqtdtwoiIOpB4omClexTJMtmcZ_qQAi3aaY2IcJU",

                deleteSharePoint:
                    "https://9afed35bf326ee4aaf159428749519.1e.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/b9733766f55744eeaa87e586a3ea102b/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=oAHhxWthoafmMoztCyB5cfB4y81adNrpZZRiyA5sj0s",

                sendMailFaxService:
                    "https://9afed35bf326ee4aaf159428749519.1e.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/508b52ccb5cc4b5fbade55d4632a7699/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=bCv3MCERkCtU1AVzqnSomb-LofQlK1RRzJmDeFd-zUQ"

            },

            QuoteFlow: {
                createUpdateSharePoint:
                    "https://9afed35bf326ee4aaf159428749519.1e.environment.api.powerplatform.com/powerautomate/automations/direct/workflows/04739b287fed4c7e98a19b9ba06984de/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=FGcAqtdtwoiIOpB4omClexTJMtmcZ_qQAi3aaY2IcJU",

                deleteSharePoint:
                    "https://9afed35bf326ee4aaf159428749519.1e.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/b9733766f55744eeaa87e586a3ea102b/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=oAHhxWthoafmMoztCyB5cfB4y81adNrpZZRiyA5sj0s",

                sendMailFaxService:
                    "https://9afed35bf326ee4aaf159428749519.1e.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/96ccde89f4754af8b7434d96c7462a4d/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=vclZRDv5GF8E5Xrghhdxh-tdHL74tz_XRLCq9zvJrbg"
            }
        };

        // Generate Based 64 For SSRS Report
        Common.GenerateBASE64 =
            "https://quikrete-azure-onpremise-api-dev.azurewebsites.net/api/GenerateReport?code=nfEDf6CzbR2NYkIh2sNdAdDAtPmGVPZtgu-UKLo5WPxVAzFusSuY9A==" // dev

        Common.CustomerInfoAPI =
            "https://quikrete-azure-onpremise-api-dev.azurewebsites.net/api/customer-info-template?code=Bpt_sFIzm2qYQHk7BWCF6HqmbwZQ0fyxHCNdClteLc6qAzFuiYr8OA==";

        Common.PublishAPI =
            "https://9afed35bf326ee4aaf159428749519.1e.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/b42bf32109e44d35904d1267b0a9c00b/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=LGS5qRFjgrIu8IQ4Ms1PApXgUUK3anFUMBmQPWAnbiM";


        Common.GetQuickViewControlValue = function (fContext, quickViewName, fieldName) {
            var resultField = null;
            var quickViewControl = fContext.ui.quickForms.get(quickViewName);

            if (quickViewControl && quickViewControl.isLoaded()) {
                var field = quickViewControl.getAttribute(fieldName);
                if (field !== null && field !== undefined) {
                    var fieldValue = field.getValue();
                    if (fieldValue !== null && fieldValue !== undefined) {
                        resultField = fieldValue;
                    }
                }
            }
            return resultField;
        };

        Common.GetFieldValue = function (fContext, fieldName) {
            var resultField = null;
            var field = fContext.getAttribute(fieldName);
            if (field != undefined && field != null) {
                field = field.getValue();
                if (field != undefined && field != null) {
                    resultField = field;
                }
                else {
                    resultField = null;
                }
            }
            return resultField;
        };

        Common.GetFieldValueText = function (fContext, fieldName) {
            var resultField = null;
            var field = fContext.getAttribute(fieldName);
            if (field != undefined && field != null) {
                field = field.getText();
                if (field != undefined && field != null) {
                    resultField = field;
                }
                else {
                    resultField = null;
                }
            }
            return resultField;
        };

        Common.GetLookupFieldText = function (formContext, fieldName) {
            var field = formContext.getAttribute(fieldName);
            if (field) {
                var lookupValue = field.getValue();
                if (lookupValue && lookupValue.length > 0) {
                    return lookupValue[0].name;
                }
            }
            return null;
        };

        Common.SetFieldValue = function (fContext, fieldName, fieldValue) {
            var field = fContext.getAttribute(fieldName);
            if (field != undefined && field != null) {
                field.setValue(fieldValue);
            }
        };

        Common.MakeFieldRequired = function (fContext, fieldName, reqLevel) {
            if (reqLevel === void 0) { reqLevel = true; }
            var field = fContext.getAttribute(fieldName);
            if (field != undefined && field != null) {
                if (reqLevel) {
                    field.setRequiredLevel("required");
                }
                else {
                    field.setRequiredLevel("none");
                }
            }
        };

        Common.MakeFieldDisabled = function (fContext, fieldName, disabled) {
            if (disabled === void 0) { disabled = true; }
            var field = fContext.getControl(fieldName);
            if (field != undefined && field != null) {
                //@ts-ignore
                field.setDisabled(disabled);
            }
        };

        Common.MakeFieldVisibled = function (fContext, fieldName, visible) {
            if (visible === void 0) { visible = true; }
            var field = fContext.getControl(fieldName);
            if (field != undefined && field != null) {
                //@ts-ignore
                field.setVisible(visible);
            }
        };

        Common.MakeSectionVisibled = function (fContext, tabName, sectionName, visible) {
            if (visible === void 0) { visible = true; }
            var tab = fContext.ui.tabs.get(tabName);
            if (tab != undefined && tab != null) {
                var section = tab.sections.get(sectionName);
                if (section != undefined && section != null) {
                    section.setVisible(visible);
                }
            }
        };

        Common.SetFieldValidationMsg = function (fContext, fieldName, message) {
            var field = fContext.getControl(fieldName);
            if (field != undefined && field != null) {
                //@ts-ignore
                field.setNotification(message);
            }
        };

        Common.ClearFieldValidationMsg = function (fContext, fieldName) {
            var field = fContext.getControl(fieldName);
            if (field != undefined && field != null) {
                //@ts-ignore
                field.clearNotification();
            }
        };

        Common.MakeFormReadonly = function (fContext) {
            var formControls = fContext.ui.controls;
            formControls.forEach(function (control) {
                if (control.getName() != "" && control.getName() != null) {
                    //@ts-ignore
                    control.setDisabled(true);
                }
            });
        };

        Common.MakeLookupNonClickable = function (fContext, fieldName) {
            var field = fContext.getControl(fieldName);
            if (field != undefined && field != null) {
                //@ts-ignore
                field.addOnLookupTagClick(function (evt) {
                    //Prevent to redirect on new page
                    evt.getEventArgs().preventDefault();
                });
            }
        };

        Common.MakeAllLookupNonClickable = function (fContext) {
            var formControls = fContext.ui.controls;
            formControls.forEach(function (control) {
                if (control.getName() != "" && control.getName() != null) {
                    try {
                        //@ts-ignore
                        control.addOnLookupTagClick(function (evt) {
                            //Prevent to redirect on new page
                            evt.getEventArgs().preventDefault();
                        });
                    }
                    catch (e) {
                    }
                }
            });
        };

        Common.convertNumberToWords = function (n) {
            if (n < 0)
                return false;
            var singleDigit = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
            var doubleDigit = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
            var belowHundred = ['Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
            if (n === 0)
                return 'Zero';
            // Separate the integer and decimal parts
            var integerPart = Math.floor(n);
            var decimalPart = Math.round((n - integerPart) * 100); // Convert decimal to cents
            function translate(n) {
                var word = "";
                if (n < 10) {
                    word = singleDigit[n] + '';
                }
                else if (n < 20) {
                    word = doubleDigit[n - 10] + ' ';
                }
                else if (n < 100) {
                    var rem = translate(n % 10);
                    word = belowHundred[(n - n % 10) / 10 - 2] + ' ' + rem;
                }
                else if (n < 1000) {
                    var remainder = translate(n % 100);
                    word = singleDigit[Math.trunc(n / 100)] + ' Hundred ' + remainder;
                }
                else if (n < 1000000) {
                    var remainder = translate(n % 1000);
                    word = translate(Math.trunc(n / 1000)) + ' Thousand ' + remainder;
                }
                else if (n < 1000000000) {
                    var remainder = translate(n % 1000000);
                    word = translate(Math.trunc(n / 1000000)) + ' Million ' + remainder;
                }
                else {
                    var remainder = translate(n % 1000000000);
                    word = translate(Math.trunc(n / 1000000000)) + ' Billion ' + remainder;
                }
                return word;
            }
            // Create the words for the integer part
            var integerWords = translate(integerPart).trim();
            // Create the words for the decimal part
            var decimalWords = (decimalPart > 0) ? 'and ' + translate(decimalPart).trim() + ' cents' : '';
            // Construct the final result
            var result = (integerWords + ' ' + decimalWords).trim();
            return result;
        };

        Common.GetCurrentRecordId = function (fContext) {
            var currentRecId = fContext.data.entity.getId().replace('{', '').replace('}', '');
            return currentRecId;
        };

        Common.GetCurrentEntityName = function (fContext) {
            var currentEntityName = null;
            if (fContext.data != undefined && fContext.data != null) {
                currentEntityName = fContext.data.entity.getEntityName();
            }
            else {
                //@ts-ignore
                currentEntityName = fContext._entityName;
            }
            return currentEntityName;
        };

        Common.GetFormType = function (fContext) {
            //0	Undefined
            //1	Create
            //2	Update
            //3	Read Only
            //4	Disabled
            //6	Bulk Edit
            var formType = fContext.ui.getFormType();
            return formType;
        };

        Common.RefreshRibbon = function (fContext, refreshAll) {
            if (refreshAll === void 0) { refreshAll = false; }
            fContext.ui.refreshRibbon(refreshAll);
        };

        Common.RefreshFormData = function (fContext, save = false) {
            return new Promise((resolve, reject) => {
                try {
                    // Call the `refresh` method and resolve the promise with its result
                    fContext.data.refresh(save).then(response => {
                        resolve(response);
                    }).catch(error => {
                        reject(error); // Reject the promise if an error occurs
                    });
                } catch (error) {
                    reject(error); // Catch any synchronous errors
                }
            });
        };

        Common.IsFieldDirty = function (fContext, fieldName) {
            var isDirty = false;
            var field = fContext.getAttribute(fieldName);
            if (field != undefined && field != null) {
                //@ts-ignore
                isDirty = field.getIsDirty();
            }
            return isDirty;
        };

        Common.FormNotification = function (formContext, message, level = "INFO", uniqueId = null) {
            return new Promise((resolve, reject) => {
                try {
                    // Display form notification based on uniqueId presence
                    if (uniqueId !== null) {
                        formContext.ui.setFormNotification(message, level, uniqueId);
                    } else {
                        formContext.ui.setFormNotification(message, level);
                    }

                    // Resolve the promise since the operation is complete
                    resolve();
                } catch (error) {
                    // Reject the promise if an error occurs
                    reject(error);
                }
            });
        };

        Common.ClearFormNotification = function (formContext, uniqueId = "") {
            return new Promise((resolve, reject) => {
                try {
                    // Clear the form notification
                    formContext.ui.clearFormNotification(uniqueId);

                    // Resolve the Promise since the operation is complete
                    resolve();
                } catch (error) {
                    // Reject the Promise if an error occurs
                    reject(error);
                }
            });
        };

        Common.formatGUID = function (str) {
            if (str) {
                str = str.replace(/[{}]/g, '');
                str = str.toUpperCase();
            }
            return str;
        };

        Common.ODataLookupField = function (fieldLogicalName) {
            var isOffline = Quikrete.GlobalContext.IsOffline();
            if (isOffline) {
                return fieldLogicalName;
            }
            return "_" + fieldLogicalName + "_value";
        };

        Common.IsUndefinedOrNull = function (inputObj) {
            if (inputObj == undefined || inputObj == null) {
                return true;
            }
            else {
                return false;
            }
        };
        Common.SetFieldSubmitMode = function (fContext, fieldName, mode) {
            var field = fContext.getAttribute(fieldName);
            if (field != undefined && field != null) {
                //@ts-ignore
                field.setSubmitMode(mode); // 'mode' can be 'always', 'never', or 'dirty'
            }
        };
        Common.AddCustomFilter = function (fContext, fieldName, fetchXml, entityName) {
            var field = fContext.getControl(fieldName);
            if (field != undefined && field != null) {
                //@ts-ignore
                field.addCustomFilter(fetchXml, entityName);
            }
        };
        Common.getSchemaName = async function (fContext, entityName, fieldName) {

            const clientURL = fContext.getClientUrl();
            const entityDefination = await fetch(`${clientURL}/api/data/v9.2/EntityDefinitions(LogicalName='${entityName}')/Attributes(LogicalName='${fieldName}')`);

            const attr = await entityDefination.json();

            if (attr) {
                return attr?.SchemaName;
            } else {
                return '';
            }

        };

    })(Common = Quikrete.Common || (Quikrete.Common = {}));
})(Quikrete || (Quikrete = {}));

(function (Quikrete) {
    var WebApi;
    (function (WebApi) {
        WebApi.RetrieveRecord = function RetrieveRecord(entityName, recodId, queryParam) {
            //Show Progress Bar for  API call
            Quikrete.ProgressIndicator.Show("Getting Information");
            return new Promise(function (resolve, reject) {
                // Determine whether the context is offline or online
                var webApi = Quikrete.GlobalContext.IsOffline() ? Xrm.WebApi.offline : Xrm.WebApi.online;

                // Call the web API to retrieve the record
                webApi.retrieveRecord(entityName, recodId, queryParam)
                    .then(function (response) {
                        Quikrete.ProgressIndicator.Close();
                        resolve(response);  // Resolve with the response if successful
                    })
                    .catch(function (error) {
                        Quikrete.ProgressIndicator.Close();
                        reject(error);  // Reject with the error message if failed
                    });
            });
        };

        WebApi.RetrieveMultipleRecords = async function (entityName, queryParam) {
            //Show Progress Bar for  API call
            Quikrete.ProgressIndicator.Show("Getting Information");
            //return new Promise(function (resolve, reject) {
            //    // Determine whether the context is offline or online
            //    var webApi = Quikrete.GlobalContext.IsOffline() ? Xrm.WebApi.offline : Xrm.WebApi.online;

            //    // Call the web API to retrieve multiple records
            //    webApi.retrieveMultipleRecords(entityName, queryParam)
            //        .then(function (response) {
            //            Quikrete.ProgressIndicator.Close();
            //            // Resolve with the entities if available, or resolve with null
            //            if (response && response.entities && response.entities.length > 0) {
            //                resolve(response.entities);
            //            } else {
            //                resolve(null);  // Resolve with null if no records found
            //            }
            //        })
            //        .catch(function (error) {
            //            Quikrete.ProgressIndicator.Close();
            //            reject(error);  // Reject with the error if the API call fails
            //        });
            //});

            var webApi = Quikrete.GlobalContext.IsOffline() ? Xrm.WebApi.offline : Xrm.WebApi.online;

            try {

                let allRecords = [];
                let response = await webApi.retrieveMultipleRecords(entityName, queryParam);

                if (response && response.entities && response.entities.length > 0) {
                    allRecords = allRecords.concat(response.entities);
                }

                // Loop while there's a nextLink for pagination
                let nextLink = response["@odata.nextLink"] || response.nextLink;
                while (nextLink) {
                    // Use URL to extract the relative query string
                    const relativeQuery = new URL(nextLink).search;
                    response = await webApi.retrieveMultipleRecords(entityName, relativeQuery);
                    nextLink = response["@odata.nextLink"] || response.nextLink;
                    if (response && response.entities && response.entities.length > 0) {
                        allRecords = allRecords.concat(response.entities);
                    } else {
                        break; // exit loop if no more records
                    }
                }

                Quikrete.ProgressIndicator.Close();
                return allRecords;
            } catch (error) {
                Quikrete.ProgressIndicator.Close();
                throw error;
            }
        };

        WebApi.CreateRecord = function (entityName, record) {
            //Show Progress Bar for  API call
            Quikrete.ProgressIndicator.Show("Please Wait..");
            return new Promise(function (resolve, reject) {
                // Determine whether the context is offline or online
                var webApi = Quikrete.GlobalContext.IsOffline() ? Xrm.WebApi.offline : Xrm.WebApi.online;

                // Call the web API to create the record
                webApi.createRecord(entityName, record)
                    .then(function (response) {
                        Quikrete.ProgressIndicator.Close();
                        resolve(response);  // Resolve with the created record's response
                    })
                    .catch(function (error) {
                        Quikrete.ProgressIndicator.Close();
                        reject(error);  // Reject with the error if the creation fails
                    });
            });
        };

        WebApi.UpdateRecord = function (entityName, recordId, record) {
            //Show Progress Bar for  API call
            Quikrete.ProgressIndicator.Show("Please Wait..");
            return new Promise((resolve, reject) => {
                // Determine whether the context is offline or online
                const webApi = Quikrete.GlobalContext.IsOffline() ? Xrm.WebApi.offline : Xrm.WebApi.online;

                // Call the Web API to update the record
                webApi.updateRecord(entityName, recordId, record)
                    .then(response => {
                        Quikrete.ProgressIndicator.Close();
                        resolve(response);  // Resolve with the updated record response
                    })
                    .catch(error => {
                        Quikrete.ProgressIndicator.Close();
                        reject(error);  // Reject with the error if the update fails
                    });
            });
        };

        WebApi.DeleteRecord = function (entityName, recordId) {
            //Show Progress Bar for  API call
            Quikrete.ProgressIndicator.Show("Please Wait..");
            return new Promise((resolve, reject) => {
                // Determine whether the context is offline or online
                const webApi = Quikrete.GlobalContext.IsOffline() ? Xrm.WebApi.offline : Xrm.WebApi.online;

                // Call the Web API to delete the record
                webApi.deleteRecord(entityName, recordId)
                    .then(response => {
                        Quikrete.ProgressIndicator.Close();
                        resolve(response);  // Resolve with the response on success
                    })
                    .catch(error => {
                        Quikrete.ProgressIndicator.Close();
                        reject(error);  // Reject with the error if the deletion fails
                    });
            });
        };

        WebApi.Execute = function (executeRequest) {
            //Show Progress Bar for  API call
            Quikrete.ProgressIndicator.Show("Please Wait..");
            return new Promise((resolve, reject) => {
                // Determine if the context is offline or online
                const webApi = Quikrete.GlobalContext.IsOffline() ? Xrm.WebApi.offline : Xrm.WebApi.online;

                // Call the Web API's execute function
                webApi.execute(executeRequest)
                    .then(response => {
                        Quikrete.ProgressIndicator.Close();

                        if (!response.ok) {
                            throw new Error(`Request failed with status ${response.status}`);
                        }

                        // Handle 204 No Content
                        if (response.status === 204) {
                            resolve(null); // explicitly resolve with no body
                            return;
                        }

                        // Handle responses with body
                        return response.json();
                    })
                    .then(responseBody => {
                        Quikrete.ProgressIndicator.Close();
                        resolve(responseBody);  // Resolve the promise with the response body
                    })
                    .catch(error => {
                        Quikrete.ProgressIndicator.Close();
                        reject(error);  // Reject the promise with an error if something goes wrong
                    });
            });
        };

    })(WebApi = Quikrete.WebApi || (Quikrete.WebApi = {}));
})(Quikrete || (Quikrete = {}));

(function (Quikrete) {
    var GlobalContext;
    (function (GlobalContext) {

        GlobalContext.GetCurrentAppUniqueName = function () {
            return new Promise(function (resolve, reject) {
                var result = "";
                var globalContext = Xrm.Utility.getGlobalContext();

                globalContext.getCurrentAppProperties()
                    .then(function (app) {
                        result = app.uniqueName ?? result;  // Resolving with uniqueName
                        resolve(result);  // Return the result
                    })
                    .catch(function (error) {
                        reject(error);  // Reject with error in case of failure
                    });
            });
        };
        GlobalContext.GetCurrentUserId = function () {
            var userSettings = Xrm.Utility.getGlobalContext().userSettings;
            var currentuserid = userSettings.userId.replace('{', '').replace('}', '');
            //var username = userSettings.userName;
            return currentuserid;
        };
        GlobalContext.GetClientState = function () {
            var clientContext = Xrm.Utility.getGlobalContext().client;
            var clientState = clientContext.getClientState();
            return clientState;
        };
        GlobalContext.IsOffline = function () {
            var isOffline = false;
            var clientContext = Xrm.Utility.getGlobalContext().client;
            isOffline = clientContext.isOffline();
            return isOffline;
        };
        GlobalContext.CheckEntityAccess = function (entityName, privilegeType, privilegeDepth) {
            return new Promise(function (resolve, reject) {
                var finalResult = false;

                Xrm.Utility.getEntityMetadata(entityName, [])
                    .then(function (entityMetadata) {
                        var privilegeArray = entityMetadata["Privileges"];
                        if (privilegeArray != undefined && privilegeArray != null && privilegeArray.length > 0) {
                            var privilegeData = privilegeArray.filter(function (item) {
                                return item["PrivilegeType"] == privilegeType && item[privilegeDepth] == true;
                            });
                            if (privilegeData != null && privilegeData.length > 0) {
                                finalResult = true;
                            }
                        }
                        resolve(finalResult); // Resolve with the final result
                    })
                    .catch(function (error) {
                        reject(error); // Reject with an error if something fails
                    });
            });
        };
        GlobalContext.GetUserSetting = function () {
            return Xrm.Utility.getGlobalContext().userSettings;
        };
        GlobalContext.GetQueryStringParameters = function () {
            return Xrm.Utility.getGlobalContext().getQueryStringParameters();
        };
        GlobalContext.GetClientUrl = function () {
            return Xrm.Utility.getGlobalContext().getClientUrl();
        };
        GlobalContext.GetUserRoles = function () {
            var userSettings = GlobalContext.GetUserSetting();
            var userRoles = userSettings.roles.getAll();
            return userRoles;
        };

        GlobalContext.GetentityMetadata = function (entityName, attributes) {
            return new Promise(function (resolve, reject) {
                Xrm.Utility.getEntityMetadata(entityName, attributes)
                    .then(function (entityMetadata) {
                        resolve(entityMetadata); // Resolve with the final result
                    })
                    .catch(function (error) {
                        reject(error); // Reject with an error if something fails
                    });
            });
        }

    })(GlobalContext = Quikrete.GlobalContext || (Quikrete.GlobalContext = {}));
})(Quikrete || (Quikrete = {}));

(function (Quikrete) {
    var Navigation;
    (function (Navigation) {
        Navigation.OpenAlertDialog = function (textTitle, textDescription, alertOptions) {
            if (alertOptions === void 0) { alertOptions = { height: "auto", width: "auto" }; }
            return new Promise(function (resolve, reject) {
                var alertStrings = { text: textDescription, title: textTitle };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions)
                    .then(function (success) {
                        resolve(success); // Resolve with the success response
                    })
                    .catch(function (error) {
                        reject(error); // Reject with the error if something goes wrong
                    });
            });
        };

        Navigation.OpenConfirmationDialog = function (textTitle, textDescription, confirmOptions) {
            if (confirmOptions === void 0) { confirmOptions = { height: "auto", width: "auto" }; }
            return new Promise(function (resolve, reject) {
                var confirmStrings = { text: textDescription, title: textTitle };
                Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions)
                    .then(function (success) {
                        resolve(success); // Resolves with the result of the confirmation (true or false)
                    })
                    .catch(function (error) {
                        reject(error); // Reject with error if something goes wrong
                    });
            });
        };
        Navigation.NavigateTo = function (pageInput, navigationOptions) {
            return new Promise(function (resolve, reject) {
                Xrm.Navigation.navigateTo(pageInput, navigationOptions)
                    .then(function () {
                        resolve(true);  // Resolves with true on successful navigation
                    })
                    .catch(function () {
                        reject(false); // Rejects with false if navigation fails
                    });
            });
        };
        Navigation.OpenForm = function (entityFormOptions, formParameters) {
            return new Promise(function (resolve, reject) {
                Xrm.Navigation.openForm(entityFormOptions, formParameters)
                    .then(function (success) {
                        resolve(success);  // Resolves with the success result on successful form opening
                    })
                    .catch(function (error) {
                        reject(error);  // Rejects with the error if opening the form fails
                    });
            });
        };

        Navigation.OpenErrorDialog = function (message, details) {
            return new Promise(function (resolve, reject) {
                var errorOptions = {
                    message: message,
                    details: details
                };
                Xrm.Navigation.openErrorDialog(errorOptions)
                    .then(function (success) {
                        resolve(success);  // Resolves if user closes the dialog
                    })
                    .catch(function (error) {
                        reject(error);     // Rejects if there's an issue opening the dialog
                    });
            });
        };

    })(Navigation = Quikrete.Navigation || (Quikrete.Navigation = {}));
})(Quikrete || (Quikrete = {}));

(function (Quikrete) {
    var ProgressIndicator;
    (function (ProgressIndicator) {
        // Show progress indicator with a message
        ProgressIndicator.Show = function (message) {
            return new Promise(function (resolve, reject) {
                try {
                    Xrm.Utility.showProgressIndicator(message);
                    resolve();  // Resolves once the progress indicator is shown
                } catch (error) {
                    reject(error);  // Rejects in case of an error
                }
            });
        };

        // Close the progress indicator
        ProgressIndicator.Close = function () {
            return new Promise(function (resolve, reject) {
                try {
                    Xrm.Utility.closeProgressIndicator();
                    resolve();  // Resolves once the progress indicator is closed
                } catch (error) {
                    reject(error);  // Rejects in case of an error
                }
            });
        };

    })(ProgressIndicator = Quikrete.ProgressIndicator || (Quikrete.ProgressIndicator = {}));
})(Quikrete || (Quikrete = {}));

(function (Quikrete) {
    var Security;
    (function (Security) {
        /**
         * Retrieves role names for the given Role IDs using the common library API functions.
         * @param {Array<string>} roleIds - An array of GUIDs representing role IDs.
         * @returns {Promise<Array<string>>} - A promise that resolves to an array of role names.
         */
        Security.GetRolesByIds = function (roleIds) {
            return new Promise(function (resolve, reject) {
                if (!Array.isArray(roleIds) || roleIds.length === 0) {
                    reject("An array of RoleIds is required.");
                    return;
                }

                // Build the filter query to fetch all roles matching the given IDs
                const filters = roleIds
                    .map(roleId => `RoleId eq guid'${roleId}'`)
                    .join(" or ");
                const queryParam = `?$filter=${filters}&$select=Name`;

                Quikrete.WebApi.RetrieveMultipleRecords("RoleSet", queryParam)
                    .then(function (roles) {
                        if (roles && roles.length > 0) {
                            // Extract names of all matching roles
                            const roleNames = roles.map(role => role.Name);
                            resolve(roleNames);
                        } else {
                            resolve([]); // Return an empty array if no roles are found
                        }
                    })
                    .catch(function (error) {
                        reject(`Failed to retrieve roles: ${error.message}`);
                    });
            });
        };

        /**
         * Retrieves the Business Unit for a given System User ID.
         * @param {string} systemUserId - A GUID representing the System User ID.
         * @returns {Promise<string>} - A promise that resolves to the Business Unit ID in uppercase.
         */
        Security.GetBusinessUnit = function (systemUserId) {
            return new Promise(function (resolve, reject) {
                if (!systemUserId) {
                    reject("SystemUserId is required.");
                    return;
                }

                Quikrete.WebApi.RetrieveRecord("systemuser", systemUserId)
                    .then(function (users) {
                        if (users !== null) {
                            const businessUnitId = users._businessunitid_value;
                            resolve(businessUnitId.toUpperCase()); // Resolve the Business Unit ID in uppercase
                        } else {
                            reject("No user found with the provided SystemUserId.");
                        }
                    })
                    .catch(function (error) {
                        reject(`Failed to retrieve business unit: ${error.message}`);
                    });
            });
        };

        Security.GetEnvironmentVariableValue = function getEnvironmentVariableValue(variableName) {
            return new Promise(function (resolve, reject) {
                // Construct the OData query to fetch the environment variable by its display name
                var query = "?$filter=displayname eq '" + variableName + "'&$select=value";

                // Make the web API call
                Xrm.WebApi.retrieveMultipleRecords("environmentvariabledefinition", query).then(
                    function success(result) {
                        if (result.entities.length > 0) {
                            var value = result.entities[0].value;
                            console.log("Environment Variable Value: ", value);
                            resolve(value);  // Resolve with the environment variable value
                        } else {
                            reject("No environment variable found with the name " + variableName);  // Reject if no variable is found
                        }
                    },
                    function (error) {
                        reject("Error retrieving environment variable: " + error.message);  // Reject with error message
                    }
                );
            });
        };

    })(Security = Quikrete.Security || (Quikrete.Security = {}));
})(Quikrete || (Quikrete = {}));