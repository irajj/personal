﻿var Quikrete = Quikrete || {};
Quikrete.FormExtension = (function () {

    var isMainGridContext = false;
    function addPluralization() {
        // Extend String prototype to support pluralization
        String.prototype.plural = function (revert) {
            var plural = {
                "(quiz)$": "$1zes",
                "^(ox)$": "$1en",
                "([m|l])ouse$": "$1ice",
                "(matr|vert|ind)ix|ex$": "$1ices",
                "(x|ch|ss|sh)$": "$1es",
                "([^aeiouy]|qu)y$": "$1ies",
                "(hive)$": "$1s",
                "(?:([^f])fe|([lr])f)$": "$1$2ves",
                "(shea|lea|loa|thie)f$": "$1ves",
                "sis$": "ses",
                "([ti])um$": "$1a",
                "(tomat|potat|ech|her|vet)o$": "$1oes",
                "(bu)s$": "$1ses",
                "(alias)$": "$1es",
                "(octop)us$": "$1i",
                "(ax|test)is$": "$1es",
                "(us)$": "$1es",
                "([^s]+)$": "$1s"
            };

            var irregular = {
                "move": "moves",
                "foot": "feet",
                "goose": "geese",
                "child": "children",
                "man": "men",
                "tooth": "teeth",
                "person": "people"
            };

            var uncountable = [
                "sheep",
                "fish",
                "deer",
                "moose",
                "series",
                "species",
                "money",
                "rice",
                "information",
                "equipment"
            ];

            if (uncountable.includes(this.toLowerCase())) return this;

            for (let word in irregular) {
                let pattern = revert ? new RegExp(irregular[word] + "$", "i") : new RegExp(word + "$", "i");
                let replace = revert ? word : irregular[word];

                if (pattern.test(this)) return this.replace(pattern, replace);
            }

            let array = revert ? singular : plural;
            for (let reg in array) {
                let pattern = new RegExp(reg, "i");

                if (pattern.test(this)) return this.replace(pattern, array[reg]);
            }

            return this;
        };
    }

    /**
     * Initializes form extensions for the given execution context.
     * @param {object} executionContext - The execution context provided by Dynamics 365.
     */
    function formContextExtensionInit(executionContext) {
        try {

            addPluralization();

            //if (Quikrete.IsDebuggerEnabled === true)
            //debugger;

            // Get the form context from the execution context
            var formContext;

            if (executionContext && typeof executionContext.getFormContext === "function") {
                // executionContext is a standard context object, retrieve form context
                formContext = executionContext.getFormContext();
            } else if (executionContext && typeof executionContext.getAttribute === "function") {
                // executionContext is already a FormContext (has form-specific functions)
                formContext = executionContext;
            }
            else if (executionContext && executionContext.getGrid && typeof executionContext.getGrid === "function") {
                // If executionContext has getGrid(), it's a Main Grid context
                //For this we just bind some methods only using flag
                isMainGridContext = true;
                formContext = executionContext;
            }
            else {
                console.error("Invalid executionContext: Unable to determine formContext");
                return;
            }

            // Ensure required modules are available
            if (
                typeof Quikrete !== "undefined" &&
                Quikrete.Common &&
                Quikrete.WebApi &&
                Quikrete.GlobalContext &&
                Quikrete.Navigation &&
                Quikrete.Security &&
                Quikrete.ProgressIndicator
            ) {
                if (!isMainGridContext) {

                    // Attach extensions to FormContext prototype
                    formContext.getFieldValue = function (fieldName) {
                        return Quikrete.Common.GetFieldValue(this, fieldName);
                    };
                    formContext.getFieldValueText = function (fieldName) {
                        return Quikrete.Common.GetFieldValueText(this, fieldName);
                    };
                    formContext.getLookupFieldText = function (fieldName) {
                        return Quikrete.Common.GetLookupFieldText(this, fieldName);
                    };

                    formContext.setFieldValue = function (fieldName, fieldValue) {
                        return Quikrete.Common.SetFieldValue(this, fieldName, fieldValue);
                    };

                    formContext.makeFieldRequired = function (fieldName, reqLevel = true) {
                        Quikrete.Common.MakeFieldRequired(this, fieldName, reqLevel);
                    };

                    formContext.makeFieldDisabled = function (fieldName, disabled = true) {
                        Quikrete.Common.MakeFieldDisabled(this, fieldName, disabled);
                    };

                    formContext.makeFieldVisible = function (fieldName, visible = true) {
                        Quikrete.Common.MakeFieldVisibled(this, fieldName, visible);
                    };

                    formContext.setFieldSubmitMode = function (fieldName, mode = "always") {
                        Quikrete.Common.SetFieldSubmitMode(this, fieldName, mode);
                    };

                    // Form-related utilities
                    formContext.makeSectionVisible = function (tabName, sectionName, visible = true) {
                        Quikrete.Common.MakeSectionVisibled(this, tabName, sectionName, visible);
                    };

                    formContext.setFieldValidationMessage = function (fieldName, message) {
                        Quikrete.Common.SetFieldValidationMsg(this, fieldName, message);
                    };

                    formContext.clearFieldValidationMessage = function (fieldName) {
                        Quikrete.Common.ClearFieldValidationMsg(this, fieldName);
                    };

                    formContext.makeFormReadonly = function () {
                        Quikrete.Common.MakeFormReadonly(this);
                    };

                    formContext.refreshRibbon = function (refreshAll = false) {
                        Quikrete.Common.RefreshRibbon(this, refreshAll);
                    };

                    formContext.refreshFormData = function (save = false) {
                        return Quikrete.Common.RefreshFormData(this, save);
                    };

                    formContext.isFieldDirty = function (fieldName) {
                        return Quikrete.Common.IsFieldDirty(this, fieldName);
                    };

                    formContext.getFormType = function () {
                        return Quikrete.Common.GetFormType(this);
                    };

                    formContext.getCurrentRecordId = function () {
                        return Quikrete.Common.GetCurrentRecordId(this);
                    };

                    formContext.getCurrentEntityName = function () {
                        return Quikrete.Common.GetCurrentEntityName(this);
                    };

                    formContext.getPlural = function (spell) {
                        return spell.plural();
                    }
                }

                formContext.formatGUID = function (guid) {
                    return Quikrete.Common.formatGUID(guid);
                };

                formContext.retrieveRecord = async function (entityName, recordId, queryParam) {
                    return await Quikrete.WebApi.RetrieveRecord(entityName, recordId, queryParam);
                };

                formContext.retrieveMultipleRecords = async function (entityName, queryParam) {
                    return await Quikrete.WebApi.RetrieveMultipleRecords(entityName, queryParam);
                };

                formContext.createRecord = function (entityName, record) {
                    return Quikrete.WebApi.CreateRecord(entityName, record);
                };

                formContext.updateRecord = function (entityName, recordId, record) {
                    return Quikrete.WebApi.UpdateRecord(entityName, recordId, record);
                };

                formContext.deleteRecord = function (entityName, recordId) {
                    return Quikrete.WebApi.DeleteRecord(entityName, recordId);
                };

                formContext.execute = function (executeRequest) {
                    return Quikrete.WebApi.Execute(executeRequest);
                };

                formContext.openAlertDialog = function (textTitle, textDescription, alertOptions = { height: "auto", width: "auto" }) {
                    return Quikrete.Navigation.OpenAlertDialog(textTitle, textDescription, alertOptions);
                };

                formContext.openConfirmationDialog = function (textTitle, textDescription, confirmOptions = { height: "auto", width: "auto" }) {
                    return Quikrete.Navigation.OpenConfirmationDialog(textTitle, textDescription, confirmOptions);
                };

                formContext.errorDialog = function (message, details) {
                    return Quikrete.Navigation.OpenErrorDialog(message, details);
                };

                formContext.navigateTo = function (pageInput, navigationOptions) {
                    return Quikrete.Navigation.NavigateTo(pageInput, navigationOptions);
                };

                formContext.openForm = function (entityFormOptions, formParameters) {
                    return Quikrete.Navigation.OpenForm(entityFormOptions, formParameters);
                };

                formContext.show = function (message) {
                    return Quikrete.ProgressIndicator.Show(message);
                };

                formContext.close = function () {
                    return Quikrete.ProgressIndicator.Close();
                };

                formContext.getRolesByIds = function (roleIds) {
                    return Quikrete.Security.GetRolesByIds(roleIds);
                };

                formContext.getBusinessUnit = function (systemUserId) {
                    return Quikrete.Security.GetBusinessUnit(systemUserId);
                };

                formContext.getEnvironmentVariableValue = function (variableName) {
                    return Quikrete.Security.GetEnvironmentVariableValue(variableName);
                };

                // Global context-related utilities
                formContext.getUserSetting = function () {
                    return Quikrete.GlobalContext.GetUserSetting();
                };

                formContext.getCurrentAppUniqueName = async function () {
                    return await Quikrete.GlobalContext.GetCurrentAppUniqueName();
                };

                formContext.getCurrentUserId = function () {
                    return Quikrete.GlobalContext.GetCurrentUserId();
                };

                formContext.getClientState = function () {
                    return Quikrete.GlobalContext.GetClientState();
                };

                formContext.isOffline = function () {
                    return Quikrete.GlobalContext.IsOffline();
                };

                formContext.getQueryStringParameters = function () {
                    return Quikrete.GlobalContext.GetQueryStringParameters();
                };

                formContext.getClientUrl = function () {
                    return Quikrete.GlobalContext.GetClientUrl();
                };

                formContext.isUserAdministrator = function () {
                    var userRoles = Quikrete.GlobalContext.GetUserRoles();
                    var isAdmin = false;
                    var adminRoles = ["System Administrator"];
                    // Use 'some' to check if any role matches the admin roles
                    isAdmin = userRoles.some(role => adminRoles.includes(role.name));
                    return isAdmin;
                };

                formContext.getUserTeams = async function (userId) {
                    var userTeamName = [];
                    // Define the query to get the teams the user belongs to
                    const queryParam = `?$filter=systemuserid eq '${userId}'&$select=teamid`;

                    // Make the Web API request to retrieve the team memberships
                    var response = await Quikrete.WebApi.RetrieveMultipleRecords("teammembership", queryParam);

                    for (const teamMembership of response) {
                        var teamId = teamMembership.teamid;
                        var teams = await Quikrete.WebApi.RetrieveRecord("team", teamId, "");
                        var teamobj = {
                            UserId: userId,
                            TeamId: teamId,
                            TeamName: teams.name
                        };
                        userTeamName.push(teamobj);
                    }
                    return userTeamName; // Note: This will be empty when the function is initially called due to async behavior
                };

                formContext.getentityMetadata = async function (entityName, attributes) {
                    // Make the Web API request to retrieve the team memberships
                    var response = await Quikrete.GlobalContext.GetentityMetadata(entityName, attributes);
                    return response; // Note: This will be empty when the function is initially called due to async behavior
                };

                formContext.addCustomFilter = function (fieldName, fatchXML, entityName) {
                    Quikrete.Common.AddCustomFilter(this, fieldName, fatchXML, entityName);
                };

                formContext.getQuickViewControlValue = function (quickViewControlName, fieldName) {
                    return Quikrete.Common.GetQuickViewControlValue(this, quickViewControlName, fieldName);
                };

                formContext.getPlural = function (spell) {
                    return spell.plural();
                }

                formContext.getSchemaName = async function (entityName, fieldName) {
                    return Quikrete.Common.getSchemaName(this, entityName, fieldName);
                }


                formContext.validateAllRequiredFields = function validateAllRequiredFields() {
                    var attributes = formContext.data.entity.attributes.get();

                    attributes.forEach(function (attribute) {
                        var isRequired = attribute.getRequiredLevel() === "required";
                        var value = attribute.getValue();
                        var attributeName = attribute.getName();
                        var control = formContext.getControl(attributeName);

                        // Skip if no control (hidden field or unsupported type)
                        if (!control) return;

                        if (isRequired && (value === null || value === "")) {
                            control.setNotification("This field is required.", "REQUIRED_" + attributeName);
                        } else {
                            control.clearNotification("REQUIRED_" + attributeName);
                        }
                    });
                }
                formContext.validateAllRequiredFields = function validateAllRequiredFields() {
                    var attributes = formContext.data.entity.attributes.get();

                    attributes.forEach(function (attribute) {
                        var isRequired = attribute.getRequiredLevel() === "required";
                        var attributeName = attribute.getName();
                        var control = formContext.getControl(attributeName);

                        if (!control) return; // skip hidden/system fields

                        // Attach onchange handler if not already attached
                        if (!attribute._hasValidationHandler) {
                            attribute.addOnChange(function () {
                                validateField(attribute, control);
                            });
                            attribute._hasValidationHandler = true; // custom flag
                        }

                        // Run initial validation
                        validateField(attribute, control);
                    });
                };

                function validateField(attribute, control) {
                    var value = attribute.getValue();
                    var isRequired = attribute.getRequiredLevel() === "required";
                    var attributeName = attribute.getName();

                    if (isRequired && (value === null || value === "")) {
                        control.setNotification("This field is required.", "REQUIRED_" + attributeName);
                    } else {
                        control.clearNotification("REQUIRED_" + attributeName);
                    }
                }
                console.log("FormExtension initialized successfully.");
            } else {
                console.error("Missing required Quikrete modules.");
            }
        } catch (error) {
            console.error("Error initializing FormExtension:", error);
        }
    };

    return {
        Init: formContextExtensionInit
    }
}());