﻿var Quikrete = Quikrete || {};
Quikrete.OpportunityProduct = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    var userHasAdministratorRole = null;
    var recordBuid = null;
    var isdiscountpercentchange = false;

    function init(executionContext) {
        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.

        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();
        top.FormContext = formContext;
        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);
        formContext.data.entity.addOnPostSave(onPostSaveHandler)
        // call function on change of Discount Amount  manualdiscountamount
        if (formContext.getAttribute("new_manualdiscount") != null)
            formContext.getAttribute("new_manualdiscount").addOnChange(onChangeOfManualDiscount);

        // call function on change of manualdiscountamount
        if (formContext.getAttribute("manualdiscountamount") != null)
            formContext.getAttribute("manualdiscountamount").addOnChange(onChangeOfManualDiscount);

        // call function on change of discount percentage
        if (formContext.getAttribute("new_discountpercent") != null)
            formContext.getAttribute("new_discountpercent").addOnChange(onChangeOfDiscountPercentage);

        // call function on change of Pcs / Qty
        if (formContext.getAttribute("new_pcs") != null)
            formContext.getAttribute("new_pcs").addOnChange(onChangeOfPcsPerQty);

        // call function on change of Price Per Unit
        if (formContext.getAttribute("priceperunit") != null)
            formContext.getAttribute("priceperunit").addOnChange(onChangeOfPricePerUnit);

        // call function on change of UOM
        if (formContext.getAttribute("uomid") != null)
            formContext.getAttribute("uomid").addOnChange(onChangeOfUOMId);
    }

    async function formOnLoad() {

        var formType = formContext.getFormType();
        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);
        recordBuid = await Quikrete.ISVFunctions.GetRecordBuidFromLookup(formContext, "opportunityid");
        var opportunityDotProject = null, opportunityManufacturingId = null;
        formContext.getControl("new_manufacturinglocationid").setFocus(true);
        formContext.setFieldSubmitMode("new_productcode");
        formContext.setFieldSubmitMode("new_segment_lookup");
        formContext.setFieldSubmitMode("new_supersegment_lookup");
        formContext.setFieldSubmitMode("quantity");
        formContext.setFieldSubmitMode("new_extendedpriceperunit");
        formContext.setFieldSubmitMode("new_productdescriptioneditable");
        formContext.setFieldSubmitMode("new_changedby");
        formContext.setFieldSubmitMode("new_priceperpound");
        formContext.setFieldSubmitMode("new_totalweight");
        formContext.setFieldSubmitMode("new_weightperunit");
        formContext.setFieldSubmitMode("new_weightuom");

        //Filter Manufaturing Location By Buisness Unit Id.
        Quikrete.ISVFunctions.FilterLookup(formContext, "new_manufacturinglocationid", recordBuid, "new_owningbusinessunit");

        if (formType === Quikrete.Common.FormType.Create) { // Form type 1: Create
            formContext.setFieldValue("quantity", 1.0);
            formContext.setFieldValue("new_pcs", 1.0);
            var opportunity = formContext.getFieldValue("opportunityid");
            if (opportunity != null) {
                var OpportunityID = opportunity[0].id;
                const queryParameterForOpportunity = `?$select=new_dotproject,_new_manufacturinglocationid_value`;
                var opportunintyResponse = await formContext.retrieveRecord("opportunity", OpportunityID, queryParameterForOpportunity);
                if (opportunintyResponse != null) {
                    opportunityDotProject = opportunintyResponse.new_dotproject;
                    if (opportunityDotProject == "1") {
                        formContext.setFieldValue("new_followdotspecs", true);
                    }
                    else {
                        formContext.setFieldValue("new_followdotspecs", false);
                    }
                    opportunityManufacturingId = opportunintyResponse._new_manufacturinglocationid_value;
                    if (opportunityManufacturingId != null) {
                        var lookupValue = new Array();
                        lookupValue[0] = new Object();

                        lookupValue[0].id = opportunintyResponse["_new_manufacturinglocationid_value"];
                        lookupValue[0].name = opportunintyResponse["_new_manufacturinglocationid_value@OData.Community.Display.V1.FormattedValue"];
                        lookupValue[0].entityType = opportunintyResponse["_new_manufacturinglocationid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        formContext.setFieldValue("new_manufacturinglocationid", lookupValue);

                    }
                }
            }

        }


        if (formType == Quikrete.Common.FormType.Update || formType == Quikrete.Common.FormType.ReadOnly || formType == Quikrete.Common.FormType.Disabled) {
            if (formContext.getFieldValue("new_sequencenumber") != null) {
                formContext.makeFieldVisible("new_sequencechange", false);
            }
        }

        formContext.setFieldSubmitMode("new_amount");
        formContext.setFieldSubmitMode("new_priceperunit");
        formContext.setFieldSubmitMode("new_altproductdescription");
        var productNumber = formContext.getFieldValue("new_productnumber");
        if (productNumber != null) {
            var product = formContext.getFieldValue("productid");
            if (product != null) {
                var productId = product[0].id;
                productDescriptionEnableDisable(productId);
            }
        }
        var stage = formContext.getFieldValue("new_stage");
        if (stage != null && stage == "60") {
            formContext.makeFieldRequired("new_reasonlost", true);
        }
        setPricingfields(formType);
    }

    function setPricingfields(formType) {

        formContext.setFieldValue("isproductoverridden", false);
        formContext.getAttribute("isproductoverridden").fireOnChange();

        if (recordBuid.toUpperCase() === Quikrete.Common.RinkerBU) {
            formContext.setFieldValue("ispriceoverridden", false);
            formContext.setFieldValue("new_priceoverridden", true);
        }
        else {
            formContext.setFieldValue("ispriceoverridden", true);
        }

        formContext.getAttribute("ispriceoverridden").fireOnChange();
        formContext.makeFieldVisible("productid", false);
        formContext.makeFieldVisible("productdescription", false);
        formContext.getControl("new_manufacturinglocationid").setFocus(true);


        if (formType != Quikrete.Common.FormType.Create) {
            formContext.setFieldSubmitMode("isproductoverridden", "never");
            formContext.makeFieldDisabled("uomid", false);
        }
        else {
            formContext.makeFieldDisabled("uomid", true);
        }

        setTimeout(async () => {
            formContext.makeFieldDisabled("ispriceoverridden", true);
            formContext.ui.tabs.get("Admin")?.sections.get("Hidden")?.setVisible(false);
        }, 500);

    }

    async function productDescriptionEnableDisable(productId) {
        const queryParameter = `?$select=new_sourcesystem,_new_family_value`;
        var result = await formContext.retrieveRecord("product", productId, queryParameter);
        if (result != null) {

            let productFamily = [
                "Write In - EC" //	141
                , "Write In - Metal Bridge"	//144
                , "Write In - Walls"	//145
                , "Write In - Geosynthetics"	//146
                , "Write In - Sanitary"	//174
                , "Structural Plate Detention"	//117
                , "Write In - Pipe"	//28
                , "Lump Sum Product" //121
            ];

            const normalizedList = productFamily.map(item => item.toLowerCase().trim());
            const sourceSystem = result['new_sourcesystem'];
            const productFamilyText = result['_new_family_value@OData.Community.Display.V1.FormattedValue'];
            const productFamilyValue = result['_new_family_value'];
            let oppId = formContext.getFieldValue("opportunityid");
            if (sourceSystem != null && productFamilyValue != null) {
                if (sourceSystem == "1" && !normalizedList.includes(productFamilyText.toLowerCase().trim())) {
                    formContext.makeFieldDisabled("new_productdescriptioneditable", true);
                }
                else {
                    formContext.makeFieldDisabled("new_productdescriptioneditable", false);
                }
            }
            if (oppId != null) {
                let oppresult = await formContext.retrieveRecord("opportunity", oppId[0]?.id, "?$select=statecode");
                if (oppresult.statecode != 0) {
                    formContext.makeFieldDisabled("new_productdescriptioneditable", true);
                }
            }

        }
    }

    async function formOnSave(e) {
        var eventArgs = e?.getEventArgs();
        if (formContext.getFieldValue("opportunityid") != null) {
            let oppId = formContext.getFieldValue("opportunityid");
            let result = await formContext.retrieveRecord("opportunity", oppId[0].id, "?$select=statecode");
            if (result != null && result["statecode"] != 0) {
                eventArgs.preventDefault();
                return;
            }
        }

        await Quikrete.ISVFunctions.SavePCFData(formContext, e);
        calculateAmounts();

        var formType = formContext.getFormType();
        if (formType === Quikrete.Common.FormType.Create || formType === Quikrete.Common.FormType.Update) {
            // Fill User look up
            formContext.setFieldValue("new_changedby", formContext.getUserSetting().userName)
        }
        var itemnumber = '';
        var newItemNum = null, productDescriptionEditable = null;
        newItemNum = formContext.getFieldValue("new_itemno");
        productDescriptionEditable = formContext.getFieldValue("new_productdescriptioneditable");
        formContext.setFieldSubmitMode("new_productdescriptioneditable");
        if (newItemNum != null && productDescriptionEditable != null) {
            itemnumber = newItemNum + '-' + productDescriptionEditable;
        }
        else if (newItemNum == '' || newItemNum == null) {
            itemnumber = productDescriptionEditable;
        }
        else if (productDescriptionEditable == '' || productDescriptionEditable == null) {
            itemnumber = newItemNum;
        }
        formContext.setFieldValue("new_productdescriptionwithitemnumber", itemnumber);
        formContext.setFieldSubmitMode("new_pcs");
        formContext.setFieldSubmitMode("new_discountpercent");
        formContext.setFieldSubmitMode("new_extendedpriceperunit");
        formContext.setFieldSubmitMode("new_supersegment_lookup");
        formContext.setFieldSubmitMode("new_amount");

        if (formType === Quikrete.Common.FormType.Update)// Form type 2: Update
        {
            var stageValue = formContext.getFieldValue("new_stage") == null ? "" : formContext.getFieldValueText("new_stage");
            var stageValueText = formContext.getFieldValue("new_stage") == null ? "" : formContext.getFieldValue("new_stage");
            if (formContext.getFieldValue("new_lastupdatedstage") !== stageValueText && formContext.getFieldValue("new_lastupdatedstage") !== stageValue) {
                formContext.setFieldValue("new_lastupdatedstage", stageValue);
                formContext.setFieldSubmitMode("new_lastupdatedstage");
            }
        }
    }

    function onChangeOfPcsPerQty() {
        calculateAmounts();
    }

    function onChangeOfPricePerUnit() {
        calculateAmounts();
    }

    function onChangeOfManualDiscount() {
        var manualDiscount = formContext.getFieldValue("manualdiscountamount");
        if (manualDiscount != null) {
            isdiscountpercentchange = false;
            calculateAmounts();
        }
    }

    function onChangeOfDiscountPercentage() {
        var discountPercent = formContext.getFieldValue("new_discountpercent");
        if (discountPercent != null) {
            isdiscountpercentchange = true;
            calculateAmounts();
        }
    }

    function calculateAmounts() {

        var uomlist = formContext.getFieldValue("new_pamuomlist");
        var uomText = formContext.getLookupFieldText("uomid");

        let needLengthMultiplier = true;

        if (uomlist && uomText) {
            const uomlistArray = uomlist.split(",");
            needLengthMultiplier = uomlistArray.some(u => u.trim().toLowerCase() === uomText.toLowerCase());
        }

        var lengthMultiplier = Number(formContext.getFieldValue("new_lengthmultiplier")) || 1.0;
        var pcsPerQty = Number(formContext.getFieldValue("new_pcs")) || 0;

        // Calculate quantity exactly like legacy intent
        const quantity = needLengthMultiplier ? pcsPerQty * lengthMultiplier : pcsPerQty;


        var priceoverridden = formContext.getFieldValue("new_priceoverridden");
        if (priceoverridden == null) {
            priceoverridden = false;
            formContext.setFieldValue("new_priceoverridden", false);
        }

        var unitPrice = Number(formContext.getFieldValue("priceperunit"));
        var discountpercent = Number(formContext.getFieldValue("new_discountpercent"));
        var manualDiscount = Number(formContext.getFieldValue("manualdiscountamount"));

        // Default fallbacks for missing/invalid values
        if (isNaN(unitPrice)) unitPrice = 0;
        if (isNaN(discountpercent)) discountpercent = 0;
        if (isNaN(manualDiscount)) manualDiscount = 0;

        // --- Handle Discount Logic ---
        // If user changed discount percent, calculate manual discount
        if (isdiscountpercentchange) {
            manualDiscount = ((unitPrice * quantity) * discountpercent) / 100;
        } else {
            // Avoid division by zero
            if (unitPrice * quantity > 0) {
                discountpercent = (100 * manualDiscount) / (unitPrice * quantity);
            } else {
                discountpercent = 0;
            }
        }

        // --- Extended and Base Amounts ---
        var extendedpriceperunit = unitPrice - ((unitPrice * discountpercent) / 100);
        if (isNaN(extendedpriceperunit)) extendedpriceperunit = 0;

        var extendedAmount = extendedpriceperunit * quantity;
        if (isNaN(extendedAmount)) extendedAmount = 0;

        var baseAmount = unitPrice * quantity;
        if (isNaN(baseAmount)) baseAmount = 0;

        // --- Set Fields ---
        formContext.setFieldValue("quantity", quantity);
        formContext.setFieldValue("manualdiscountamount", manualDiscount);
        formContext.setFieldValue("new_manualdiscount", manualDiscount);
        formContext.setFieldValue("new_discountpercent", discountpercent);
        formContext.setFieldValue("new_extendedpriceperunit", extendedpriceperunit);
        formContext.setFieldValue("extendedamount", extendedAmount);
        formContext.setFieldValue("baseamount", baseAmount);
        formContext.setFieldValue("new_amount", baseAmount);
    }


    async function onPostSaveHandler() {
        await Quikrete.ISVFunctions.PostSaveHandlerForPCF(formContext);
    }

    function assignInsertSequenceNumber(executionContext) {
        const formContext = executionContext.getFormContext();
        var primaryEntityName = formContext.data.entity.getEntityName();
        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
        top.Quikrete = Quikrete;
        top.primaryEntityName = primaryEntityName
        const stdButtonAttr = formContext.getAttribute("new_sequencechange");
        const stdValue = stdButtonAttr?.getValue();
        if (stdValue === "Assign/Insert Sequence #") {
            try {
                let OrderDetailsId = formContext.getCurrentRecordId();

                let pageInput = {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_InsertProduct",
                    data: new URLSearchParams({ OrderDetailsId }).toString(),
                };
                let navigationOptions = {
                    target: 2,
                    width: { value: 50, unit: "%" },
                    height: { value: 50, unit: "%" },
                    position: 1
                };
                formContext.navigateTo(pageInput, navigationOptions);
            }
            catch (error) {
                console.log("Error: " + error.message);
            }
        }
        stdButtonAttr.setValue(null);
        stdButtonAttr.setSubmitMode("never");
    }

    async function onChangeOfUOMId() {
        calculateAmounts();
    }

    return {
        Init: init,
        FormOnLoad: formOnLoad,
        AssignInsertSequenceNumber: assignInsertSequenceNumber
    }
}());