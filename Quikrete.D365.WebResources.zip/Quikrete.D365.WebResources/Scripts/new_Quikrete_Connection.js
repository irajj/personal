﻿var Quikrete = Quikrete || {};
Quikrete.Connection = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;

    function init(executionContext) {
        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        // Adds a function to be called when form data is loaded.
        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);

        //on Change of Role To
        if (formContext.getAttribute("record2roleid") != null)
            formContext.getAttribute("record2roleid").addOnChange(onChangeOfRoleTo);

    }


    async function formOnLoad() {
        formContext.getControl("record2roleid")?.setFocus();
        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);
        //check role of user
        var isSysAdmin = await formContext.isUserAdministrator();
        var regardingobjectid = formContext.getFieldValue("record1id");
        if (regardingobjectid != null) {
            if (regardingobjectid[0].entityType == 'account') {
                var accountRoles = ['SE', 'BC', 'SWC', 'IBC'];

                formContext.getControl("record2roleid").addPreSearch(function () {
                    addLookupFilter(accountRoles, 'eq', isSysAdmin, true);
                });
            }
            else if (regardingobjectid[0].entityType == 'opportunity' || regardingobjectid[0].entityType == 'quote' || regardingobjectid[0].entityType == 'salesorder') {
                var roles = ['- Spec', '- Dest'];

                formContext.getControl("record2roleid").addPreSearch(function () {
                    addLookupFilter(roles, 'like', isSysAdmin, false);
                });
            }

            if (isSysAdmin != 1) {
                formContext.makeFieldDisabled("record2id", true);
                formContext.makeFieldDisabled("new_piperegion", true);
                formContext.makeFieldDisabled("new_stormwaterregion", true);
                formContext.makeFieldDisabled("new_structuresregion", true);

                var formType = formContext.getFormType();
                if (formType === Quikrete.Common.FormType.Update) { // Form type 2: Update
                    formContext.makeFieldDisabled("record2roleid", true);
                }
            }
        }

        if (regardingobjectid != null) {
            if (regardingobjectid[0].entityType == 'account')
                return;

            let retriveBusinessid = await formContext.retrieveRecord(regardingobjectid[0].entityType, regardingobjectid[0].id, "?$select=_owningbusinessunit_value");
            if (retriveBusinessid != null && retriveBusinessid['_owningbusinessunit_value@OData.Community.Display.V1.FormattedValue'] != "Contech") {
                formContext.openAlertDialog("Access to this form is restricted based on your security permissions").then(
                    function (success) {
                        formContext.ui.close()
                    },
                    function (error) {
                        formContext.ui.close()
                    }
                );
            }
        }

        formContext.getControl("record2id").setEntityTypes(["systemuser"]);
    }

    //Function to add filter for connection role.
    function addLookupFilter(roles, operator, isSysAdmin, flag) {
        var fetchStr = "<filter type='or'>";
        let val = (flag == false ? "%" : "");
        for (let i of roles) {
            fetchStr += `<condition attribute='name' operator='${operator}' value='${val + i}' />`;
        }
        if (flag) {
            fetchStr += (isSysAdmin == 1 ? "<condition attribute='name' operator='eq' value='Area Manager - Pipe' />" : "");
        }
        fetchStr += "</filter>";
        formContext.addCustomFilter("record2roleid", fetchStr, "connectionrole");
    }


    async function onChangeOfRoleTo() {

        var regardingObject = formContext.getFieldValue("record1id");
        if (regardingObject != null) {
            var roleName = null;
            var entityZipCode = null;
            if (regardingObject[0].entityType == 'account') {
                var accountId = regardingObject[0].id;
                accountId = accountId.replace("{", "").replace("}", "");
                const queryParam = `?$select=address1_postalcode`;

                // Make the Web API request to retrieve
                var accountResponse = await formContext.retrieveRecord("account", accountId, queryParam);
                if (accountResponse != null) {
                    entityZipCode = accountResponse.address1_postalcode;
                }

                var lookupValue = new Array();
                lookupValue[0] = new Object();
                var record2RoleId = formContext.getFieldValue("record2roleid");
                if (record2RoleId != null) {
                    roleName = record2RoleId[0].name;
                    MakeFieldsRequired(roleName);

                }

                const queryParameterForzipCode = `?$select=new_zipcodeid,new_region,new_structuresregion,new_stormwaterregion,_new_bcnameid_value,_new_senameid_value,_new_swcnameid_value,_new_ibcnameid_value&$filter=new_zipcode eq '${entityZipCode}'`
                //queryParameterForzipCode = `?$select=new_zipcodeid,new_region,new_structuresregion,new_stormwaterregion,new_bcnameid,new_senameid,new_swcnameid,new_ibcnameid&$filter=new_zipcode eq '${entityZipCode}'`
                var zipcodeEntity = await formContext.retrieveMultipleRecords("new_zipcode", queryParameterForzipCode);
                if (zipcodeEntity != null) {
                    var result = zipcodeEntity[0];
                    var pipeRegion = result["new_region"];
                    var structurEsResion = result["new_structuresregion"];
                    var stormwaterRegion = result["new_stormwaterregion"];

                    if (roleName == "SE") {
                        lookupValue[0].id = result["_new_senameid_value"];
                        lookupValue[0].name = result["_new_senameid_value@OData.Community.Display.V1.FormattedValue"];
                        lookupValue[0].entityType = result["_new_senameid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        if (lookupValue[0].name != null) {
                            formContext.setFieldValue("record2id", lookupValue);
                        }
                        else {
                            formContext.openAlertDialog("This Connection cannot be added because there is no SE in the Zip Code Table for the zip code of this Account.");
                            formContext.setFieldValue("record2id", null);
                            formContext.setFieldValue("record2roleid", null);
                        }
                        formContext.setFieldSubmitMode("new_structuresregion");
                        formContext.setFieldValue("new_structuresregion", null);
                        formContext.setFieldSubmitMode("new_piperegion");
                        formContext.setFieldValue("new_piperegion", pipeRegion);
                        formContext.setFieldSubmitMode("new_stormwaterregion");
                        formContext.setFieldValue("new_stormwaterregion", null);
                    }
                    else if (roleName == "BC") {

                        lookupValue[0].id = result["_new_bcnameid_value"];
                        lookupValue[0].name = result["_new_bcnameid_value@OData.Community.Display.V1.FormattedValue"];
                        lookupValue[0].entityType = result["_new_bcnameid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        if (lookupValue[0].name != null) {
                            formContext.setFieldValue("record2id", lookupValue);
                        }
                        else {
                            formContext.openAlertDialog("This Connection cannot be added because there is no BC in the Zip Code Table for the zip code of this Account.");
                            formContext.setFieldValue("record2id", null);
                            formContext.setFieldValue("record2roleid", null);
                        }
                        formContext.setFieldSubmitMode("new_structuresregion");
                        formContext.setFieldValue("new_structuresregion", structurEsResion);
                        formContext.setFieldSubmitMode("new_piperegion");
                        formContext.setFieldValue("new_piperegion", null);
                        formContext.setFieldSubmitMode("new_stormwaterregion");
                        formContext.setFieldValue("new_stormwaterregion", null);
                    }

                    else if (roleName == "SWC") {
                        lookupValue[0].id = result["_new_swcnameid_value"];
                        lookupValue[0].name = result["_new_swcnameid_value@OData.Community.Display.V1.FormattedValue"];
                        lookupValue[0].entityType = result["_new_swcnameid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        if (lookupValue[0].name != null) {
                            formContext.setFieldValue("record2id", lookupValue);
                        }
                        else {
                            formContext.openAlertDialog("This Connection cannot be added because there is no SWC in the Zip Code Table for the zip code of this Account.");
                            formContext.setFieldValue("record2id", null);
                            formContext.setFieldValue("record2roleid", null);
                        }
                        formContext.setFieldSubmitMode("new_stormwaterregion");
                        formContext.setFieldValue("new_stormwaterregion", stormwaterRegion);
                        formContext.setFieldSubmitMode("new_piperegion");
                        formContext.setFieldValue("new_piperegion", null);
                        formContext.setFieldSubmitMode("new_structuresregion");
                        formContext.setFieldValue("new_structuresregion", null);
                    }
                    else if (roleName == "IBC") {
                        lookupValue[0].id = result["_new_ibcnameid_value"];
                        lookupValue[0].name = result["_new_ibcnameid_value@OData.Community.Display.V1.FormattedValue"];
                        lookupValue[0].entityType = result["_new_ibcnameid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        if (lookupValue[0].name != null) {
                            formContext.setFieldValue("record2id", lookupValue);
                        }
                        else {
                            formContext.openAlertDialog("This Connection cannot be added because there is no IBC in the Zip Code Table for the zip code of this Account.");
                            formContext.setFieldValue("record2id", null);
                            formContext.setFieldValue("record2roleid", null);
                        }
                        formContext.setFieldSubmitMode("new_structuresregion");
                        formContext.setFieldValue("new_structuresregion", structurEsResion);
                        formContext.setFieldSubmitMode("new_piperegion");
                        formContext.setFieldValue("new_piperegion", null);
                        formContext.setFieldSubmitMode("new_stormwaterregion");
                        formContext.setFieldValue("new_stormwaterregion", null);
                    }
                }



            }

        }
    }
    async function formOnSave(executionContext) {

        var eventArgs = executionContext?.getEventArgs();
        var formType = formContext.getFormType();
        var roleName = null;
        var saveMode = eventArgs.getSaveMode();
        var isSaveRecord = true;
        if (saveMode === Quikrete.Common.SaveMode.AutoSave) {
            eventArgs.preventDefault();
            return;
        }


        var regardingObject = formContext.getFieldValue("record1id");
        if (regardingObject) {
            //var isSaverecord = true;
            var entityType = regardingObject[0].entityType;
            if (["account", "opportunity", "quote", "salesorder"].includes(entityType)) {
                var regardingObjectId = regardingObject[0].id.replace(/{|}/g, "");
                var record2RoleId = formContext.getFieldValue("record2roleid");
                if (record2RoleId) {
                    roleName = record2RoleId[0].name;

                    if (formType === Quikrete.Common.FormType.Create) {
                        const queryParam = `?$select=record2roleid&$filter=_record1id_value eq '${regardingObjectId}'`;
                        var entityConnection = await formContext.retrieveMultipleRecords("connection", queryParam);
                        if (entityConnection.length > 0) {
                            for (var entConnection of entityConnection) {

                                var existingRoleName = entConnection["_record2roleid_value@OData.Community.Display.V1.FormattedValue"];
                                if (roleName === existingRoleName) {
                                    eventArgs.preventDefault();
                                    var confirmText = "Connection for this role already exists. Please select a different role.";
                                    var confirmTitle = "Warning";
                                    formContext.openAlertDialog(confirmTitle, confirmText);
                                    return;
                                }
                            }
                        }

                    }
                    var entityZipcode = null;
                    var entityAccountZipcode = null;
                    var entityAccountId = null;

                    // Fetch ZIP codes based on entity type
                    if (entityType === "account") {
                        entityZipcode = await getEntityZipcode("account", regardingObjectId, "_new_zipaddress1_lookup_value");
                    } else if (entityType === "opportunity") {
                        let entOpportunity = await formContext.retrieveRecord("opportunity", regardingObjectId, `?$select=_new_zipaddress1_lookup_value,_customerid_value`);
                        debugger;
                        if (entOpportunity) {
                            entityZipcode = entOpportunity['_new_zipaddress1_lookup_value'];
                            entityAccountId = entOpportunity._customerid_value;
                            if (entityAccountId) {
                                entityAccountZipcode = await getEntityZipcode("account", entityAccountId, "_new_zipaddress1_lookup_value");
                            }
                        }
                    } else if (entityType === "quote" || entityType === "salesorder") {
                        entityZipcode = await getEntityZipcode(entityType, regardingObjectId, "_new_zipaddress1_lookup_value");
                    }

                    var zipcodeEntity = await formContext.retrieveRecord("new_zipcode", entityZipcode);
                    var entityZipCodeByOpportunityAccount = entityType === "opportunity" ? await formContext.retrieveRecord("new_zipcode", entityAccountZipcode) : null;

                    if (zipcodeEntity != null) {
                        var entZipCode = zipcodeEntity;
                        var entzipCodeOpportunityAccunt = entityZipCodeByOpportunityAccount || null;
                        var newName = formContext.getFieldValue("record2id")?.[0]?.name || null;
                        var oldName = getFormattedValue(roleName, entZipCode, entzipCodeOpportunityAccunt, entityType);

                        formContext.setFieldSubmitMode("new_sysadminoverride");
                        if (roleName === "Area Manager - Pipe") {
                            // formContext.setFieldValue("new_sysadminoverride", 0); // this is boolen fields
                            formContext.setFieldValue("new_sysadminoverride", false);
                        }
                        else if (oldName != newName) {
                            // formContext.setFieldValue("new_sysadminoverride", 1); // this is boolen fields
                            formContext.setFieldValue("new_sysadminoverride", true);
                        }
                        else {
                            //   formContext.setFieldValue("new_sysadminoverride", 0); // this is boolen fields
                            formContext.setFieldValue("new_sysadminoverride", false);
                        }

                        //formContext.setFieldValue("new_sysadminoverride", roleName === "Area Manager - Pipe" ? 0 : oldName !== newName ? 1 : 0);
                        //0 - no , 1- yes
                    }
                }
            }
        }
    }

    // Function to get entity zip code
    async function getEntityZipcode(entity, entityId, field) {
        const queryParam = `?$select=${field}`;
        var result = await formContext.retrieveRecord(entity, entityId, queryParam);
        return result ? result[field] : null;
    }


    // Function to get formatted value based on roleName
    function getFormattedValue(roleName, entZipCode, entzipCodeOpportunityAccunt, entityType) {
        let source = roleName.endsWith("Spec") && entityType === "opportunity" ? entzipCodeOpportunityAccunt : entZipCode;

        if (roleName.startsWith("BC")) return source["_new_bcnameid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_bcnameid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("SE")) return source["_new_senameid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_senameid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("IBC")) return source["_new_ibcnameid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_ibcnameid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("SWC")) return source["_new_swcnameid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_swcnameid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Area Manager - Armortec")) return source["_new_areamgrarmortechid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_areamgrarmortechid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("ISC - Structures")) return source["_new_iscstructuresid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_iscstructuresid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("ISC - Pipe & Storm")) return source["_new_iscpipeandstormid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_iscpipeandstormid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Design Engineer - Armortec")) return source["_new_designengineerarmortecid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_designengineerarmortecid_value@OData.Community.Display.V1.FormattedValue"] : null;
        //  if (roleName.startsWith("Design Engineer - Plate & Specialty")) return source["_new_designengineerplatespecialtyid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_designengineerplatespecialtyid_value@OData.Community.Display.V1.FormattedValue"] : null; this field deleted in zipcode
        if (roleName.startsWith("Design Engineer - Precast")) return source["_new_designengineerprecastid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_designengineerprecastid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Truss Consultant")) return source["_new_insidetrussconsultantid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_insidetrussconsultantid_value@OData.Community.Display.V1.FormattedValue"] : null;
        // if (roleName.startsWith("Big R Bridge Territory Manager")) return source["_new_bigrbridgeterritorymanagerid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_bigrbridgeterritorymanagerid_value@OData.Community.Display.V1.FormattedValue"] : null;  this field deleted in zipcode
        if (roleName.startsWith("RE - Pipe")) return source["_new_repipeid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_repipeid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Regulatory Manage")) return source["_new_regulatorymanagerid_valu@OData.Community.Display.V1.FormattedValue"] ? source["_new_regulatorymanagerid_valu@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("SDE")) return source["_new_sdenameid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_sdenameid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("RWH Design Engineer")) return source["_new_rwhdesignengineerid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_rwhdesignengineerid_value@OData.Community.Display.V1.FormattedValue"] : null;
        // new connection roles
        if (roleName.startsWith("Region Manager - Pipe")) return source["_new_regionmanagerpipeid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_regionmanagerpipeid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Structures Proj Coord")) return source["_new_areaengineerstructuresid_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_areaengineerstructuresid_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Eng. Pipe Consultant")) return source["_new_engpipeconsultant_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_engpipeconsultant_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Prestress Comm Rep")) return source["_new_prestresscommrep_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_prestresscommrep_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Prestress Girder Rep")) return source["_new_prestressgirderrep_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_prestressgirderrep_value@OData.Community.Display.V1.FormattedValue"] : null;
        if (roleName.startsWith("Prestress Res Rep")) return source["_new_prestressresrep_value@OData.Community.Display.V1.FormattedValue"] ? source["_new_prestressresrep_value@OData.Community.Display.V1.FormattedValue"] : null;

        return null;
    }

    function MakeFieldsRequired(RoleName) {
        if (RoleName != null) {
            if (RoleName == "Area Manager - Pipe") {
                formContext.makeFieldRequired("new_piperegion", true);
                formContext.makeFieldRequired("record2id", true);
            } else {
                formContext.makeFieldRequired("new_piperegion", false);
                formContext.makeFieldRequired("record2id", false);
            }
        }
    }


    return {
        Init: init,
        FormOnLoad: formOnLoad,
        OnChangeOfRoleTo: onChangeOfRoleTo

    }
}());