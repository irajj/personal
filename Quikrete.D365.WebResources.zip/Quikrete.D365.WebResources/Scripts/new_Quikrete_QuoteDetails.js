﻿var Quikrete = Quikrete || {};
Quikrete.QuoteDetail = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;
    var recordBuid = null;
    var isdiscountpercentchange = false;
    function init(executionContext) {
        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.

        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();
        top.FormContext = formContext;
        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        // Adds a function to be called when form data is loaded.
        formContext.data.addOnLoad(formOnLoad);
        formContext.data.entity.addOnSave(formOnSave);
        formContext.data.entity.addOnPostSave(onPostSaveHandler)

        // call function on change of price per unit
        if (formContext.getAttribute("priceperunit") != null)
            formContext.getAttribute("priceperunit").addOnChange(onChangeOfPricePerUnit);

        // call function on change of Pcs/qty
        if (formContext.getAttribute("new_pcs") != null)
            formContext.getAttribute("new_pcs").addOnChange(onChangeOfPcsPerQty);

        // call function on change of discount percentage
        if (formContext.getAttribute("new_discountpercent") != null)
            formContext.getAttribute("new_discountpercent").addOnChange(onChangeOfDiscountPercentage);

        // call function on change of Manual Discount Amount
        if (formContext.getAttribute("manualdiscountamount") != null)
            formContext.getAttribute("manualdiscountamount").addOnChange(onChangeOfManualDiscount);


        // call function on change of shipto telephone
        if (formContext.getAttribute("shipto_telephone") != null)
            formContext.getAttribute("shipto_telephone").addOnChange(onChangeOfShipToTelephone);

        // call function on change of shipto fax
        if (formContext.getAttribute("shipto_fax") != null)
            formContext.getAttribute("shipto_fax").addOnChange(onChangeOfShipToFax);

        // call function on change of postal code
        if (formContext.getAttribute("new_zipshiptolookup") != null)
            formContext.getAttribute("new_zipshiptolookup").addOnChange(onChangeOfPostalCode);

        // call function on change of UOM
        if (formContext.getAttribute("uomid") != null)
            formContext.getAttribute("uomid").addOnChange(onChangeOfUOMId);
    }

    async function formOnLoad() {

        var formType = formContext.getFormType();
        var quoteDotProject = null, quoteManufacturingId = null, requestedDate = null;
        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);
        recordBuid = await Quikrete.ISVFunctions.GetRecordBuidFromLookup(formContext, "quoteid");
        formContext.getControl("new_manufacturinglocationid").setFocus(true);
        formContext.setFieldSubmitMode("new_productcode");
        formContext.setFieldSubmitMode("new_segment_lookup");
        formContext.setFieldSubmitMode("new_supersegment_lookup");
        formContext.setFieldSubmitMode("quantity");
        formContext.setFieldSubmitMode("priceperunit");
        formContext.setFieldSubmitMode("new_extendedpriceperunit");
        formContext.setFieldSubmitMode("new_productdescriptioneditable");
        formContext.setFieldSubmitMode("new_altproductdescription");

        //Filter Manufaturing Location By Buisness Unit Id.
        Quikrete.ISVFunctions.FilterLookup(formContext, "new_manufacturinglocationid", recordBuid, "new_owningbusinessunit");


        if (formType === Quikrete.Common.FormType.Create) { // Form type 1: Create
            formContext.setFieldValue("new_pcs", 1.0);
            var quote = formContext.getFieldValue("quoteid");
            if (quote != null) {
                var quoteID = quote[0].id;
                const queryParameterForQuote = `?$select=new_dotproject,_new_suggestedmanufacturinglocationid_value,new_requesteddate`;
                var quoteResponse = await formContext.retrieveRecord("quote", quoteID, queryParameterForQuote);
                if (quoteResponse != null) {
                    quoteDotProject = quoteResponse.new_dotproject;
                    if (quoteDotProject == "1") {
                        formContext.setFieldValue("new_followdotspecs", true);
                    }
                    else {
                        formContext.setFieldValue("new_followdotspecs", false);
                    }
                    quoteManufacturingId = quoteResponse._new_suggestedmanufacturinglocationid_value;
                    if (quoteManufacturingId != null) {
                        var lookupValue = new Array();
                        lookupValue[0] = new Object();

                        lookupValue[0].id = quoteResponse["_new_suggestedmanufacturinglocationid_value"];
                        lookupValue[0].name = quoteResponse["_new_suggestedmanufacturinglocationid_value@OData.Community.Display.V1.FormattedValue"];
                        lookupValue[0].entityType = quoteResponse["_new_suggestedmanufacturinglocationid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        formContext.setFieldValue("new_manufacturinglocationid", lookupValue);

                    }
                    requestedDate = quoteResponse["new_requesteddate@OData.Community.Display.V1.FormattedValue"];
                    if (requestedDate != null) {
                        var date = new Date(requestedDate);
                        formContext.setFieldValue("requestdeliveryby", date);
                    }
                }
            }

        }

        if (formType === Quikrete.Common.FormType.Update || formType === Quikrete.Common.FormType.Readonly || formType === Quikrete.Common.FormType.Disabled) {
            formContext.makeFieldDisabled("lineitemnumber", true);
            if (formContext.getFieldValue("lineitemnumber") != null) {
                formContext.makeFieldVisible("new_sequencechange", false);
            }
        }
        setPricingfields(formType);
    }


    function setPricingfields(formType) {

        formContext.setFieldValue("isproductoverridden", false);
        formContext.getAttribute("isproductoverridden").fireOnChange();

        if (recordBuid.toUpperCase() === Quikrete.Common.RinkerBU) {
            formContext.setFieldValue("ispriceoverridden", false);
        }
        else {
            formContext.setFieldValue("ispriceoverridden", true);
        }

        formContext.getAttribute("ispriceoverridden").fireOnChange();
        formContext.makeFieldVisible("productid", false);
        formContext.makeFieldVisible("productdescription", false);
        formContext.getControl("new_manufacturinglocationid").setFocus(true);

        if (formType != Quikrete.Common.FormType.Create) {
            formContext.setFieldSubmitMode("isproductoverridden", "never");
            formContext.makeFieldDisabled("uomid", false);
        }
        else {
            formContext.makeFieldDisabled("uomid", true);
        }

        setTimeout(async () => {
            formContext.makeFieldDisabled("ispriceoverridden", true);
            formContext.ui.tabs.get("Admin")?.sections.get("Hidden")?.setVisible(false);
        }, 500);
    }

    async function formOnSave(e) {
        var eventArgs = e?.getEventArgs();
        if (formContext.getFieldValue("quoteid") != null) {
            let oppId = formContext.getFieldValue("quoteid");
            let result = await formContext.retrieveRecord("quote", oppId[0].id, "?$select=statecode");
            if (result != null && result["statecode"] != 0) {
                eventArgs.preventDefault();
                return;
            }
        }

        await Quikrete.ISVFunctions.SavePCFData(formContext, e);
        calculateAmounts();

        var itemNumber = formContext.getFieldValue("new_itemno");
        var productDescriptionEditable = formContext.getFieldValue("new_productdescriptioneditable");
        var newItemNum = '';
        if (itemNumber != null && productDescriptionEditable != null) {
            newItemNum = itemNumber + "-" + productDescriptionEditable;
        }
        else if (itemNumber == '' || itemNumber == null) {
            newItemNum = productDescriptionEditable;
        }
        else if (productDescriptionEditable == '' || productDescriptionEditable == null) {
            newItemNum = itemNumber;
        }
        formContext.setFieldValue("new_productdescriptionwithitemnumber", newItemNum);
    }

    function onChangeOfPricePerUnit() {
        calculateAmounts();
    }

    function onChangeOfPcsPerQty() {
        calculateAmounts();
        if (formContext.getFieldValue("isproductoverridden") === true) {
            var qtyPerPcs = formContext.getFieldValue("new_pcs");
            formContext.setFieldValue("quantity", qtyPerPcs);
        }
    }

    function onChangeOfManualDiscount() {
        var manualDiscount = formContext.getFieldValue("manualdiscountamount");
        if (manualDiscount != null) {
            isdiscountpercentchange = false;
            calculateAmounts();
        }
    }

    function onChangeOfDiscountPercentage() {
        var discountPercent = formContext.getFieldValue("new_discountpercent");
        if (discountPercent != null) {
            isdiscountpercentchange = true;
            calculateAmounts();
        }
    }

    async function onChangeOfShipToTelephone() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "shipto_telephone");
    }

    async function onChangeOfShipToFax() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "shipto_fax");
    }



    function calculateAmounts() {

        var uomlist = formContext.getFieldValue("new_pamuomlist");
        var uomText = formContext.getLookupFieldText("uomid");

        let needLengthMultiplier = true;

        if (uomlist && uomText) {
            const uomlistArray = uomlist.split(",");
            needLengthMultiplier = uomlistArray.some(u => u.trim().toLowerCase() === uomText.toLowerCase());
        }

        var lengthMultiplier = Number(formContext.getFieldValue("new_lengthmultiplier")) || 1.0;
        var pcsPerQty = Number(formContext.getFieldValue("new_pcs")) || 0;

        // Calculate quantity exactly like legacy intent
        const quantity = needLengthMultiplier ? pcsPerQty * lengthMultiplier : pcsPerQty;


        // Default and validate price override flag
        var priceoverridden = formContext.getFieldValue("new_priceoverridden");
        if (priceoverridden == null) {
            priceoverridden = false;
            formContext.setFieldValue("new_priceoverridden", false);
        }

        // Convert values safely to numbers
        var unitPrice = Number(formContext.getFieldValue("priceperunit"));
        var discountpercent = Number(formContext.getFieldValue("new_discountpercent"));
        var manualDiscount = Number(formContext.getFieldValue("manualdiscountamount"));

        // Default invalid values to 0
        if (isNaN(unitPrice)) unitPrice = 0;
        if (isNaN(discountpercent)) discountpercent = 0;
        if (isNaN(manualDiscount)) manualDiscount = 0;

        // --- Discount logic ---
        if (isdiscountpercentchange) {
            manualDiscount = ((unitPrice * quantity) * discountpercent) / 100;
            if (isNaN(manualDiscount)) manualDiscount = 0;
        } else {
            // Avoid division by zero
            if (unitPrice > 0 && quantity > 0) {
                discountpercent = (100 * manualDiscount) / (unitPrice * quantity);
                if (isNaN(discountpercent)) discountpercent = 0;
            } else {
                discountpercent = 0;
            }
        }

        // --- Extended and Base Price Calculation ---
        var extendedpriceperunit = unitPrice - ((unitPrice * discountpercent) / 100);
        if (isNaN(extendedpriceperunit)) extendedpriceperunit = 0;

        var extendedAmount = extendedpriceperunit * quantity;
        if (isNaN(extendedAmount)) extendedAmount = 0;

        var baseAmount = unitPrice * quantity;
        if (isNaN(baseAmount)) baseAmount = 0;

        // --- Update field values ---
        formContext.setFieldValue("quantity", quantity);
        formContext.setFieldValue("manualdiscountamount", manualDiscount);
        formContext.setFieldValue("new_discountpercent", discountpercent);
        formContext.setFieldValue("new_extendedpriceperunit", extendedpriceperunit);
        formContext.setFieldValue("extendedamount", extendedAmount);
        formContext.setFieldValue("baseamount", baseAmount);
    }


    // on change of postalCode
    async function onChangeOfPostalCode() {
        await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipshiptolookup", "new_cityshiptolookup", "new_stateshiptolookup", "new_countyshiptolookup", "new_countryshiptolookup");
    }

    async function onPostSaveHandler() {
        await Quikrete.ISVFunctions.PostSaveHandlerForPCF(formContext);
    }

    function assignInsertSequenceNumber(executionContext) {
        const formContext = executionContext.getFormContext();
        var primaryEntityName = formContext.data.entity.getEntityName();
        top.formContext = formContext; // Assigning the formContext to 'top' to pass it to the web resource context
        top.Quikrete = Quikrete;
        top.primaryEntityName = primaryEntityName
        const stdButtonAttr = formContext.getAttribute("new_sequencechange");
        const stdValue = stdButtonAttr?.getValue();
        if (stdValue === "Assign/Insert Sequence #") {
            try {
                let OrderDetailsId = formContext.getCurrentRecordId();

                let pageInput = {
                    pageType: "webresource",
                    webresourceName: "new_Quikrete_InsertProduct",
                    data: new URLSearchParams({ OrderDetailsId }).toString(),
                };
                let navigationOptions = {
                    target: 2,
                    width: { value: 50, unit: "%" },
                    height: { value: 50, unit: "%" },
                    position: 1
                };
                formContext.navigateTo(pageInput, navigationOptions);
            }
            catch (error) {
                console.log("Error: " + error.message);
            }
        }
        stdButtonAttr.setValue(null);
        stdButtonAttr.setSubmitMode("never");
    }

    async function onChangeOfUOMId() {
        calculateAmounts();
    }

    return {
        Init: init,
        FormOnLoad: formOnLoad,
        AssignInsertSequenceNumber: assignInsertSequenceNumber
    }
}());