﻿var Quikrete = Quikrete || {};

Quikrete.Contact = (function () {
    var eventsAttached = false;
    var formContext = null;
    var userID = null;
    var userBUID = null;

    function init(executionContext) {

        //We added Form context JavaScript Dependencies in Web Resources,
        //So the system ensures that all dependent scripts are loaded first.
        Quikrete.FormExtension.Init(executionContext);

        formContext = executionContext?.getFormContext();

        if (!eventsAttached) {
            attachEvents();
        }
    }

    function attachEvents() {
        eventsAttached = true;

        //Adds a function to be called when the OnSave event is triggered.
        formContext.data.entity.addOnSave(formOnSave);

        // Adds a function to be called when form data is loaded.
        formContext.data.addOnLoad(formOnLoad);

        if (formContext.getAttribute("new_zipaddress1_lookup") != null)
            formContext.getAttribute("new_zipaddress1_lookup").addOnChange(onChangeOfAddress1ZipCode);

        if (formContext.getAttribute("telephone1") != null)
            formContext.getAttribute("telephone1").addOnChange(onChangeOfTelephone1);

        if (formContext.getAttribute("telephone2") != null)
            formContext.getAttribute("telephone2").addOnChange(onChangeOfTelephone2);

        if (formContext.getAttribute("fax") != null)
            formContext.getAttribute("fax").addOnChange(onChangeOfFax);

        if (formContext.getAttribute("mobilephone") != null)
            formContext.getAttribute("mobilephone").addOnChange(onChangeOfMobilePhone);

        if (formContext.getAttribute("parentcustomerid") != null)
            formContext.getAttribute("parentcustomerid").addOnChange(onChangeOfParentCustomer);

        // --- Subgrid hiding: bind to tab expand ---
        if (formContext.ui.tabs.get("activities") != null)
            formContext.ui.tabs.get("activities").addTabStateChange(onTabStateChangeOfActivities);
    }

    async function onChangeOfAddress1ZipCode() {
        await Quikrete.ISVFunctions.GetDetailsByZipCodeLookup(formContext, "new_zipaddress1_lookup", "new_cityaddress1_lookup", "new_stateaddress1_lookup", "new_countyaddress1_lookup", "new_countryaddress1_lookup");
    }

    async function onChangeOfTelephone1() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "telephone1");
    }

    async function onChangeOfTelephone2() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "telephone2");
    }

    async function onChangeOfFax() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "fax");
    }

    async function onChangeOfMobilePhone() {
        Quikrete.ISVFunctions.ValidateAndFormatFaxPhoneNumber(formContext, "mobilephone");
    }

    async function onChangeOfParentCustomer() {
        try {

            const parentCustomer = formContext.getFieldValue("parentcustomerid");
            if (!parentCustomer || parentCustomer.length === 0) return;

            const { id, entityType } = parentCustomer[0];
            const customerId = id.replace(/[{}]/g, "").toLowerCase();

            const customerRecord = await Xrm.WebApi.retrieveRecord(entityType, customerId);

            // Set lookup fields
            setLookupField(
                "new_zipaddress1_lookup",
                customerRecord,
                "_new_zipaddress1_lookup_value"
            );

            setLookupField(
                "new_stateaddress1_lookup",
                customerRecord,
                "_new_stateaddress1_lookup_value"
            );

            setLookupField(
                "new_cityaddress1_lookup",
                customerRecord,
                "_new_cityaddress1_lookup_value"
            );

            setLookupField(
                "new_countyaddress1_lookup",
                customerRecord,
                "_new_countyaddress1_lookup_value"
            );

            setLookupField(
                "new_countryaddress1_lookup",
                customerRecord,
                "_new_countryaddress1_lookup_value"
            );

            setLookupValuesofAddresstoText();
        }
        catch (error) {
            console.error("Error in onChangeOfParentCustomer:", error);
        }
    }

    function setLookupField(fieldName, record, lookupSchemaName) {
        const lookupId = record[lookupSchemaName];
        if (!lookupId) return;
        const lookup = [{
            id: lookupId,
            name: record[`${lookupSchemaName}@OData.Community.Display.V1.FormattedValue`],
            entityType: record[`${lookupSchemaName}@Microsoft.Dynamics.CRM.lookuplogicalname`]
        }];
        const attribute = formContext.getAttribute(fieldName);
        if (attribute) {
            attribute.setValue(lookup);
        }
    }

    async function formOnLoad() {
        userID = formContext.getCurrentUserId();
        userBUID = await formContext.getBusinessUnit(userID);
        if (userBUID == Quikrete.Common.HardscapesAndMasonryBU) {
            formContext.makeFieldRequired("mobilephone", true);
        }

        // Set Parent Customer Info
        await setParentCustomerInfo();
    }

    async function setParentCustomerInfo() {

        const parentInfo = formContext.context.getQueryStringParameters();
        const parentEntityId = parentInfo.parentrecordid;
        const parentEntityName = parentInfo.parentrecordtype;
        if (parentEntityName && ["salesorder", "quote", "opportunity"].includes(parentEntityName.toLowerCase())) {
            var parentCustomerAttr = await formContext.retrieveRecord(parentEntityName, parentEntityId, "?$select=_customerid_value");
            if (parentCustomerAttr) {
                var accountLookup = [];
                accountLookup.push({
                    id: parentCustomerAttr["_customerid_value"].replace("{", "").replace("}", "").toLowerCase(),
                    name: parentCustomerAttr["_customerid_value@OData.Community.Display.V1.FormattedValue"],
                    entityType: parentCustomerAttr["_customerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"]
                });
            }
            formContext.getAttribute("parentcustomerid").setValue(accountLookup);
            formContext.getAttribute("parentcustomerid").fireOnChange();
        }
    }

    function formOnSave(executionContext) {
        const eventArgs = executionContext.getEventArgs();

        setLookupValuesofAddresstoText();
        // Run validation
        const isValid = validatePhoneEmail();

        // Prevent save if validation fails
        if (!isValid) {
            eventArgs.preventDefault();
        }
    }

    function setLookupValuesofAddresstoText() {

        //Set text Value from lookup field for Address 1
        var postalcode1 = formContext.getLookupFieldText("new_zipaddress1_lookup");
        var city1 = formContext.getLookupFieldText("new_cityaddress1_lookup");
        var state1 = formContext.getLookupFieldText("new_stateaddress1_lookup");
        var county1 = formContext.getLookupFieldText("new_countyaddress1_lookup");
        var country1 = formContext.getLookupFieldText("new_countryaddress1_lookup");

        formContext.setFieldValue("address1_postalcode", postalcode1);
        formContext.setFieldValue("address1_city", city1);
        formContext.setFieldValue("address1_stateorprovince", state1);
        formContext.setFieldValue("address1_county", county1);
        formContext.setFieldValue("address1_country", country1);
    }

    function validatePhoneEmail() {
        const mobilePhone = formContext.getFieldValue("telephone1");
        const businessPhone = formContext.getFieldValue("mobilephone");
        const emailAddress = formContext.getFieldValue("emailaddress1");
        if (!mobilePhone && !businessPhone && !emailAddress) {
            var confirmText = "At least one of Business Phone, Mobile Phone, or Email must be provided.";
            var confirmTitle = "Warning";
            formContext.openAlertDialog(confirmTitle, confirmText);
            return false;
        }
        return true;
    }

    function onTabStateChangeOfActivities() {
        var tab = formContext.ui.tabs.get("activities"); // tab where Notes grid is
        if (tab) {
            if (tab.getDisplayState() === "expanded") {
                // run your logic when tab opens
                Quikrete.ISVFunctions.HideNotSubgridAddButtons("notes");
                Quikrete.ISVFunctions.HideActivitiesSubgridButton();
            }
        }
    }

    return {
        Init: init,
        FormOnSave: formOnSave,
        OnChangeOfAddress1ZipCode: onChangeOfAddress1ZipCode,
        OnChangeOfTelephone1: onChangeOfTelephone1,
        OnChangeOfTelephone2: onChangeOfTelephone2,
        OnChangeOfFax: onChangeOfFax,
        OnChangeOfMobilePhone: onChangeOfMobilePhone
    }
}());